import { exec } from "child_process";
import { promises as fs } from "fs";
import * as path from "path";
import { promisify } from "util";
import axios from "axios";

const execAsync = promisify(exec);

// Constants for Docker environment
const RTMP_HOST = process.env.RTMP_SERVER_HOST || 'rtmp';
const RTMP_HTTP_PORT = process.env.RTMP_HTTP_PORT || '80';
const RTMP_RTMP_PORT = process.env.RTMP_PORT || '1935';

/**
 * Check if RTMP server is running
 */
async function isRtmpServerRunning(): Promise<boolean> {
  try {
    // Try to reach the stats endpoint of the RTMP server
    const response = await axios.get(`http://${RTMP_HOST}:${RTMP_HTTP_PORT}/stat`, {
      timeout: 5000,
    });
    return response.status === 200;
  } catch (error) {
    console.error('Error checking RTMP server status:', error);
    return false;
  }
}

/**
 * Check if RTMP module is working
 */
async function isRtmpModuleWorking(): Promise<boolean> {
  try {
    // Check if we can reach the RTMP stat page
    const response = await axios.get(`http://${RTMP_HOST}:${RTMP_HTTP_PORT}/stat`, {
      timeout: 5000,
    });
    return response.status === 200 && response.data.includes('rtmp');
  } catch (error) {
    return false;
  }
}

/**
 * Get RTMP server status
 */
async function getNginxStatus(): Promise<{
  installed: boolean;
  running: boolean;
  rtmpInstalled: boolean;
  version: string | null;
  error: string | null;
  supportsAutoPush: boolean;
}> {
  try {
    const running = await isRtmpServerRunning();
    const rtmpInstalled = await isRtmpModuleWorking();
    
    // Get the version by parsing the stat page
    let version = null;
    try {
      const response = await axios.get(`http://${RTMP_HOST}:${RTMP_HTTP_PORT}/stat`, {
        timeout: 5000,
      });
      const versionMatch = response.data.match(/<nginx_version>(.*?)<\/nginx_version>/);
      if (versionMatch && versionMatch[1]) {
        version = versionMatch[1];
      }
    } catch (error) {
      // Ignore version errors
    }
    
    return {
      installed: true, // In Docker, we assume it's installed
      running,
      rtmpInstalled,
      version,
      error: null,
      supportsAutoPush: true, // Modern versions should support this
    };
  } catch (error) {
    return {
      installed: false,
      running: false,
      rtmpInstalled: false,
      version: null,
      error: error instanceof Error ? error.message : 'Unknown error',
      supportsAutoPush: false,
    };
  }
}

/**
 * Get RTMP configuration
 */
async function getRtmpConfig(): Promise<any> {
  try {
    // In Docker, we return a predefined configuration
    return {
      rtmp: {
        port: parseInt(RTMP_RTMP_PORT),
        chunk_size: 60000,
        gop_cache: true,
        ping: 30,
        ping_timeout: 60,
      },
      http: {
        port: parseInt(RTMP_HTTP_PORT),
        allow_origin: '*',
      },
    };
  } catch (error) {
    console.error('Error getting RTMP configuration:', error);
    return null;
  }
}

/**
 * Change the RTMP port
 */
async function changeRtmpPort(port: number): Promise<{ success: boolean, message: string }> {
  // In Docker, we can't change ports dynamically, but we can update the environment
  // and restart the container
  return {
    success: false,
    message: "In Docker mode, port changes require updating the docker-compose.yml file and restarting the containers."
  };
}

/**
 * Change the HTTP port
 */
async function changeHttpPort(port: number): Promise<{ success: boolean, message: string }> {
  // In Docker, we can't change ports dynamically, but we can update the environment
  // and restart the container
  return {
    success: false,
    message: "In Docker mode, port changes require updating the docker-compose.yml file and restarting the containers."
  };
}

/**
 * Restart RTMP server
 */
async function restartRtmpServer(): Promise<void> {
  try {
    // In Docker, we would restart the container
    console.log("In Docker mode, restarting RTMP server requires restarting the container.");
    console.log("To restart the RTMP container, run: docker-compose restart rtmp");
  } catch (error) {
    console.error('Error restarting RTMP server:', error);
    throw error;
  }
}

/**
 * Check if a port is available
 */
async function isPortAvailable(port: number): Promise<boolean> {
  // In Docker, port availability depends on the host, not the container
  return true;
}

// Export the Docker-specific functions
export {
  isRtmpServerRunning,
  isRtmpModuleWorking,
  getNginxStatus,
  getRtmpConfig,
  changeRtmpPort,
  changeHttpPort,
  restartRtmpServer,
  isPortAvailable,
};