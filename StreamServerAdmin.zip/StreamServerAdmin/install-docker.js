#!/usr/bin/env node

const { exec, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const http = require('http');
const { promisify } = require('util');

const execPromise = promisify(exec);
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Configuration
const APP_PORT = process.env.PORT || 5000;
const RTMP_PORT = process.env.RTMP_PORT || 1935;
const RTMP_HTTP_PORT = process.env.RTMP_HTTP_PORT || 8080;
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000; // 5 seconds
const DB_READY_WAIT = 10000; // 10 seconds

console.log('🚀 Stream Manager Docker Installation Script');
console.log('===========================================\n');

// Check if Docker is installed
function checkDocker() {
  return new Promise((resolve, reject) => {
    exec('docker --version', (error) => {
      if (error) {
        console.log('❌ Docker is not installed or not in your PATH');
        console.log('Please install Docker from https://docs.docker.com/get-docker/');
        reject(new Error('Docker is not installed'));
      } else {
        console.log('✅ Docker is installed');
        resolve();
      }
    });
  });
}

// Check if Docker Compose is installed
function checkDockerCompose() {
  return new Promise((resolve, reject) => {
    // Try both docker-compose and docker compose (v2)
    exec('docker-compose --version', (error) => {
      if (error) {
        // Try Docker Compose V2
        exec('docker compose version', (error2) => {
          if (error2) {
            console.log('❌ Docker Compose is not installed or not in your PATH');
            console.log('Please install Docker Compose from https://docs.docker.com/compose/install/');
            reject(new Error('Docker Compose is not installed'));
          } else {
            console.log('✅ Docker Compose V2 is installed');
            // Set global compose command to V2
            global.composeCmd = 'docker compose';
            resolve();
          }
        });
      } else {
        console.log('✅ Docker Compose is installed');
        // Set global compose command to V1
        global.composeCmd = 'docker-compose';
        resolve();
      }
    });
  });
}

// Copy environment variables
function setupEnvironment() {
  return new Promise((resolve) => {
    if (fs.existsSync('.env.docker')) {
      console.log('🔧 Using .env.docker for configuration');
      
      // Copy .env.docker to .env if not exists or ask for overwrite
      if (!fs.existsSync('.env')) {
        fs.copyFileSync('.env.docker', '.env');
        console.log('✅ Created .env file from .env.docker template');
        resolve();
      } else {
        rl.question('⚠️ .env file already exists. Overwrite with .env.docker? (y/n): ', (answer) => {
          if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
            fs.copyFileSync('.env.docker', '.env');
            console.log('✅ Overwritten .env with .env.docker');
          } else {
            console.log('ℹ️ Using existing .env file');
          }
          resolve();
        });
      }
    } else {
      console.log('⚠️ .env.docker not found, creating default .env.docker file');
      const defaultEnvContent = `# Database Configuration
DATABASE_URL=postgres://postgres:postgres@db:5432/stream_manager
PGHOST=db
PGPORT=5432
PGUSER=postgres
PGPASSWORD=postgres
PGDATABASE=stream_manager

# Application Settings
NODE_ENV=production
PORT=5000
SESSION_SECRET=stream_manager_session_secret
USE_DOCKER=true

# RTMP Server Configuration
RTMP_SERVER_HOST=rtmp
RTMP_HTTP_PORT=80
RTMP_PORT=1935`;
      fs.writeFileSync('.env.docker', defaultEnvContent);
      fs.copyFileSync('.env.docker', '.env');
      console.log('✅ Created default .env and .env.docker files');
      resolve();
    }
  });
}

// Check if any required ports are already in use
async function checkPorts() {
  console.log('🔍 Checking if required ports are available...');
  
  const portsToCheck = [
    { port: APP_PORT, name: 'Dashboard' },
    { port: RTMP_PORT, name: 'RTMP Server' },
    { port: RTMP_HTTP_PORT, name: 'RTMP HTTP/HLS' }
  ];
  
  for (const { port, name } of portsToCheck) {
    try {
      // Try to establish a server on the port
      const server = http.createServer();
      await new Promise((resolve, reject) => {
        server.once('error', (err) => {
          if (err.code === 'EADDRINUSE') {
            reject(new Error(`Port ${port} is already in use`));
          } else {
            reject(err);
          }
        });
        server.once('listening', () => {
          server.close();
          resolve();
        });
        server.listen(port);
      });
      console.log(`✅ Port ${port} (${name}) is available`);
    } catch (error) {
      console.log(`❌ Port ${port} (${name}) is already in use!`);
      
      // Ask if we should stop other containers that might be using these ports
      const answer = await askQuestion(`Would you like to stop all running Docker containers? (y/n): `);
      if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
        try {
          console.log('Stopping all running Docker containers...');
          await execPromise('docker stop $(docker ps -q)');
          console.log('✅ All Docker containers stopped');
        } catch (error) {
          console.log('No running containers found or error stopping containers');
        }
      } else {
        console.log('⚠️ Please free up the required ports and run the script again.');
        process.exit(1);
      }
      break;
    }
  }
}

// Build and start Docker containers
async function startContainers() {
  console.log('🚀 Building and starting Docker containers...');
  
  try {
    // Pull the latest images first
    console.log('Pulling latest base images...');
    await execPromise(`${global.composeCmd} pull`);
    
    // Start the containers
    console.log('Building and starting containers...');
    const { stdout, stderr } = await execPromise(`${global.composeCmd} up -d --build`);
    console.log(stdout);
    
    if (stderr && stderr.includes('ERROR')) {
      throw new Error(`Error in docker-compose: ${stderr}`);
    }
    
    console.log('✅ Containers are running!');
    return true;
  } catch (error) {
    console.error('❌ Error starting containers:', error.message);
    
    // Attempt to fix common issues
    console.log('🔧 Attempting to fix common Docker issues...');
    
    try {
      // Stop all containers and remove them
      await execPromise(`${global.composeCmd} down`);
      console.log('Stopped and removed all containers');
      
      // Prune unused containers, networks, and volumes
      await execPromise('docker system prune -f');
      console.log('Pruned unused Docker resources');
      
      // Try starting again
      console.log('Starting containers again...');
      await execPromise(`${global.composeCmd} up -d --build`);
      console.log('✅ Containers restarted successfully!');
      return true;
    } catch (retryError) {
      console.error('❌ Failed to fix Docker issues:', retryError.message);
      throw new Error('Could not start Docker containers');
    }
  }
}

// Initialize database
async function initializeDatabase() {
  console.log('🔧 Initializing database...');
  console.log(`Waiting ${DB_READY_WAIT/1000} seconds for the database to be ready...`);
  
  // Wait for the database to be ready
  await new Promise((resolve) => setTimeout(resolve, DB_READY_WAIT));
  
  let retries = 0;
  while (retries < MAX_RETRIES) {
    try {
      const { stdout, stderr } = await execPromise(`${global.composeCmd} exec -T app npm run db:push`);
      console.log(stdout);
      console.log('✅ Database initialized!');
      return true;
    } catch (error) {
      retries++;
      console.error(`⚠️ Database initialization attempt ${retries} failed:`, error.message);
      
      if (retries >= MAX_RETRIES) {
        console.error('❌ Failed to initialize database after multiple attempts');
        console.log('Proceeding anyway - the system may attempt to initialize on first run');
        return false;
      }
      
      console.log(`Retrying in ${RETRY_DELAY/1000} seconds...`);
      await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY));
    }
  }
}

// Check service health
async function checkServiceHealth() {
  console.log('🔍 Checking health of services...');
  
  try {
    // Check if containers are running
    const { stdout: containerStatus } = await execPromise(`${global.composeCmd} ps`);
    console.log(containerStatus);
    
    const containers = ['stream-app', 'stream-rtmp', 'stream-db'];
    let allRunning = true;
    
    for (const container of containers) {
      if (!containerStatus.includes(container) || !containerStatus.includes('Up')) {
        allRunning = false;
        console.log(`⚠️ Container ${container} is not running properly`);
      }
    }
    
    if (!allRunning) {
      console.log('🔄 Restarting all containers...');
      await execPromise(`${global.composeCmd} restart`);
      console.log('✅ All containers restarted');
    } else {
      console.log('✅ All containers are running properly');
    }
    
    return true;
  } catch (error) {
    console.error('❌ Error checking service health:', error.message);
    return false;
  }
}

// Fix NGINX 502 issues
async function fixNginxIssues() {
  console.log('🔧 Applying fixes for common NGINX 502 Bad Gateway issues...');
  
  try {
    // Check if RTMP container is running
    const { stdout: rtmpStatus } = await execPromise('docker ps | grep stream-rtmp');
    
    if (!rtmpStatus.includes('stream-rtmp')) {
      console.log('⚠️ RTMP container is not running, attempting to start it...');
      await execPromise(`${global.composeCmd} up -d rtmp`);
    }
    
    // Check the logs for the RTMP container
    const { stdout: rtmpLogs } = await execPromise('docker logs stream-rtmp');
    
    if (rtmpLogs.includes('error') || rtmpLogs.includes('invalid')) {
      console.log('⚠️ RTMP container has configuration errors, rebuilding container...');
      await execPromise(`${global.composeCmd} up -d --build rtmp`);
    }
    
    console.log('✅ NGINX configuration fixes applied');
    return true;
  } catch (error) {
    console.log('⚠️ Could not fix NGINX issues automatically:', error.message);
    console.log('Please check your Docker and NGINX configuration manually');
    return false;
  }
}

// Helper function to ask questions
function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

// Display connection information
function displayInfo() {
  console.log('\n🎉 Stream Manager is now running!');
  console.log('====================================');
  console.log(`📊 Dashboard: http://localhost:${APP_PORT}`);
  console.log(`🎥 RTMP Server: rtmp://localhost:${RTMP_PORT}/live`);
  console.log(`🎬 HLS Stream: http://localhost:${RTMP_HTTP_PORT}/hls/[stream-key].m3u8`);
  console.log(`📈 RTMP Stats: http://localhost:${RTMP_HTTP_PORT}/stat`);
  console.log('====================================');
  console.log('\n📝 Default admin credentials:');
  console.log('Username: admin');
  console.log('Password: admin123');
  console.log('\n⚠️ Remember to change the default password!');
  
  console.log('\n🔧 Troubleshooting:');
  console.log('If you encounter 502 Bad Gateway errors:');
  console.log(`1. Run 'node troubleshoot.js' to automatically fix common issues`);
  console.log(`2. Check container logs with '${global.composeCmd} logs'`);
  console.log(`3. Restart containers with '${global.composeCmd} restart'`);
}

// Create troubleshooting script
function createTroubleshootScript() {
  const troubleshootScript = `#!/usr/bin/env node

const { exec } = require('child_process');
const { promisify } = require('util');
const execPromise = promisify(exec);

console.log('🔧 Stream Manager Troubleshooting Tool');
console.log('=====================================');

async function checkContainers() {
  console.log('\\n📋 Checking container status...');
  
  try {
    const { stdout } = await execPromise('docker ps -a');
    console.log(stdout);
    
    // Check if all containers are running
    const requiredContainers = ['stream-app', 'stream-rtmp', 'stream-db'];
    let allRunning = true;
    
    for (const container of requiredContainers) {
      if (!stdout.includes(container) || !stdout.includes('Up')) {
        console.log(\`⚠️ Container \${container} is not running properly\`);
        allRunning = false;
      }
    }
    
    return allRunning;
  } catch (error) {
    console.error('❌ Error checking containers:', error.message);
    return false;
  }
}

async function restartContainers() {
  console.log('\\n🔄 Restarting all containers...');
  
  try {
    // Try both docker-compose and docker compose (v2)
    try {
      await execPromise('docker-compose restart');
    } catch (error) {
      await execPromise('docker compose restart');
    }
    
    console.log('✅ All containers restarted');
    return true;
  } catch (error) {
    console.error('❌ Error restarting containers:', error.message);
    return false;
  }
}

async function checkLogs() {
  console.log('\\n📃 Checking container logs for errors...');
  
  const containers = ['stream-app', 'stream-rtmp', 'stream-db'];
  let errors = false;
  
  for (const container of containers) {
    try {
      console.log(\`\\n📜 Logs for \${container}:\`);
      const { stdout } = await execPromise(\`docker logs --tail 50 \${container}\`);
      
      // Look for error patterns
      const errorPatterns = ['ERROR', 'Error:', 'fatal', 'Failed', 'Exception'];
      
      for (const pattern of errorPatterns) {
        if (stdout.includes(pattern)) {
          console.log(\`⚠️ Found \${pattern} in \${container} logs\`);
          errors = true;
        }
      }
      
      // Print last 5 lines of logs
      const lines = stdout.split('\\n');
      const lastLines = lines.slice(Math.max(0, lines.length - 5)).join('\\n');
      console.log(lastLines);
      
    } catch (error) {
      console.log(\`⚠️ Could not get logs for \${container}: \${error.message}\`);
    }
  }
  
  return !errors;
}

async function fixNginxIssues() {
  console.log('\\n🔧 Attempting to fix NGINX 502 Bad Gateway issues...');
  
  try {
    // Check RTMP container specifically
    console.log('📋 Checking RTMP container status...');
    const { stdout: rtmpStatus } = await execPromise('docker ps -a | grep stream-rtmp');
    console.log(rtmpStatus);
    
    if (!rtmpStatus.includes('Up')) {
      console.log('⚠️ RTMP container is not running, restarting it...');
      
      try {
        await execPromise('docker-compose up -d rtmp');
      } catch (error) {
        await execPromise('docker compose up -d rtmp');
      }
      
      console.log('✅ RTMP container restarted');
    }
    
    // Rebuild RTMP container if needed
    console.log('🔄 Rebuilding RTMP container to ensure clean configuration...');
    
    try {
      await execPromise('docker-compose up -d --build rtmp');
    } catch (error) {
      await execPromise('docker compose up -d --build rtmp');
    }
    
    console.log('✅ RTMP container rebuilt');
    
    // Check network communication between containers
    console.log('🔍 Testing network communication between containers...');
    
    try {
      await execPromise('docker exec stream-app ping -c 2 stream-rtmp');
      console.log('✅ Network communication is working properly');
    } catch (error) {
      console.log('⚠️ Network communication issue detected, restarting Docker network...');
      
      try {
        await execPromise('docker-compose down');
        await execPromise('docker-compose up -d');
      } catch (composeError) {
        await execPromise('docker compose down');
        await execPromise('docker compose up -d');
      }
    }
    
    return true;
  } catch (error) {
    console.error('❌ Error fixing NGINX issues:', error.message);
    return false;
  }
}

async function showHealthStatus() {
  console.log('\\n🏥 Checking health of services...');
  
  try {
    // Check ports
    const ports = [
      { port: 5000, service: 'Dashboard' },
      { port: 1935, service: 'RTMP' },
      { port: 8080, service: 'HLS/DASH' }
    ];
    
    for (const { port, service } of ports) {
      try {
        const { stdout } = await execPromise(\`netstat -tuln | grep :\${port}\`);
        if (stdout) {
          console.log(\`✅ \${service} port \${port} is open\`);
        } else {
          console.log(\`❌ \${service} port \${port} is not open\`);
        }
      } catch (error) {
        console.log(\`⚠️ Could not check \${service} port \${port}\`);
      }
    }
  } catch (error) {
    console.log('⚠️ Could not check service health:', error.message);
  }
}

async function troubleshoot() {
  try {
    const containersOk = await checkContainers();
    
    if (!containersOk) {
      await restartContainers();
    }
    
    await checkLogs();
    await fixNginxIssues();
    await showHealthStatus();
    
    console.log('\\n✅ Troubleshooting complete!');
    console.log('If you still have issues, please check the documentation for manual fixes.');
  } catch (error) {
    console.error('❌ Error during troubleshooting:', error.message);
  }
}

troubleshoot();
`;

  fs.writeFileSync('troubleshoot.js', troubleshootScript);
  console.log('✅ Created troubleshoot.js script for fixing common issues');
}

// Main installation function
async function install() {
  try {
    await checkDocker();
    await checkDockerCompose();
    await setupEnvironment();
    await checkPorts();
    
    // Start containers
    if (await startContainers()) {
      // Wait for services to start up
      await new Promise((resolve) => setTimeout(resolve, 5000));
      
      // Check service health
      await checkServiceHealth();
      
      // Apply NGINX fixes
      await fixNginxIssues();
      
      // Initialize database
      await initializeDatabase();
      
      // Create troubleshooting script
      createTroubleshootScript();
      
      // Display information
      displayInfo();
    }
    
    rl.close();
  } catch (error) {
    console.error('❌ Installation failed:', error.message);
    
    const answer = await askQuestion('Would you like to run troubleshooting steps? (y/n): ');
    if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
      await fixNginxIssues();
      await checkServiceHealth();
    }
    
    rl.close();
    process.exit(1);
  }
}

// Run the installation
install();