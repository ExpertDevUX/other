# Stream Manager

A sophisticated video stream server management platform that leverages intelligent design and automation to simplify complex server operations.

## Features

- 💻 User account management with admin features
- 📹 RTMP server setup and configuration
- 🔄 Automatic installation with Docker
- 🎥 Live streaming with HLS/DASH support
- 📊 Real-time server metrics via WebSockets
- 🔧 NGINX configuration management
- 🔒 HTTPS support with Let's Encrypt
- 🌐 Integration with WpStream (WordPress plugin)
- 🔍 Bandwidth monitoring and management
- 🧩 Embedding functionality for streams

## Technology Stack

- **Backend**: Node.js, Express
- **Frontend**: React, TypeScript, Shadcn UI, TailwindCSS
- **Database**: PostgreSQL with Drizzle ORM
- **Streaming**: NGINX-RTMP module
- **Containerization**: Docker

## Installation

### Using Docker (Recommended)

1. Make sure you have [Docker](https://docs.docker.com/get-docker/) and [Docker Compose](https://docs.docker.com/compose/install/) installed.

2. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/stream-manager.git
   cd stream-manager
   ```

3. Run the installation script:
   ```bash
   node install-docker.js
   ```

4. Once the installation is complete, visit http://localhost:5000 to access the Stream Manager dashboard.

### Default Credentials

- **Username**: admin
- **Password**: admin123

Make sure to change the default password after your first login!

## Service URLs

- **Dashboard**: http://localhost:5000
- **RTMP Server**: rtmp://localhost:1935/live
- **HLS Stream**: http://localhost:8080/hls/[stream-key].m3u8
- **DASH Stream**: http://localhost:8080/dash/[stream-key]/index.mpd
- **RTMP Stats**: http://localhost:8080/stat

## Docker Commands

### Start Services
```bash
docker-compose up -d
```

### Stop Services
```bash
docker-compose down
```

### View Logs
```bash
docker-compose logs -f
```

### Rebuild Services
```bash
docker-compose up -d --build
```

## Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. The server will be running at http://localhost:5000

## Production Deployment

For production deployment, we recommend using Docker with proper environment configurations.

1. Update the `.env.docker` file with your production settings
2. Build and start the containers:
   ```bash
   docker-compose -f docker-compose.yml up -d --build
   ```

## Troubleshooting

### 502 Bad Gateway Error
If you encounter a 502 Bad Gateway error when accessing the application through Docker:

1. Check if all containers are running:
   ```bash
   docker-compose ps
   ```

2. Ensure the app container is healthy:
   ```bash
   docker logs stream-app
   ```

3. Make sure the NGINX container is properly configured:
   ```bash
   docker logs stream-rtmp
   ```

4. Restart the containers:
   ```bash
   docker-compose restart
   ```

5. If the issue persists, check if the ports are properly exposed and not in use by other applications.

## License

MIT License