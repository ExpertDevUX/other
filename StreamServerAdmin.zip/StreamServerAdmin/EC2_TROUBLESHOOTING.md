# EC2 Deployment Troubleshooting Guide

This guide will help you troubleshoot common issues when deploying the Stream Manager application to an AWS EC2 instance.

## Connection Issues

### Can't Connect to EC2 Instance

**Symptoms:**
- SSH connection fails
- Web application not accessible
- "Host not found" or "Connection refused" errors

**Troubleshooting Steps:**

1. **Verify instance is running:**
   ```bash
   aws ec2 describe-instances --instance-ids i-035729c326f963671 --region ap-southeast-1 --query 'Reservations[0].Instances[0].[State.Name,PublicIpAddress]'
   ```

2. **Check security group rules:**
   - Verify that ports 22 (SSH), 80 (HTTP), 443 (HTTPS), 1935 (RTMP), and 8000-9000 are open
   - Use the AWS console or this command:
   ```bash
   aws ec2 describe-security-groups --group-names stream-manager-sg --region ap-southeast-1
   ```

3. **Test SSH connection with verbose output:**
   ```bash
   ssh -v -i stream-manager-key.pem ubuntu@18.143.116.55
   ```

4. **Check if SSH key has correct permissions:**
   ```bash
   chmod 400 stream-manager-key.pem
   ```

## Application Issues

### Web Server Not Running

**Symptoms:**
- Can connect to EC2 but web application not accessible
- "Connection refused" when trying to access the website

**Troubleshooting Steps:**

1. **Check if Nginx is running:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo systemctl status nginx"
   ```

2. **Check Nginx configuration:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo nginx -t"
   ```

3. **Check application logs:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo journalctl -u stream-manager.service"
   ```

4. **Verify application is running:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo systemctl status stream-manager.service"
   ```

### Database Connection Issues

**Symptoms:**
- Application fails to start
- Database connection errors in logs

**Troubleshooting Steps:**

1. **Check PostgreSQL status:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo systemctl status postgresql"
   ```

2. **Verify database exists:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo -u postgres psql -c '\l'"
   ```

3. **Check database connection string:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "cat /opt/stream-manager/.env"
   ```

4. **Test database connection:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "sudo -u postgres psql -c 'SELECT 1;'"
   ```

## Deployment Issues

### Error in Deployment Script

**Symptoms:**
- Deployment script fails
- Application not installed properly

**Troubleshooting Steps:**

1. **Check deployment logs:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "cat /var/log/deploy-app.log"
   ```

2. **Check for Node.js installation:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "node -v"
   ```

3. **Check for npm installations:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "npm -v"
   ```

4. **Manually run npm install:**
   ```bash
   ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "cd /opt/stream-manager && sudo npm install"
   ```

## Quick Fixes

### Restart Services

```bash
# Connect to the EC2 instance
ssh -i stream-manager-key.pem ubuntu@18.143.116.55

# Restart PostgreSQL
sudo systemctl restart postgresql

# Restart Nginx
sudo systemctl restart nginx

# Restart application
sudo systemctl restart stream-manager.service
```

### Update Application

```bash
# Connect to the EC2 instance
ssh -i stream-manager-key.pem ubuntu@18.143.116.55

# Go to application directory
cd /opt/stream-manager

# Pull latest changes (if using git)
sudo git pull

# Or upload new files with scp
# exit the SSH session first, then:
scp -i stream-manager-key.pem -r ./your-updated-files ubuntu@18.143.116.55:/opt/stream-manager/

# Then SSH back in and:
sudo npm install
sudo systemctl restart stream-manager.service
```

### Check System Resources

```bash
ssh -i stream-manager-key.pem ubuntu@18.143.116.55 "df -h && free -m && top -b -n 1"
```

## Complete Reset

If you need to start over, you can reset the application:

```bash
ssh -i stream-manager-key.pem ubuntu@18.143.116.55

# Stop services
sudo systemctl stop stream-manager.service
sudo systemctl stop nginx
sudo systemctl stop postgresql

# Remove application
sudo rm -rf /opt/stream-manager

# Reset PostgreSQL
sudo -u postgres psql -c "DROP DATABASE stream_manager;"
sudo -u postgres psql -c "DROP USER stream_manager;"

# Then re-run the installation scripts
exit

./ec2-direct-install.sh --key stream-manager-key.pem --host 18.143.116.55 --username ubuntu
./deploy-app-to-ec2.sh --key stream-manager-key.pem --host 18.143.116.55 --username ubuntu --source .
```