<?php
$title = $server ? 'Edit RTMP Server' : 'Add RTMP Server';
include ROOT_PATH . '/views/layouts/header.php';

// Parse server settings
$settings = ($server && isset($server['settings'])) ? json_decode($server['settings'], true) : [];
$rtmpPath = $settings['rtmp_path'] ?? 'live';
$hlsEnabled = $settings['hls_enabled'] ?? true;
$recordingEnabled = $settings['recording_enabled'] ?? false;
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?= $title ?></h1>
        <a href="/rtmp" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Servers
        </a>
    </div>
    
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] === 'error' ? 'danger' : $_SESSION['flash']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form action="/rtmp/save<?= $server ? '/' . $server['id'] : '' ?>" method="post">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Server Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $server ? htmlspecialchars($server['name']) : '' ?>" required>
                        <div class="form-text">A descriptive name for this RTMP server</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="host" class="form-label">Host</label>
                        <input type="text" class="form-control" id="host" name="host" value="<?= $server ? htmlspecialchars($server['host']) : 'localhost' ?>" required>
                        <div class="form-text">Hostname or IP address of the RTMP server</div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="port" class="form-label">RTMP Port</label>
                        <input type="number" class="form-control" id="port" name="port" value="<?= $server ? intval($server['port']) : 1935 ?>" min="1" max="65535" required>
                        <div class="form-text">Default RTMP port is 1935</div>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="rtmp_path" class="form-label">RTMP Path</label>
                        <input type="text" class="form-control" id="rtmp_path" name="rtmp_path" value="<?= htmlspecialchars($rtmpPath) ?>">
                        <div class="form-text">Application name for RTMP (usually "live")</div>
                    </div>
                    
                    <div class="col-md-4 d-flex align-items-end">
                        <div class="form-check me-4">
                            <input class="form-check-input" type="checkbox" id="hls_enabled" name="hls_enabled" <?= $hlsEnabled ? 'checked' : '' ?>>
                            <label class="form-check-label" for="hls_enabled">
                                Enable HLS
                            </label>
                        </div>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="recording_enabled" name="recording_enabled" <?= $recordingEnabled ? 'checked' : '' ?>>
                            <label class="form-check-label" for="recording_enabled">
                                Enable Recording
                            </label>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <div class="d-flex justify-content-between">
                    <a href="/rtmp" class="btn btn-outline-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Server Configuration</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header">
            <h5 class="card-title mb-0">RTMP Server Configuration Guide</h5>
        </div>
        <div class="card-body">
            <h6>Local Server</h6>
            <p>For testing or development, you can run the RTMP server on the same machine as the web application. Use "localhost" or "127.0.0.1" as the host.</p>
            
            <h6>Remote Server</h6>
            <p>For production, it's recommended to run the RTMP server on a dedicated machine. Enter the hostname or IP address of your remote server.</p>
            
            <h6>Port Configuration</h6>
            <p>The default RTMP port is 1935. You may need to change this if:</p>
            <ul>
                <li>The port is already in use by another application</li>
                <li>Your firewall blocks the default port</li>
                <li>You want to run multiple RTMP servers on the same machine</li>
            </ul>
            
            <h6>HLS Streaming</h6>
            <p>HTTP Live Streaming (HLS) converts RTMP streams to a format that can be played in web browsers without plugins. Enabling HLS is recommended for better compatibility.</p>
            
            <h6>Stream Recording</h6>
            <p>When enabled, the RTMP server will save live streams to disk. This allows viewers to watch streams after they have ended. Note that recording requires sufficient disk space.</p>
        </div>
    </div>
</div>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>