<?php
$title = 'RTMP Server Management';
include ROOT_PATH . '/views/layouts/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>RTMP Server Management</h1>
        <a href="/rtmp/config" class="btn btn-primary">
            <i class="bi bi-plus"></i> Add New Server
        </a>
    </div>
    
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] === 'error' ? 'danger' : $_SESSION['flash']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <?php if (empty($servers)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-server text-muted" style="font-size: 48px;"></i>
                    <h3 class="mt-3">No RTMP Servers</h3>
                    <p class="text-muted">You don't have any RTMP servers configured yet.</p>
                    <a href="/rtmp/config" class="btn btn-primary">
                        <i class="bi bi-plus"></i> Add New Server
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Host</th>
                                <th>Port</th>
                                <th>Status</th>
                                <th>Last Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($servers as $server): ?>
                                <?php
                                    $settings = json_decode($server['settings'], true) ?? [];
                                    $metrics = json_decode($server['metrics'], true) ?? [];
                                    $status = $server['status'] ?? 'unknown';
                                    $statusClass = [
                                        'online' => 'success',
                                        'offline' => 'danger',
                                        'unknown' => 'secondary'
                                    ][$status] ?? 'secondary';
                                ?>
                                <tr data-server-id="<?= $server['id'] ?>">
                                    <td><?= htmlspecialchars($server['name']) ?></td>
                                    <td><?= htmlspecialchars($server['host']) ?></td>
                                    <td><?= htmlspecialchars($server['port']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $statusClass ?> server-status">
                                            <?= ucfirst($status) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= isset($metrics['updated_at']) ? date('M d, Y H:i', strtotime($metrics['updated_at'])) : 'Never' ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="/rtmp/config/<?= $server['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-gear"></i> Configure
                                            </a>
                                            <a href="/rtmp/install/<?= $server['id'] ?>" class="btn btn-sm btn-outline-success">
                                                <i class="bi bi-box"></i> Install
                                            </a>
                                            <button class="btn btn-sm btn-outline-info check-status" data-server-id="<?= $server['id'] ?>">
                                                <i class="bi bi-arrow-repeat"></i> Check Status
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header">
            <h5 class="card-title mb-0">About RTMP Servers</h5>
        </div>
        <div class="card-body">
            <p>RTMP (Real-Time Messaging Protocol) servers are used for live streaming video content. They receive video streams from broadcasters and make them available to viewers.</p>
            
            <h6>Key Features:</h6>
            <ul>
                <li><strong>Live Streaming</strong> - Stream video content in real-time</li>
                <li><strong>Low Latency</strong> - Minimize delay between broadcaster and viewers</li>
                <li><strong>HLS Support</strong> - Convert RTMP streams to HLS for broader compatibility</li>
                <li><strong>Recording</strong> - Save live streams for later viewing</li>
            </ul>
            
            <h6>Setup Options:</h6>
            <ul>
                <li><strong>Local Server</strong> - Install the RTMP server on the same machine as the web application</li>
                <li><strong>Remote Server</strong> - Install the RTMP server on a separate machine (recommended for production)</li>
                <li><strong>Cloud Server</strong> - Use a cloud-based virtual machine for hosting your RTMP server</li>
            </ul>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check status buttons
    const checkStatusButtons = document.querySelectorAll('.check-status');
    checkStatusButtons.forEach(button => {
        button.addEventListener('click', function() {
            const serverId = this.getAttribute('data-server-id');
            const row = document.querySelector(`tr[data-server-id="${serverId}"]`);
            const statusBadge = row.querySelector('.server-status');
            
            // Change button text
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="bi bi-arrow-repeat"></i> Checking...';
            this.disabled = true;
            
            // Make AJAX request to check status
            fetch(`/rtmp/status/${serverId}`)
                .then(response => response.json())
                .then(data => {
                    // Update status badge
                    if (data.success) {
                        const status = data.status.online ? 'online' : 'offline';
                        const statusClass = status === 'online' ? 'success' : 'danger';
                        
                        statusBadge.className = `badge bg-${statusClass} server-status`;
                        statusBadge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
                    }
                })
                .catch(error => {
                    console.error('Error checking server status:', error);
                })
                .finally(() => {
                    // Restore button text and enable
                    this.innerHTML = originalText;
                    this.disabled = false;
                });
        });
    });
});
</script>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>