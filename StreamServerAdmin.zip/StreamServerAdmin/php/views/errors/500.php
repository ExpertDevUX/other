<div class="container text-center py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="display-1 fw-bold text-danger">500</h1>
            <h2 class="mb-4">Server Error</h2>
            <p class="lead mb-3">Something went wrong on our servers.</p>
            
            <?php if (isset($error) && !empty($error)): ?>
                <div class="alert alert-danger mb-4">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
            
            <p class="mb-5">Our technical team has been notified. Please try again later or contact support if the problem persists.</p>
            
            <div class="d-flex justify-content-center gap-3">
                <a href="/" class="btn btn-primary">
                    <i class="bi bi-house-door"></i> Go Home
                </a>
                <a href="javascript:history.back()" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Go Back
                </a>
            </div>
        </div>
    </div>
</div>