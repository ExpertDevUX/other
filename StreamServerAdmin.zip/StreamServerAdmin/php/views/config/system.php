<?php
$title = 'System Configuration';
include ROOT_PATH . '/views/layouts/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>System Configuration</h1>
        <div>
            <button id="reset-config" class="btn btn-outline-warning me-2">
                <i class="bi bi-arrow-counterclockwise"></i> Reset to Default
            </button>
            <a href="/dashboard" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-<?= $_SESSION['flash']['type'] === 'error' ? 'danger' : $_SESSION['flash']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="list-group">
                <a href="/config/interface" class="list-group-item list-group-item-action">
                    <i class="bi bi-brush me-2"></i> Interface
                </a>
                <a href="/config/system" class="list-group-item list-group-item-action active">
                    <i class="bi bi-gear me-2"></i> System
                </a>
                <a href="/config/rtmp" class="list-group-item list-group-item-action">
                    <i class="bi bi-camera-video me-2"></i> RTMP
                </a>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">System Info</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            PHP Version
                            <span class="badge bg-primary"><?= phpversion() ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Database Type
                            <span class="badge bg-primary"><?= $this->db->getType() ?? 'SQLite' ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Operating System
                            <span class="badge bg-primary"><?= php_uname('s') ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Server Software
                            <span class="badge bg-primary"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-body">
                    <form action="/config/save-system" method="post">
                        <h4 class="mb-3">Application Settings</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="debug_mode" name="debug_mode" <?= $config['debug_mode'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="debug_mode">Debug Mode</label>
                                    <div class="form-text">Enable detailed error messages</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="log_level" class="form-label">Log Level</label>
                                    <select class="form-select" id="log_level" name="log_level">
                                        <?php foreach ($logLevels as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['log_level'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">Determines which messages are recorded in logs</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" <?= $config['maintenance_mode'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="maintenance_mode">Maintenance Mode</label>
                                    <div class="form-text">Make the site temporarily unavailable to visitors</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="maintenance_message" class="form-label">Maintenance Message</label>
                                    <textarea class="form-control" id="maintenance_message" name="maintenance_message" rows="2"><?= htmlspecialchars($config['maintenance_message']) ?></textarea>
                                    <div class="form-text">Message shown during maintenance</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">Performance & Caching</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="cache_enabled" name="cache_enabled" <?= $config['cache_enabled'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="cache_enabled">Enable Caching</label>
                                    <div class="form-text">Improve performance by caching data</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cache_lifetime" class="form-label">Cache Lifetime (seconds)</label>
                                    <input type="number" class="form-control" id="cache_lifetime" name="cache_lifetime" value="<?= intval($config['cache_lifetime']) ?>" min="60" max="86400">
                                    <div class="form-text">How long cached items are stored</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="session_lifetime" class="form-label">Session Lifetime (seconds)</label>
                                    <input type="number" class="form-control" id="session_lifetime" name="session_lifetime" value="<?= intval($config['session_lifetime']) ?>" min="300" max="2592000">
                                    <div class="form-text">How long user sessions remain active</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="timezone" class="form-label">Timezone</label>
                                    <select class="form-select" id="timezone" name="timezone">
                                        <?php foreach ($timezones as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $config['timezone'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">Server timezone for dates and times</div>
                                </div>
                            </div>
                        </div>
                        
                        <h4 class="mb-3">File Uploads</h4>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="max_upload_size" class="form-label">Max Upload Size (MB)</label>
                                    <input type="number" class="form-control" id="max_upload_size" name="max_upload_size" value="<?= intval($config['max_upload_size']) ?>" min="1" max="1000">
                                    <div class="form-text">Maximum file size for uploads</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="allowed_file_types" class="form-label">Allowed File Types</label>
                                    <input type="text" class="form-control" id="allowed_file_types" name="allowed_file_types" value="<?= htmlspecialchars($config['allowed_file_types']) ?>">
                                    <div class="form-text">Comma-separated list of allowed file extensions</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <button type="reset" class="btn btn-outline-secondary me-2">Reset Form</button>
                            <button type="submit" class="btn btn-primary">Save Configuration</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">System Maintenance</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="d-grid">
                                <button class="btn btn-outline-primary" id="btn-clear-cache">
                                    <i class="bi bi-trash me-2"></i> Clear Cache
                                </button>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="d-grid">
                                <a href="/config/export" class="btn btn-outline-success">
                                    <i class="bi bi-download me-2"></i> Export Configuration
                                </a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="d-grid">
                                <button class="btn btn-outline-secondary" id="btn-import-config">
                                    <i class="bi bi-upload me-2"></i> Import Configuration
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Reset configuration button
    document.getElementById('reset-config').addEventListener('click', function() {
        if (confirm('Are you sure you want to reset to default settings? This cannot be undone.')) {
            window.location.href = '/config/reset/system';
        }
    });
    
    // Clear cache button
    document.getElementById('btn-clear-cache').addEventListener('click', function() {
        if (confirm('Are you sure you want to clear the application cache?')) {
            fetch('/config/clear-cache', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Cache cleared successfully');
                    } else {
                        alert('Failed to clear cache: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('An error occurred: ' + error);
                });
        }
    });
    
    // Import configuration button
    document.getElementById('btn-import-config').addEventListener('click', function() {
        // This would typically open a file dialog or show a modal
        alert('Feature not implemented. In a real application, this would open a file upload dialog.');
    });
});
</script>

<?php include ROOT_PATH . '/views/layouts/footer.php'; ?>