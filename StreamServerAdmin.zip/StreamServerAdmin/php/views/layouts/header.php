<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? $title . ' - ' : '' ?><?= $GLOBALS['SITE_NAME'] ?? 'Stream Manager' ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="/css/style.css" rel="stylesheet">
    
    <!-- Dynamic Custom CSS -->
    <link href="/css/custom.css" rel="stylesheet">
    
    <?php if ($GLOBALS['RTMP_CONFIG']['low_latency_mode'] ?? false): ?>
    <!-- Low latency settings for video playback -->
    <script>
        window.LOW_LATENCY_MODE = true;
    </script>
    <?php endif; ?>
</head>
<body>
    <?php
    // Get interface configuration
    $interfaceConfig = \App\Core\ConfigManager::get('interface');
    $logoUrl = $interfaceConfig['logo_url'] ?? '';
    ?>
    
    <nav class="navbar navbar-expand-lg <?= ($interfaceConfig['theme'] ?? '') === 'dark' ? 'navbar-dark bg-dark' : 'navbar-dark bg-dark' ?>">
        <div class="container">
            <a class="navbar-brand" href="/">
                <?php if (!empty($logoUrl)): ?>
                    <img src="<?= htmlspecialchars($logoUrl) ?>" alt="Logo" height="30" class="me-2">
                <?php endif; ?>
                <?= $GLOBALS['SITE_NAME'] ?? 'Stream Manager' ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <?php if (isset($_SESSION['user'])): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/dashboard') === 0 ? 'active' : '' ?>" href="/dashboard">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/streams') === 0 ? 'active' : '' ?>" href="/streams">Streams</a>
                        </li>
                        
                        <?php if ($_SESSION['user']['role'] === 'admin'): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle <?= strpos($_SERVER['REQUEST_URI'], '/rtmp') === 0 || strpos($_SERVER['REQUEST_URI'], '/servers') === 0 ? 'active' : '' ?>" href="#" id="serverDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Servers
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="serverDropdown">
                                    <li><a class="dropdown-item" href="/rtmp">RTMP Servers</a></li>
                                    <li><a class="dropdown-item" href="/servers">All Servers</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle <?= strpos($_SERVER['REQUEST_URI'], '/config') === 0 || strpos($_SERVER['REQUEST_URI'], '/settings') === 0 || strpos($_SERVER['REQUEST_URI'], '/integrations') === 0 ? 'active' : '' ?>" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Admin
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="adminDropdown">
                                    <li><a class="dropdown-item" href="/config/interface">Configuration</a></li>
                                    <li><a class="dropdown-item" href="/settings">Settings</a></li>
                                    <li><a class="dropdown-item" href="/integrations">Integrations</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $_SERVER['REQUEST_URI'] === '/' ? 'active' : '' ?>" href="/">Home</a>
                        </li>
                    <?php endif; ?>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?= htmlspecialchars($_SESSION['user']['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="/profile">Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/logout">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $_SERVER['REQUEST_URI'] === '/login' ? 'active' : '' ?>" href="/login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $_SERVER['REQUEST_URI'] === '/register' ? 'active' : '' ?>" href="/register">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->