<?php
namespace App\Controllers;

use App\Models\Server;
use App\Core\Application;

/**
 * RTMP Server Controller
 * 
 * Handles RTMP server configuration and management
 */
class RtmpController
{
    private $serverModel;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->serverModel = new Server();
    }
    
    /**
     * Display server management page
     */
    public function index($params)
    {
        // Get all RTMP servers
        $servers = $this->serverModel->getByType('rtmp');
        
        // Render the view
        include ROOT_PATH . '/views/rtmp/index.php';
    }
    
    /**
     * Display server configuration form
     */
    public function configForm($params)
    {
        // Check if server ID is provided
        $serverId = $params['id'] ?? null;
        $server = null;
        
        if ($serverId) {
            // Edit existing server
            $server = $this->serverModel->find($serverId);
            
            if (!$server) {
                // Server not found, redirect to servers list
                header('Location: /rtmp');
                exit;
            }
        }
        
        // Render the view
        include ROOT_PATH . '/views/rtmp/config-form.php';
    }
    
    /**
     * Save server configuration
     */
    public function saveConfig($params)
    {
        // Get POST data
        $serverId = $params['id'] ?? null;
        $name = $_POST['name'] ?? '';
        $host = $_POST['host'] ?? '';
        $port = intval($_POST['port'] ?? 1935);
        $rtmpPath = $_POST['rtmp_path'] ?? 'live';
        $hlsEnabled = isset($_POST['hls_enabled']) ? 1 : 0;
        $recordingEnabled = isset($_POST['recording_enabled']) ? 1 : 0;
        
        // Validate input
        if (empty($name) || empty($host)) {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Server name and host are required'
            ];
            
            // Redirect back to form
            header('Location: /rtmp/config' . ($serverId ? "/{$serverId}" : ''));
            exit;
        }
        
        // Prepare server data
        $serverData = [
            'name' => $name,
            'host' => $host,
            'port' => $port,
            'type' => 'rtmp',
            'settings' => json_encode([
                'rtmp_path' => $rtmpPath,
                'hls_enabled' => $hlsEnabled,
                'recording_enabled' => $recordingEnabled
            ])
        ];
        
        // Save server configuration
        if ($serverId) {
            // Update existing server
            $this->serverModel->update($serverId, $serverData);
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'Server configuration updated successfully'
            ];
        } else {
            // Create new server
            $this->serverModel->create($serverData);
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'Server created successfully'
            ];
        }
        
        // Redirect to servers list
        header('Location: /rtmp');
        exit;
    }
    
    /**
     * Install RTMP server
     */
    public function install($params)
    {
        // Get server ID
        $serverId = $params['id'] ?? null;
        
        if (!$serverId) {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Server ID is required'
            ];
            
            // Redirect to servers list
            header('Location: /rtmp');
            exit;
        }
        
        // Get server details
        $server = $this->serverModel->find($serverId);
        
        if (!$server) {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Server not found'
            ];
            
            // Redirect to servers list
            header('Location: /rtmp');
            exit;
        }
        
        // Check if server is localhost
        $isLocalhost = in_array($server['host'], ['localhost', '127.0.0.1']);
        
        if ($isLocalhost) {
            // For localhost, we can run the installation script directly
            $result = $this->installLocalRtmpServer($server);
        } else {
            // For remote servers, we need to generate installation instructions
            $result = $this->generateRemoteInstallInstructions($server);
        }
        
        // Pass result to the view
        include ROOT_PATH . '/views/rtmp/install-result.php';
    }
    
    /**
     * Install RTMP server on localhost
     */
    private function installLocalRtmpServer($server)
    {
        // Check if rtmp-install.sh exists
        $installScript = ROOT_PATH . '/rtmp-install.sh';
        
        if (!file_exists($installScript)) {
            return [
                'success' => false,
                'message' => 'Installation script not found',
                'details' => 'The rtmp-install.sh script is missing'
            ];
        }
        
        // Make sure the script is executable
        chmod($installScript, 0755);
        
        // Get settings
        $settings = json_decode($server['settings'], true) ?? [];
        $rtmpPort = $server['port'] ?? 1935;
        $hlsEnabled = $settings['hls_enabled'] ?? true;
        
        // Prepare command
        $command = "sudo {$installScript} --rtmp-port {$rtmpPort}";
        
        // Execute the command in the background
        $outputFile = ROOT_PATH . '/storage/logs/rtmp-install.log';
        exec("{$command} > {$outputFile} 2>&1 &");
        
        return [
            'success' => true,
            'message' => 'RTMP server installation started',
            'details' => 'The installation is running in the background. Check the log file for progress.'
        ];
    }
    
    /**
     * Generate installation instructions for remote server
     */
    private function generateRemoteInstallInstructions($server)
    {
        // Get installation script content
        $installScript = ROOT_PATH . '/rtmp-install.sh';
        
        if (!file_exists($installScript)) {
            return [
                'success' => false,
                'message' => 'Installation script not found',
                'details' => 'The rtmp-install.sh script is missing'
            ];
        }
        
        // Get settings
        $settings = json_decode($server['settings'], true) ?? [];
        $rtmpPort = $server['port'] ?? 1935;
        $hlsEnabled = $settings['hls_enabled'] ?? true;
        
        // Generate command for remote installation
        $command = "sudo ./rtmp-install.sh --rtmp-port {$rtmpPort}";
        
        return [
            'success' => true,
            'message' => 'Remote installation instructions generated',
            'details' => 'Follow these steps to install the RTMP server on your remote host',
            'script' => file_get_contents($installScript),
            'command' => $command,
            'server' => $server
        ];
    }
    
    /**
     * Check server status
     */
    public function status($params)
    {
        // Get server ID
        $serverId = $params['id'] ?? null;
        
        if (!$serverId) {
            // Return error response
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Server ID is required'
            ]);
            exit;
        }
        
        // Get server details
        $server = $this->serverModel->find($serverId);
        
        if (!$server) {
            // Return error response
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Server not found'
            ]);
            exit;
        }
        
        // Check server status
        $status = $this->checkServerStatus($server);
        
        // Update server status in database
        $this->serverModel->update($serverId, [
            'status' => $status['online'] ? 'online' : 'offline',
            'metrics' => json_encode($status)
        ]);
        
        // Return status as JSON
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'server' => $server,
            'status' => $status
        ]);
        exit;
    }
    
    /**
     * Check RTMP server status
     */
    private function checkServerStatus($server)
    {
        $host = $server['host'];
        $port = $server['port'];
        $isLocalhost = in_array($host, ['localhost', '127.0.0.1']);
        
        // Default status
        $status = [
            'online' => false,
            'cpu' => 0,
            'memory' => 0,
            'uptime' => 0,
            'streams' => [],
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Check if port is open
        if ($isLocalhost) {
            // For localhost, check if the service is running
            exec("ps aux | grep nginx | grep -v grep", $output, $returnCode);
            $status['online'] = ($returnCode === 0);
            
            // Get CPU and memory usage if online
            if ($status['online']) {
                exec("ps aux | grep nginx | grep -v grep | awk '{print $3}'", $cpuOutput);
                exec("ps aux | grep nginx | grep -v grep | awk '{print $4}'", $memOutput);
                
                $status['cpu'] = !empty($cpuOutput) ? floatval($cpuOutput[0]) : 0;
                $status['memory'] = !empty($memOutput) ? floatval($memOutput[0]) : 0;
                
                // Get uptime
                exec("ps -o etimes= -p $(pgrep -f 'nginx: master')", $uptimeOutput);
                $status['uptime'] = !empty($uptimeOutput) ? intval($uptimeOutput[0]) : 0;
            }
        } else {
            // For remote server, try to connect to the port
            $connection = @fsockopen($host, $port, $errno, $errstr, 5);
            $status['online'] = $connection !== false;
            
            if ($connection) {
                fclose($connection);
                
                // Try to get status from the HTTP status page
                $statusUrl = "http://{$host}/status";
                $statusContent = @file_get_contents($statusUrl);
                
                if ($statusContent !== false) {
                    // Parse status information if available
                    if (preg_match('/Online/i', $statusContent)) {
                        $status['online'] = true;
                    }
                }
            }
        }
        
        return $status;
    }
}