<?php
namespace App\Controllers;

use App\Core\Application;
use App\Models\Config;

/**
 * Config Controller
 * 
 * Handles application configuration settings
 */
class ConfigController
{
    private $configModel;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->configModel = new Config();
    }
    
    /**
     * Display interface configuration page
     */
    public function interface($params)
    {
        // Get current configuration
        $config = $this->configModel->getConfiguration('interface');
        
        // Parse configuration
        if (!$config) {
            // Set default config if none exists
            $config = [
                'site_name' => 'Stream Manager',
                'theme' => 'light',
                'logo_url' => '',
                'primary_color' => '#0d6efd',
                'secondary_color' => '#6c757d',
                'show_footer' => true,
                'dashboard_layout' => 'cards',
                'stream_preview_size' => 'medium',
                'enable_animations' => true,
                'custom_css' => ''
            ];
            
            // Save default configuration
            $this->configModel->saveConfiguration('interface', $config);
        } else {
            $config = json_decode($config['value'], true);
        }
        
        // Available themes
        $themes = [
            'light' => 'Light Theme',
            'dark' => 'Dark Theme',
            'auto' => 'System Default (Auto)',
            'custom' => 'Custom Theme'
        ];
        
        // Available dashboard layouts
        $dashboardLayouts = [
            'cards' => 'Card Layout (Default)',
            'list' => 'List Layout',
            'compact' => 'Compact Layout',
            'grid' => 'Grid Layout'
        ];
        
        // Stream preview sizes
        $previewSizes = [
            'small' => 'Small (240p)',
            'medium' => 'Medium (360p)',
            'large' => 'Large (720p)',
            'full' => 'Full Size (Original)'
        ];
        
        // Render the view
        include ROOT_PATH . '/views/config/interface.php';
    }
    
    /**
     * Save interface configuration
     */
    public function saveInterface()
    {
        // Get POST data
        $siteName = $_POST['site_name'] ?? 'Stream Manager';
        $theme = $_POST['theme'] ?? 'light';
        $logoUrl = $_POST['logo_url'] ?? '';
        $primaryColor = $_POST['primary_color'] ?? '#0d6efd';
        $secondaryColor = $_POST['secondary_color'] ?? '#6c757d';
        $showFooter = isset($_POST['show_footer']) ? true : false;
        $dashboardLayout = $_POST['dashboard_layout'] ?? 'cards';
        $streamPreviewSize = $_POST['stream_preview_size'] ?? 'medium';
        $enableAnimations = isset($_POST['enable_animations']) ? true : false;
        $customCss = $_POST['custom_css'] ?? '';
        
        // Validate input
        if (empty($siteName)) {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Site name is required'
            ];
            
            // Redirect back to form
            header('Location: /config/interface');
            exit;
        }
        
        // Validate colors
        if (!preg_match('/#([a-f0-9]{3}){1,2}\b/i', $primaryColor)) {
            $primaryColor = '#0d6efd';
        }
        
        if (!preg_match('/#([a-f0-9]{3}){1,2}\b/i', $secondaryColor)) {
            $secondaryColor = '#6c757d';
        }
        
        // Prepare configuration data
        $config = [
            'site_name' => $siteName,
            'theme' => $theme,
            'logo_url' => $logoUrl,
            'primary_color' => $primaryColor,
            'secondary_color' => $secondaryColor,
            'show_footer' => $showFooter,
            'dashboard_layout' => $dashboardLayout,
            'stream_preview_size' => $streamPreviewSize,
            'enable_animations' => $enableAnimations,
            'custom_css' => $customCss
        ];
        
        // Save configuration
        $result = $this->configModel->saveConfiguration('interface', $config);
        
        if ($result) {
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'Interface configuration saved successfully'
            ];
        } else {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Failed to save interface configuration'
            ];
        }
        
        // Redirect back to form
        header('Location: /config/interface');
        exit;
    }
    
    /**
     * Display system configuration page
     */
    public function system($params)
    {
        // Get current configuration
        $config = $this->configModel->getConfiguration('system');
        
        // Parse configuration
        if (!$config) {
            // Set default config if none exists
            $config = [
                'debug_mode' => false,
                'log_level' => 'error',
                'maintenance_mode' => false,
                'maintenance_message' => 'The site is currently under maintenance. Please check back later.',
                'cache_enabled' => true,
                'cache_lifetime' => 3600,
                'session_lifetime' => 86400,
                'max_upload_size' => 100, // MB
                'allowed_file_types' => 'jpg,jpeg,png,gif,mp4,webm',
                'timezone' => 'UTC'
            ];
            
            // Save default configuration
            $this->configModel->saveConfiguration('system', $config);
        } else {
            $config = json_decode($config['value'], true);
        }
        
        // Available log levels
        $logLevels = [
            'debug' => 'Debug (All Messages)',
            'info' => 'Info (Informational Messages)',
            'warning' => 'Warning (Warning Messages)',
            'error' => 'Error (Error Messages Only)',
            'critical' => 'Critical (Critical Errors Only)'
        ];
        
        // Get all available timezones
        $timezones = [];
        $timezonesRaw = DateTimeZone::listIdentifiers();
        foreach ($timezonesRaw as $tz) {
            $timezones[$tz] = str_replace('_', ' ', $tz);
        }
        
        // Render the view
        include ROOT_PATH . '/views/config/system.php';
    }
    
    /**
     * Save system configuration
     */
    public function saveSystem()
    {
        // Get POST data
        $debugMode = isset($_POST['debug_mode']) ? true : false;
        $logLevel = $_POST['log_level'] ?? 'error';
        $maintenanceMode = isset($_POST['maintenance_mode']) ? true : false;
        $maintenanceMessage = $_POST['maintenance_message'] ?? '';
        $cacheEnabled = isset($_POST['cache_enabled']) ? true : false;
        $cacheLifetime = intval($_POST['cache_lifetime'] ?? 3600);
        $sessionLifetime = intval($_POST['session_lifetime'] ?? 86400);
        $maxUploadSize = intval($_POST['max_upload_size'] ?? 100);
        $allowedFileTypes = $_POST['allowed_file_types'] ?? 'jpg,jpeg,png,gif,mp4,webm';
        $timezone = $_POST['timezone'] ?? 'UTC';
        
        // Validate input
        if ($cacheLifetime < 0) {
            $cacheLifetime = 3600;
        }
        
        if ($sessionLifetime < 0) {
            $sessionLifetime = 86400;
        }
        
        if ($maxUploadSize < 1 || $maxUploadSize > 1000) {
            $maxUploadSize = 100;
        }
        
        // Prepare configuration data
        $config = [
            'debug_mode' => $debugMode,
            'log_level' => $logLevel,
            'maintenance_mode' => $maintenanceMode,
            'maintenance_message' => $maintenanceMessage,
            'cache_enabled' => $cacheEnabled,
            'cache_lifetime' => $cacheLifetime,
            'session_lifetime' => $sessionLifetime,
            'max_upload_size' => $maxUploadSize,
            'allowed_file_types' => $allowedFileTypes,
            'timezone' => $timezone
        ];
        
        // Save configuration
        $result = $this->configModel->saveConfiguration('system', $config);
        
        if ($result) {
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'System configuration saved successfully'
            ];
        } else {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Failed to save system configuration'
            ];
        }
        
        // Redirect back to form
        header('Location: /config/system');
        exit;
    }
    
    /**
     * Display RTMP configuration page
     */
    public function rtmp($params)
    {
        // Get current configuration
        $config = $this->configModel->getConfiguration('rtmp');
        
        // Parse configuration
        if (!$config) {
            // Set default config if none exists
            $config = [
                'default_rtmp_port' => 1935,
                'hls_enabled' => true,
                'hls_fragment_duration' => 2,
                'hls_playlist_length' => 30,
                'recording_enabled' => false,
                'recording_path' => '/var/www/html/recordings',
                'recording_format' => 'flv',
                'low_latency_mode' => false,
                'authentication_required' => true,
                'authentication_token_lifetime' => 3600
            ];
            
            // Save default configuration
            $this->configModel->saveConfiguration('rtmp', $config);
        } else {
            $config = json_decode($config['value'], true);
        }
        
        // Recording formats
        $recordingFormats = [
            'flv' => 'FLV (Flash Video)',
            'mp4' => 'MP4 (MPEG-4)',
            'ts' => 'TS (MPEG Transport Stream)'
        ];
        
        // Render the view
        include ROOT_PATH . '/views/config/rtmp.php';
    }
    
    /**
     * Save RTMP configuration
     */
    public function saveRtmp()
    {
        // Get POST data
        $defaultRtmpPort = intval($_POST['default_rtmp_port'] ?? 1935);
        $hlsEnabled = isset($_POST['hls_enabled']) ? true : false;
        $hlsFragmentDuration = intval($_POST['hls_fragment_duration'] ?? 2);
        $hlsPlaylistLength = intval($_POST['hls_playlist_length'] ?? 30);
        $recordingEnabled = isset($_POST['recording_enabled']) ? true : false;
        $recordingPath = $_POST['recording_path'] ?? '/var/www/html/recordings';
        $recordingFormat = $_POST['recording_format'] ?? 'flv';
        $lowLatencyMode = isset($_POST['low_latency_mode']) ? true : false;
        $authenticationRequired = isset($_POST['authentication_required']) ? true : false;
        $authenticationTokenLifetime = intval($_POST['authentication_token_lifetime'] ?? 3600);
        
        // Validate input
        if ($defaultRtmpPort < 1 || $defaultRtmpPort > 65535) {
            $defaultRtmpPort = 1935;
        }
        
        if ($hlsFragmentDuration < 1 || $hlsFragmentDuration > 10) {
            $hlsFragmentDuration = 2;
        }
        
        if ($hlsPlaylistLength < 10 || $hlsPlaylistLength > 300) {
            $hlsPlaylistLength = 30;
        }
        
        if ($authenticationTokenLifetime < 60 || $authenticationTokenLifetime > 86400) {
            $authenticationTokenLifetime = 3600;
        }
        
        // Prepare configuration data
        $config = [
            'default_rtmp_port' => $defaultRtmpPort,
            'hls_enabled' => $hlsEnabled,
            'hls_fragment_duration' => $hlsFragmentDuration,
            'hls_playlist_length' => $hlsPlaylistLength,
            'recording_enabled' => $recordingEnabled,
            'recording_path' => $recordingPath,
            'recording_format' => $recordingFormat,
            'low_latency_mode' => $lowLatencyMode,
            'authentication_required' => $authenticationRequired,
            'authentication_token_lifetime' => $authenticationTokenLifetime
        ];
        
        // Save configuration
        $result = $this->configModel->saveConfiguration('rtmp', $config);
        
        if ($result) {
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'RTMP configuration saved successfully'
            ];
        } else {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => 'Failed to save RTMP configuration'
            ];
        }
        
        // Redirect back to form
        header('Location: /config/rtmp');
        exit;
    }
}