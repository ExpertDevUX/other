<?php
// Define constants
define('ROOT_PATH', dirname(__DIR__));

// Autoload classes
spl_autoload_register(function($class) {
    // Convert namespace to file path
    $class = str_replace('\\', '/', $class);
    $file = ROOT_PATH . '/' . $class . '.php';
    
    if (file_exists($file)) {
        require_once $file;
    }
});

// Load environment variables
if (file_exists(ROOT_PATH . '/.env')) {
    $lines = file(ROOT_PATH . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            
            // Remove quotes if present
            if (preg_match('/^"(.+)"$/', $value, $matches)) {
                $value = $matches[1];
            } elseif (preg_match("/^'(.+)'$/", $value, $matches)) {
                $value = $matches[1];
            }
            
            $_ENV[$key] = $value;
            $_SERVER[$key] = $value;
            putenv("$key=$value");
        }
    }
}

// Start session
session_start();

// Load configuration manager and initialize
\App\Core\ConfigManager::init();

// Create storage directories if they don't exist
$storageDirs = [
    ROOT_PATH . '/storage',
    ROOT_PATH . '/storage/logs',
    ROOT_PATH . '/storage/cache',
    ROOT_PATH . '/storage/uploads',
    ROOT_PATH . '/storage/recordings'
];

foreach ($storageDirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Set error handling based on debug mode
if ($GLOBALS['DEBUG_MODE'] ?? false) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ERROR | E_PARSE);
    ini_set('display_errors', 0);
    
    // Custom error handler for production
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        // Log error
        $logFile = ROOT_PATH . '/storage/logs/error.log';
        $errorDate = date('Y-m-d H:i:s');
        $errorMessage = "[$errorDate] Error $errno: $errstr in $errfile on line $errline\n";
        file_put_contents($logFile, $errorMessage, FILE_APPEND);
        
        // Only display generic error to user for serious errors
        if ($errno == E_ERROR || $errno == E_PARSE || $errno == E_CORE_ERROR) {
            include ROOT_PATH . '/views/errors/error.php';
            exit;
        }
        
        return true;
    });
}

// Create the application instance
$app = new \App\Core\Application();