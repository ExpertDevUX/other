<?php
/**
 * Environment Variables
 */

// Load .env file if it exists
if (file_exists(BASE_PATH . '/.env')) {
    $lines = file(BASE_PATH . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        // Skip comments
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        // Parse the line
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        // Remove quotes if present
        if (strpos($value, '"') === 0 && strrpos($value, '"') === strlen($value) - 1) {
            $value = substr($value, 1, -1);
        } elseif (strpos($value, "'") === 0 && strrpos($value, "'") === strlen($value) - 1) {
            $value = substr($value, 1, -1);
        }
        
        // Set the environment variable
        $_ENV[$name] = $value;
        $_SERVER[$name] = $value;
    }
}

// Set default environment variables if not set
$_ENV['APP_NAME'] = $_ENV['APP_NAME'] ?? 'Stream Manager';
$_ENV['APP_URL'] = $_ENV['APP_URL'] ?? 'http://localhost';
$_ENV['DEBUG'] = $_ENV['DEBUG'] ?? 'false';

// Database
$_ENV['DB_HOST'] = $_ENV['DB_HOST'] ?? 'localhost';
$_ENV['DB_PORT'] = $_ENV['DB_PORT'] ?? '5432';
$_ENV['DB_NAME'] = $_ENV['DB_NAME'] ?? 'stream_manager';
$_ENV['DB_USER'] = $_ENV['DB_USER'] ?? 'stream_manager';
$_ENV['DB_PASS'] = $_ENV['DB_PASS'] ?? 'stream_manager_pwd';

// RTMP Server
$_ENV['RTMP_HOST'] = $_ENV['RTMP_HOST'] ?? 'localhost';
$_ENV['RTMP_PORT'] = $_ENV['RTMP_PORT'] ?? '1935';

// Storage
$_ENV['STORAGE_PATH'] = $_ENV['STORAGE_PATH'] ?? BASE_PATH . '/storage';

// Session
$_ENV['SESSION_LIFETIME'] = $_ENV['SESSION_LIFETIME'] ?? '86400';