<?php
namespace App\Core;

/**
 * Base Model class
 * 
 * All models should extend this class
 */
class Model
{
    protected $db;
    protected $table;
    protected $fillable = [];
    protected $primaryKey = 'id';
    
    /**
     * Constructor
     */
    public function __construct()
    {
        // Get database connection
        $this->db = Application::getDB();
    }
    
    /**
     * Get all records
     */
    public function getAll()
    {
        $sql = "SELECT * FROM {$this->table}";
        return $this->db->findAll($sql);
    }
    
    /**
     * Find a record by ID
     */
    public function find($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id";
        return $this->db->find($sql, ['id' => $id]);
    }
    
    /**
     * Find records by a specific field value
     */
    public function findBy($field, $value)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$field} = :value";
        return $this->db->findAll($sql, ['value' => $value]);
    }
    
    /**
     * Find a single record by a specific field value
     */
    public function findOneBy($field, $value)
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$field} = :value LIMIT 1";
        return $this->db->find($sql, ['value' => $value]);
    }
    
    /**
     * Create a new record
     */
    public function create($data)
    {
        // Filter data to only include fillable fields
        $filteredData = $this->filterData($data);
        
        // Add timestamps if they exist in the table
        $filteredData = $this->addTimestamps($filteredData, true);
        
        // Insert record
        $id = $this->db->insert($this->table, $filteredData);
        
        // Return the newly created record
        return $this->find($id);
    }
    
    /**
     * Update a record
     */
    public function update($id, $data)
    {
        // Filter data to only include fillable fields
        $filteredData = $this->filterData($data);
        
        // Add updated_at timestamp if it exists in the table
        $filteredData = $this->addTimestamps($filteredData, false);
        
        // Update record
        $this->db->update(
            $this->table,
            $filteredData,
            "{$this->primaryKey} = :id",
            ['id' => $id]
        );
        
        // Return the updated record
        return $this->find($id);
    }
    
    /**
     * Delete a record
     */
    public function delete($id)
    {
        return $this->db->delete(
            $this->table,
            "{$this->primaryKey} = :id",
            ['id' => $id]
        );
    }
    
    /**
     * Count records
     */
    public function count()
    {
        $sql = "SELECT COUNT(*) AS count FROM {$this->table}";
        $result = $this->db->find($sql);
        return $result['count'];
    }
    
    /**
     * Execute a raw SQL query
     */
    public function query($sql, $params = [])
    {
        return $this->db->query($sql, $params);
    }
    
    /**
     * Filter data to only include fillable fields
     */
    protected function filterData($data)
    {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_intersect_key($data, array_flip($this->fillable));
    }
    
    /**
     * Add timestamp fields to data
     */
    protected function addTimestamps($data, $isCreate = false)
    {
        // Get table columns
        $sql = $this->getTableInfoSql();
        $columns = $this->db->findAll($sql);
        $columnNames = array_column($columns, 'name');
        
        // Check if timestamps exist in the table
        $now = date('Y-m-d H:i:s');
        
        if ($isCreate && in_array('created_at', $columnNames)) {
            $data['created_at'] = $now;
        }
        
        if (in_array('updated_at', $columnNames)) {
            $data['updated_at'] = $now;
        }
        
        return $data;
    }
    
    /**
     * Get SQL to fetch table columns based on database type
     */
    protected function getTableInfoSql()
    {
        $dbConfig = Application::getConfig()['database'];
        
        switch ($dbConfig['type']) {
            case 'sqlite':
                return "PRAGMA table_info({$this->table})";
                
            case 'mysql':
                return "SHOW COLUMNS FROM {$this->table}";
                
            case 'pgsql':
                return "SELECT column_name as name FROM information_schema.columns WHERE table_name = '{$this->table}'";
                
            default:
                throw new \Exception("Unsupported database type: {$dbConfig['type']}");
        }
    }
}