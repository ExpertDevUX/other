<?php
namespace App\Core;

/**
 * Router class
 * 
 * Handles URL routing and middleware
 */
class Router
{
    private $routes = [];
    private $notFoundHandler;
    
    /**
     * Register a GET route
     */
    public function get($path, $handler, $middleware = [])
    {
        $this->addRoute('GET', $path, $handler, $middleware);
    }
    
    /**
     * Register a POST route
     */
    public function post($path, $handler, $middleware = [])
    {
        $this->addRoute('POST', $path, $handler, $middleware);
    }
    
    /**
     * Register a PUT route
     */
    public function put($path, $handler, $middleware = [])
    {
        $this->addRoute('PUT', $path, $handler, $middleware);
    }
    
    /**
     * Register a DELETE route
     */
    public function delete($path, $handler, $middleware = [])
    {
        $this->addRoute('DELETE', $path, $handler, $middleware);
    }
    
    /**
     * Set 404 Not Found handler
     */
    public function setNotFoundHandler($handler)
    {
        $this->notFoundHandler = $handler;
    }
    
    /**
     * Add a route to the router
     */
    private function addRoute($method, $path, $handler, $middleware)
    {
        // Convert path to regex pattern
        $pattern = $this->pathToPattern($path);
        
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'pattern' => $pattern,
            'handler' => $handler,
            'middleware' => $middleware
        ];
    }
    
    /**
     * Convert path to regex pattern
     */
    private function pathToPattern($path)
    {
        // Replace route parameters with regex patterns
        $pattern = preg_replace('/\/:([^\/]+)/', '/(?P<$1>[^/]+)', $path);
        
        // Escape forward slashes
        $pattern = str_replace('/', '\/', $pattern);
        
        // Add start and end delimiters
        $pattern = '/^' . $pattern . '$/';
        
        return $pattern;
    }
    
    /**
     * Match a URI to a route
     */
    private function match($uri, $method)
    {
        foreach ($this->routes as $route) {
            // Check if method matches
            if ($route['method'] !== $method) {
                continue;
            }
            
            // Check if URI matches pattern
            if (preg_match($route['pattern'], $uri, $params)) {
                // Remove numeric keys from params
                foreach ($params as $key => $value) {
                    if (is_int($key)) {
                        unset($params[$key]);
                    }
                }
                
                return [
                    'route' => $route,
                    'params' => $params
                ];
            }
        }
        
        return null;
    }
    
    /**
     * Dispatch a request
     */
    public function dispatch($uri, $method)
    {
        // Remove query string from URI
        $uri = parse_url($uri, PHP_URL_PATH);
        
        // Remove trailing slash if not root
        if ($uri !== '/' && substr($uri, -1) === '/') {
            $uri = rtrim($uri, '/');
        }
        
        // Match route
        $match = $this->match($uri, $method);
        
        if ($match) {
            $route = $match['route'];
            $params = $match['params'];
            
            // Run middleware
            foreach ($route['middleware'] as $middleware) {
                $this->runMiddleware($middleware, $params);
            }
            
            // Call handler
            $this->callHandler($route['handler'], $params);
            
        } else {
            // No route found
            $this->handleNotFound();
        }
    }
    
    /**
     * Run middleware
     */
    private function runMiddleware($middleware, $params)
    {
        switch ($middleware) {
            case 'auth':
                // Check if user is authenticated
                if (!isset($_SESSION['user'])) {
                    // Redirect to login page
                    header('Location: /login');
                    exit;
                }
                break;
                
            case 'admin':
                // Check if user is an admin
                if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                    // Redirect to forbidden page
                    header('Location: /403');
                    exit;
                }
                break;
                
            case 'guest':
                // Check if user is not authenticated
                if (isset($_SESSION['user'])) {
                    // Redirect to dashboard
                    header('Location: /dashboard');
                    exit;
                }
                break;
                
            default:
                // Custom middleware
                $middlewareClass = "App\\Middleware\\" . ucfirst($middleware);
                if (class_exists($middlewareClass)) {
                    $middlewareInstance = new $middlewareClass();
                    $middlewareInstance->handle($params);
                }
                break;
        }
    }
    
    /**
     * Call a route handler
     */
    private function callHandler($handler, $params)
    {
        if (is_string($handler)) {
            // Handler is in the format "ControllerName@methodName"
            $parts = explode('@', $handler);
            
            if (count($parts) !== 2) {
                throw new \Exception("Invalid handler format: {$handler}");
            }
            
            $controllerName = $parts[0];
            $methodName = $parts[1];
            
            // Add namespace
            $controllerClass = "App\\Controllers\\" . $controllerName;
            
            if (!class_exists($controllerClass)) {
                throw new \Exception("Controller not found: {$controllerClass}");
            }
            
            $controller = new $controllerClass();
            
            if (!method_exists($controller, $methodName)) {
                throw new \Exception("Method not found: {$methodName} in {$controllerClass}");
            }
            
            // Call controller method with params
            call_user_func_array([$controller, $methodName], [$params]);
            
        } elseif (is_callable($handler)) {
            // Handler is a callable function
            call_user_func($handler, $params);
            
        } else {
            throw new \Exception("Invalid handler");
        }
    }
    
    /**
     * Handle 404 Not Found
     */
    private function handleNotFound()
    {
        if ($this->notFoundHandler) {
            call_user_func($this->notFoundHandler);
        } else {
            // Default 404 handler
            header("HTTP/1.0 404 Not Found");
            include ROOT_PATH . '/views/errors/404.php';
        }
        
        exit;
    }
}