<?php
namespace App\Core;

/**
 * Base Controller class
 * All controllers should extend this class
 */
class Controller
{
    /**
     * Render a view
     */
    protected function render($view, $params = [])
    {
        return Application::getInstance()->response->render($view, $params);
    }
    
    /**
     * Redirect to another URL
     */
    protected function redirect($url)
    {
        return Application::getInstance()->response->redirect($url);
    }
    
    /**
     * Return JSON response
     */
    protected function json($data, $statusCode = 200)
    {
        return Application::getInstance()->response->json($data, $statusCode);
    }
    
    /**
     * Check if user is logged in
     */
    protected function isLoggedIn()
    {
        return isset($_SESSION['user_id']);
    }
    
    /**
     * Get current user ID
     */
    protected function getUserId()
    {
        return $_SESSION['user_id'] ?? null;
    }
    
    /**
     * Check if user is admin
     */
    protected function isAdmin()
    {
        return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
    }
    
    /**
     * Require login
     */
    protected function requireLogin()
    {
        if (!$this->isLoggedIn()) {
            $this->setFlash('error', 'You must be logged in to access this page');
            $this->redirect('/login');
            exit;
        }
    }
    
    /**
     * Require admin
     */
    protected function requireAdmin()
    {
        $this->requireLogin();
        
        if (!$this->isAdmin()) {
            $this->setFlash('error', 'You must be an administrator to access this page');
            $this->redirect('/dashboard');
            exit;
        }
    }
    
    /**
     * Set flash message
     */
    protected function setFlash($key, $message)
    {
        Application::getInstance()->session->setFlash($key, $message);
    }
    
    /**
     * Get flash message
     */
    protected function getFlash($key)
    {
        return Application::getInstance()->session->getFlash($key);
    }
}