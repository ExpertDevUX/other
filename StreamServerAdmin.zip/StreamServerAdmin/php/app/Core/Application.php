<?php
namespace App\Core;

/**
 * Application class
 * 
 * This is the main application class that handles:
 * - Routing
 * - Request/Response handling
 * - Database connection
 * - Error handling
 */
class Application
{
    private $router;
    private $db;
    private $config;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        // Load configuration
        $this->loadConfig();
        
        // Connect to database
        $this->connectDatabase();
        
        // Initialize router
        $this->router = new Router();
        
        // Register routes
        $this->registerRoutes();
    }
    
    /**
     * Load application configuration
     */
    private function loadConfig()
    {
        $configFile = ROOT_PATH . '/config/config.php';
        $this->config = require $configFile;
    }
    
    /**
     * Connect to database
     */
    private function connectDatabase()
    {
        $dbConfig = $this->config['database'];
        $this->db = new Database($dbConfig);
    }
    
    /**
     * Register application routes
     */
    private function registerRoutes()
    {
        // Home page
        $this->router->get('/', 'HomeController@index');
        
        // Authentication routes
        $this->router->get('/login', 'AuthController@loginForm');
        $this->router->post('/login', 'AuthController@login');
        $this->router->get('/register', 'AuthController@registerForm');
        $this->router->post('/register', 'AuthController@register');
        $this->router->get('/logout', 'AuthController@logout');
        
        // Dashboard routes
        $this->router->get('/dashboard', 'DashboardController@index', ['auth']);
        $this->router->get('/profile', 'DashboardController@profile', ['auth']);
        $this->router->post('/profile', 'DashboardController@updateProfile', ['auth']);
        
        // Stream management routes
        $this->router->get('/streams', 'StreamController@index', ['auth']);
        $this->router->get('/streams/create', 'StreamController@createForm', ['auth']);
        $this->router->post('/streams/create', 'StreamController@create', ['auth']);
        $this->router->get('/streams/edit/:id', 'StreamController@editForm', ['auth']);
        $this->router->post('/streams/edit/:id', 'StreamController@update', ['auth']);
        $this->router->post('/streams/delete/:id', 'StreamController@delete', ['auth']);
        $this->router->get('/streams/view/:id', 'StreamController@view');
        $this->router->get('/streams/embed/:id', 'StreamController@embed');
        
        // Server management routes
        $this->router->get('/servers', 'ServerController@index', ['auth', 'admin']);
        $this->router->get('/servers/create', 'ServerController@createForm', ['auth', 'admin']);
        $this->router->post('/servers/create', 'ServerController@create', ['auth', 'admin']);
        $this->router->get('/servers/edit/:id', 'ServerController@editForm', ['auth', 'admin']);
        $this->router->post('/servers/edit/:id', 'ServerController@update', ['auth', 'admin']);
        $this->router->post('/servers/delete/:id', 'ServerController@delete', ['auth', 'admin']);
        
        // API routes
        $this->router->get('/api/streams', 'ApiController@getStreams');
        $this->router->get('/api/streams/:id', 'ApiController@getStream');
        $this->router->post('/api/streams/:id/viewers', 'ApiController@updateViewers');
        $this->router->get('/api/servers/status', 'ApiController@getServersStatus');
        
        // Integration routes
        $this->router->get('/integrations', 'IntegrationController@index', ['auth', 'admin']);
        $this->router->post('/integrations/wpstream/configure', 'IntegrationController@configureWpStream', ['auth', 'admin']);
        $this->router->post('/integrations/wpstream/test', 'IntegrationController@testWpStream', ['auth', 'admin']);
        
        // Settings routes
        $this->router->get('/settings', 'SettingsController@index', ['auth', 'admin']);
        $this->router->post('/settings', 'SettingsController@update', ['auth', 'admin']);
        
        // Error pages
        $this->router->get('/404', 'ErrorController@notFound');
        $this->router->get('/403', 'ErrorController@forbidden');
        $this->router->get('/500', 'ErrorController@serverError');
    }
    
    /**
     * Run the application
     */
    public function run()
    {
        try {
            // Get request URI and method
            $uri = $_SERVER['REQUEST_URI'];
            $method = $_SERVER['REQUEST_METHOD'];
            
            // Handle static files
            if ($this->isStaticFile($uri)) {
                return $this->serveStaticFile($uri);
            }
            
            // Process the request
            $this->router->dispatch($uri, $method);
            
        } catch (\Exception $e) {
            // Log error
            $this->logError($e);
            
            // Show error page
            $this->showErrorPage($e);
        }
    }
    
    /**
     * Check if URI is a static file
     */
    private function isStaticFile($uri)
    {
        // Check if URI points to a file in the public directory
        $staticPrefixes = ['/public/', '/css/', '/js/', '/images/'];
        
        foreach ($staticPrefixes as $prefix) {
            if (strpos($uri, $prefix) === 0) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Serve a static file
     */
    private function serveStaticFile($uri)
    {
        // Normalize path
        $uri = str_replace(['../', './'], '', $uri);
        
        // Map URI to filesystem path
        if (strpos($uri, '/css/') === 0) {
            $path = ROOT_PATH . '/public' . $uri;
        } else if (strpos($uri, '/js/') === 0) {
            $path = ROOT_PATH . '/public' . $uri;
        } else if (strpos($uri, '/images/') === 0) {
            $path = ROOT_PATH . '/public' . $uri;
        } else {
            $path = ROOT_PATH . $uri;
        }
        
        // Check if file exists
        if (!file_exists($path)) {
            header("HTTP/1.0 404 Not Found");
            echo "File not found: " . htmlspecialchars($uri);
            exit;
        }
        
        // Get file mime type
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        $mimeTypes = [
            'css' => 'text/css',
            'js' => 'application/javascript',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'ico' => 'image/x-icon',
            'pdf' => 'application/pdf',
            'zip' => 'application/zip',
            'woff' => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf',
            'eot' => 'application/vnd.ms-fontobject',
            'mp4' => 'video/mp4',
            'webm' => 'video/webm',
            'mp3' => 'audio/mpeg',
            'm3u8' => 'application/x-mpegURL',
            'ts' => 'video/MP2T'
        ];
        
        $mimeType = $mimeTypes[$extension] ?? 'application/octet-stream';
        
        // Send appropriate headers
        header("Content-Type: $mimeType");
        header("Content-Length: " . filesize($path));
        
        // Send file
        readfile($path);
        exit;
    }
    
    /**
     * Log an error
     */
    private function logError($exception)
    {
        $logDir = $this->config['paths']['logs'];
        $logFile = $logDir . '/error_' . date('Y-m-d') . '.log';
        
        $message = sprintf(
            "[%s] %s in %s on line %d\n%s\n\n",
            date('Y-m-d H:i:s'),
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );
        
        file_put_contents($logFile, $message, FILE_APPEND);
    }
    
    /**
     * Show error page
     */
    private function showErrorPage($exception)
    {
        // Default error view path
        $viewPath = ROOT_PATH . '/views/errors/500.php';
        
        // Get error code
        $code = $exception->getCode();
        
        // Check for specific error views
        if (in_array($code, [403, 404])) {
            $specificView = ROOT_PATH . "/views/errors/{$code}.php";
            if (file_exists($specificView)) {
                $viewPath = $specificView;
            }
        }
        
        // Set error data
        $error = [
            'code' => $code ?: 500,
            'message' => $exception->getMessage(),
            'trace' => $this->config['app']['debug'] ? $exception->getTraceAsString() : null
        ];
        
        // Extract error data to variables
        extract(['error' => $error]);
        
        // Send error header
        http_response_code($error['code'] ?: 500);
        
        // Include error view
        if (file_exists($viewPath)) {
            include $viewPath;
        } else {
            // Fallback error display
            echo '<h1>Server Error</h1>';
            echo '<p>' . htmlspecialchars($error['message']) . '</p>';
            
            if ($this->config['app']['debug']) {
                echo '<h2>Debug Information</h2>';
                echo '<pre>' . htmlspecialchars($error['trace']) . '</pre>';
            }
        }
    }
    
    /**
     * Get database instance
     */
    public static function getDB()
    {
        global $app;
        return $app->db;
    }
    
    /**
     * Get configuration
     */
    public static function getConfig()
    {
        global $app;
        return $app->config;
    }
}