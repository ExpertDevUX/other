# Stream Manager PHP Version

This is the PHP version of the Stream Manager application, a powerful video stream server management platform that simplifies complex server operations through intuitive design and intelligent automation.

## Features

- User authentication and management
- Stream creation and management
- RTMP server integration and configuration
- Real-time metrics and monitoring
- SSL certificate management
- WordPress integration via WpStream
- Embedding options for streams

## Requirements

- PHP 7.4 or higher
- SQLite (used for the demo) or PostgreSQL/MySQL for production
- Apache or Nginx web server (optional, includes built-in PHP server for development)

## Installation

1. Clone the repository or download the files
2. Navigate to the project directory
3. Run the setup script:

```bash
php setup.php
```

4. Start the development server:

```bash
php run.php
```

This will start a PHP development server at http://localhost:8080

## Default Login

The setup script creates a default admin user:

- Username: `admin`
- Password: `admin123`

## Project Structure

```
php/
├── app/                  # Application code
│   ├── Core/             # Core framework classes
│   ├── models/           # Data models
│   ├── controllers/      # Controller classes
│   ├── bootstrap.php     # Application bootstrap
│   └── routes.php        # Application routes
├── config/               # Configuration files
├── public/               # Public assets (CSS, JS, images)
├── storage/              # Storage for database, logs, etc.
├── views/                # View templates
│   ├── layouts/          # Layout templates
│   ├── home/             # Home page views
│   ├── auth/             # Authentication views
│   ├── dashboard/        # Dashboard views
│   ├── streams/          # Stream management views
│   └── errors/           # Error pages
├── .htaccess             # Apache configuration
├── index.php             # Application entry point
├── run.php               # Development server script
├── setup.php             # Setup script
└── README.md             # Documentation
```

## Production Deployment

For production deployment, you should use a proper web server like Apache or Nginx, and a database like PostgreSQL or MySQL. The application includes an `.htaccess` file for Apache.

### Apache Configuration

The included `.htaccess` file handles URL rewriting for Apache. Make sure `mod_rewrite` is enabled.

### Nginx Configuration

For Nginx, use the following configuration:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /path/to/php;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock; # Adjust to your PHP-FPM socket
    }

    location ~ /\.ht {
        deny all;
    }
}
```

## Database Configuration

The demo uses SQLite for simplicity, but you can configure the application to use PostgreSQL or MySQL by updating the database settings in `config/config.php`.

## Customization

### Application Name and URL

You can customize the application name and URL in `config/config.php`.

### Theme and Styling

Customize the application appearance by modifying the CSS files in `public/css/`.

## License

This is a proprietary application. All rights reserved.