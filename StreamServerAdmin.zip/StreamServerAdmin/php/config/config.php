<?php
/**
 * Application Configuration
 */

return [
    // Application settings
    'app_name' => 'Stream Manager',
    'app_url' => 'http://localhost:8080',
    'app_version' => '1.0.0',
    'app_timezone' => 'UTC',
    
    // Database configuration
    'database' => [
        'enabled' => true,
        'driver' => 'pgsql', // mysql, pgsql, sqlite
        'host' => 'localhost',
        'port' => 5432,
        'database' => 'stream_manager',
        'username' => 'stream_manager',
        'password' => 'stream_manager_pwd',
        'charset' => 'utf8',
        'prefix' => '',
    ],
    
    // RTMP configuration
    'rtmp' => [
        'host' => 'localhost',
        'port' => 1935,
        'enabled' => true,
        'default_server' => [
            'name' => 'Default RTMP Server',
            'host' => 'localhost',
            'port' => 1935,
            'status' => 'online',
            'server_type' => 'rtmp',
            'is_default' => true,
            'capacity' => 100,
        ],
    ],
    
    // Storage configuration
    'storage' => [
        'recordings_path' => __DIR__ . '/../storage/recordings',
        'thumbnails_path' => __DIR__ . '/../storage/thumbnails',
        'backups_path' => __DIR__ . '/../storage/backups',
    ],
    
    // Security configuration
    'security' => [
        'session_lifetime' => 7200, // 2 hours
        'password_min_length' => 6,
        'default_admin' => [
            'username' => 'admin',
            'password' => 'admin123',
            'email' => 'admin@example.com',
            'is_admin' => true,
        ],
    ],
    
    // Logging configuration
    'logging' => [
        'enabled' => true,
        'path' => __DIR__ . '/../storage/logs',
        'level' => 'debug', // debug, info, notice, warning, error, critical, alert, emergency
    ],
];