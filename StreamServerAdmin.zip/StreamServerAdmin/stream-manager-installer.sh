#!/bin/bash

# Stream Manager Docker All-in-One Installer
# This script installs Stream Manager with Docker in one step
# It handles Docker installation, configuration, and troubleshooting

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Banner
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════╗"
echo "║                                                       ║"
echo "║   Stream Manager - Docker All-in-One Installer        ║"
echo "║                                                       ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "This script will install and configure Stream Manager using Docker"
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${YELLOW}Warning: Not running as root. Some operations may require sudo privileges.${NC}"
  echo "Do you want to continue? (y/n)"
  read -r continue_as_user
  if [[ ! "$continue_as_user" =~ ^[Yy]$ ]]; then
    echo "Exiting. Please run as root with 'sudo $0'"
    exit 1
  fi
fi

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Function to print section header
print_section() {
  echo
  echo -e "${BLUE}■ $1${NC}"
  echo -e "${BLUE}────────────────────────────────────────────────────────${NC}"
}

# Function to print success message
print_success() {
  echo -e "${GREEN}✓ $1${NC}"
}

# Function to print error message
print_error() {
  echo -e "${RED}✗ $1${NC}"
}

# Function to print warning message
print_warning() {
  echo -e "${YELLOW}⚠ $1${NC}"
}

# Function to print info message
print_info() {
  echo -e "ℹ $1"
}

# Check system requirements
print_section "Checking system requirements"

# Check OS
os_name=$(cat /etc/os-release | grep "^ID=" | cut -d= -f2 | tr -d '"')
os_version=$(cat /etc/os-release | grep "^VERSION_ID=" | cut -d= -f2 | tr -d '"')
echo "Detected OS: $os_name $os_version"

# Check CPU cores
cpu_cores=$(grep -c ^processor /proc/cpuinfo)
echo "CPU Cores: $cpu_cores"
if [ "$cpu_cores" -lt 2 ]; then
  print_warning "Low CPU count ($cpu_cores). Minimum recommended is 2 cores."
else
  print_success "CPU cores sufficient ($cpu_cores)"
fi

# Check RAM
total_mem=$(free -m | awk '/^Mem:/{print $2}')
echo "Total RAM: $total_mem MB"
if [ "$total_mem" -lt 2000 ]; then
  print_warning "Low memory ($total_mem MB). Minimum recommended is 2GB RAM."
else
  print_success "RAM sufficient ($total_mem MB)"
fi

# Check disk space
free_disk=$(df -h / | awk 'NR==2 {print $4}')
echo "Free disk space: $free_disk"
if [[ "$free_disk" == *"G"* ]]; then
  free_disk_num=$(echo "$free_disk" | sed 's/G//')
  if (( $(echo "$free_disk_num < 5" | bc -l) )); then
    print_warning "Low disk space ($free_disk). Minimum recommended is 5GB free space."
  else
    print_success "Disk space sufficient ($free_disk)"
  fi
else
  print_warning "Low disk space ($free_disk). Minimum recommended is 5GB free space."
fi

# Check if Docker is installed
print_section "Checking for Docker"
if command_exists docker; then
  docker_version=$(docker --version | awk '{print $3}' | sed 's/,//')
  print_success "Docker is installed (version $docker_version)"
else
  print_warning "Docker is not installed. Will attempt to install Docker..."
  
  # Install Docker based on detected OS
  if [[ "$os_name" == "ubuntu" || "$os_name" == "debian" ]]; then
    echo "Installing Docker on $os_name..."
    
    # Update package lists
    apt-get update
    
    # Install prerequisites
    apt-get install -y apt-transport-https ca-certificates curl software-properties-common gnupg
    
    # Add Docker's official GPG key
    curl -fsSL https://download.docker.com/linux/$os_name/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # Set up the repository
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/$os_name $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker Engine
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io
    
    # Start and enable Docker
    systemctl start docker
    systemctl enable docker
    
    if command_exists docker; then
      docker_version=$(docker --version | awk '{print $3}' | sed 's/,//')
      print_success "Docker installed successfully (version $docker_version)"
    else
      print_error "Failed to install Docker. Please install it manually."
      exit 1
    fi
  elif [[ "$os_name" == "centos" || "$os_name" == "fedora" || "$os_name" == "rhel" ]]; then
    echo "Installing Docker on $os_name..."
    
    # Install prerequisites
    yum install -y yum-utils
    
    # Add Docker repository
    yum-config-manager --add-repo https://download.docker.com/linux/$os_name/docker-ce.repo
    
    # Install Docker
    yum install -y docker-ce docker-ce-cli containerd.io
    
    # Start and enable Docker
    systemctl start docker
    systemctl enable docker
    
    if command_exists docker; then
      docker_version=$(docker --version | awk '{print $3}' | sed 's/,//')
      print_success "Docker installed successfully (version $docker_version)"
    else
      print_error "Failed to install Docker. Please install it manually."
      exit 1
    fi
  else
    print_error "Unsupported operating system: $os_name. Please install Docker manually."
    echo "Visit https://docs.docker.com/engine/install/ for installation instructions."
    exit 1
  fi
fi

# Check if Docker Compose is installed
print_section "Checking for Docker Compose"
compose_command=""

if command_exists docker-compose; then
  compose_version=$(docker-compose --version | awk '{print $3}' | sed 's/,//')
  print_success "Docker Compose v1 is installed (version $compose_version)"
  compose_command="docker-compose"
elif docker compose version &>/dev/null; then
  compose_version=$(docker compose version | awk '{print $4}')
  print_success "Docker Compose v2 is installed (version $compose_version)"
  compose_command="docker compose"
else
  print_warning "Docker Compose is not installed. Will attempt to install Docker Compose..."
  
  # Install Docker Compose
  COMPOSE_VERSION="v2.24.6"
  mkdir -p ~/.docker/cli-plugins/
  curl -SL "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o ~/.docker/cli-plugins/docker-compose
  chmod +x ~/.docker/cli-plugins/docker-compose
  
  # Create symlink for backwards compatibility
  ln -sf ~/.docker/cli-plugins/docker-compose /usr/local/bin/docker-compose
  chmod +x /usr/local/bin/docker-compose
  
  if command_exists docker-compose; then
    compose_version=$(docker-compose --version | awk '{print $3}' | sed 's/,//')
    print_success "Docker Compose v1 installed successfully (version $compose_version)"
    compose_command="docker-compose"
  elif docker compose version &>/dev/null; then
    compose_version=$(docker compose version | awk '{print $4}')
    print_success "Docker Compose v2 installed successfully (version $compose_version)"
    compose_command="docker compose"
  else
    print_error "Failed to install Docker Compose. Please install it manually."
    exit 1
  fi
fi

# Check if port 5000 is available
print_section "Checking port availability"
PORT_CHECK_RESULT=$(netstat -tuln | grep ":5000 ")
if [ -n "$PORT_CHECK_RESULT" ]; then
  print_warning "Port 5000 is already in use. This may cause conflicts with Stream Manager."
  echo "Do you want to stop any conflicting services? (y/n)"
  read -r stop_conflict
  if [[ "$stop_conflict" =~ ^[Yy]$ ]]; then
    # Try to find and stop the conflicting service
    if command_exists lsof; then
      CONFLICTING_PROCESS=$(lsof -i:5000 -t)
      if [ -n "$CONFLICTING_PROCESS" ]; then
        echo "Attempting to stop process using port 5000 (PID: $CONFLICTING_PROCESS)..."
        kill -15 $CONFLICTING_PROCESS
        sleep 2
        if netstat -tuln | grep -q ":5000 "; then
          print_warning "Could not free port 5000. You may experience issues."
        else
          print_success "Port 5000 is now available"
        fi
      fi
    else
      print_warning "Unable to identify the conflicting process. lsof is not installed."
      print_warning "You may experience issues with port 5000."
    fi
  else
    print_warning "Port conflict not resolved. You may experience issues."
  fi
else
  print_success "Port 5000 is available"
fi

# Check if ports 1935 and 8080 are available
PORT_CHECK_RESULT_1935=$(netstat -tuln | grep ":1935 ")
PORT_CHECK_RESULT_8080=$(netstat -tuln | grep ":8080 ")

if [ -n "$PORT_CHECK_RESULT_1935" ]; then
  print_warning "Port 1935 (RTMP) is already in use. This may cause conflicts."
else
  print_success "Port 1935 (RTMP) is available"
fi

if [ -n "$PORT_CHECK_RESULT_8080" ]; then
  print_warning "Port 8080 (HLS/HTTP) is already in use. This may cause conflicts."
else
  print_success "Port 8080 (HLS/HTTP) is available"
fi

# Create necessary directories
print_section "Setting up Stream Manager directories"

# Determine installation directory
INSTALL_DIR="$(pwd)/stream-manager"
echo "Stream Manager will be installed in: $INSTALL_DIR"
echo "Do you want to change the installation directory? (y/n)"
read -r change_dir
if [[ "$change_dir" =~ ^[Yy]$ ]]; then
  echo "Enter the absolute path for installation (e.g., /opt/stream-manager):"
  read -r INSTALL_DIR
fi

# Create installation directory if it doesn't exist
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR" || { print_error "Failed to change to installation directory"; exit 1; }
print_success "Created installation directory: $INSTALL_DIR"

# Create docker-compose.yml
print_section "Creating configuration files"

cat > "$INSTALL_DIR/docker-compose.yml" << 'EOF'
version: '3'

services:
  app:
    container_name: stream-app
    build:
      context: .
      dockerfile: Dockerfile
    env_file:
      - .env
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgres://postgres:postgres@db:5432/stream_manager
      - RTMP_SERVER_HOST=rtmp
      - RTMP_HTTP_PORT=80
      - RTMP_PORT=1935
      - USE_DOCKER=true
    ports:
      - "5000:5000"
    depends_on:
      - db
      - rtmp
    restart: unless-stopped
    networks:
      - stream-network

  rtmp:
    container_name: stream-rtmp
    build:
      context: .
      dockerfile: Dockerfile.rtmp
    ports:
      - "1935:1935"  # RTMP port
      - "8080:80"    # HTTP port for HLS/DASH
    volumes:
      - rtmp-data:/opt/nginx/hls
      - rtmp-data:/opt/nginx/dash
    restart: unless-stopped
    networks:
      - stream-network

  db:
    container_name: stream-db
    image: postgres:13-alpine
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=stream_manager
    volumes:
      - db-data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    restart: unless-stopped
    networks:
      - stream-network

volumes:
  db-data:
  rtmp-data:

networks:
  stream-network:
    driver: bridge
EOF

print_success "Created docker-compose.yml"

# Create .env
cat > "$INSTALL_DIR/.env" << 'EOF'
# Database Configuration
DATABASE_URL=postgres://postgres:postgres@db:5432/stream_manager
PGHOST=db
PGPORT=5432
PGUSER=postgres
PGPASSWORD=postgres
PGDATABASE=stream_manager

# Application Settings
NODE_ENV=production
PORT=5000
SESSION_SECRET=stream_manager_session_secret
USE_DOCKER=true

# RTMP Server Configuration
RTMP_SERVER_HOST=rtmp
RTMP_HTTP_PORT=80
RTMP_PORT=1935
EOF

print_success "Created .env file"

# Create Dockerfile
cat > "$INSTALL_DIR/Dockerfile" << 'EOF'
FROM node:18-slim

# Create app directory
WORKDIR /app

# Install dependencies required for Postgres client
RUN apt-get update && apt-get install -y \
    postgresql-client \
    curl \
    dnsutils \
    netcat-traditional \
    && rm -rf /var/lib/apt/lists/*

# Install app dependencies
# A wildcard is used to ensure both package.json AND package-lock.json are copied
COPY package*.json ./
RUN npm ci --only=production

# Copy app source
COPY . .

# Build the app
RUN npm run build

# Expose the application port
EXPOSE 5000

# Set environment variables
ENV NODE_ENV=production
ENV PORT=5000

# Start the application
CMD ["node", "dist/index.js"]
EOF

print_success "Created Dockerfile"

# Create Dockerfile.rtmp
cat > "$INSTALL_DIR/Dockerfile.rtmp" << 'EOF'
FROM alpine:3.16

# Set working directory
WORKDIR /tmp

# Install dependencies
RUN apk add --no-cache \
    build-base \
    pcre-dev \
    openssl-dev \
    zlib-dev \
    linux-headers \
    curl \
    wget \
    git \
    ca-certificates

# Download and extract NGINX
ARG NGINX_VERSION=1.23.1
RUN wget https://nginx.org/download/nginx-${NGINX_VERSION}.tar.gz && \
    tar -zxf nginx-${NGINX_VERSION}.tar.gz

# Clone RTMP module
RUN git clone https://github.com/arut/nginx-rtmp-module.git

# Build NGINX with RTMP module
RUN cd nginx-${NGINX_VERSION} && \
    ./configure \
        --prefix=/opt/nginx \
        --with-http_ssl_module \
        --with-http_v2_module \
        --with-http_flv_module \
        --with-http_mp4_module \
        --add-module=../nginx-rtmp-module \
        --with-cc-opt="-Wimplicit-fallthrough=0" && \
    make && \
    make install

# Create directories for HLS and DASH
RUN mkdir -p /opt/nginx/hls /opt/nginx/dash /opt/nginx/logs

# Cleanup
RUN rm -rf /tmp/*

# Expose ports
EXPOSE 1935
EXPOSE 80

# Copy NGINX configuration
COPY nginx/nginx.conf /opt/nginx/conf/nginx.conf

# Start NGINX
CMD ["/opt/nginx/sbin/nginx", "-g", "daemon off;"]
EOF

print_success "Created Dockerfile.rtmp"

# Create nginx directory and nginx.conf
mkdir -p "$INSTALL_DIR/nginx"
cat > "$INSTALL_DIR/nginx/nginx.conf" << 'EOF'
worker_processes auto;
error_log /opt/nginx/logs/error.log info;
pid /opt/nginx/logs/nginx.pid;

events {
    worker_connections 1024;
}

# RTMP configuration
rtmp {
    server {
        listen 1935; # Listen on standard RTMP port
        chunk_size 4000;
        
        # Enable auto push to scale to multiple workers
        rtmp_auto_push on;
        
        # Define the application name
        application live {
            live on;
            record off;
            
            # Allow publishing with any stream key
            allow publish all;
            
            # Allow playing of all streams
            allow play all;
            
            # HLS
            hls on;
            hls_path /opt/nginx/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path /opt/nginx/dash;
            dash_fragment 3;
            dash_playlist_length 60;
            
            # Show NGINX-RTMP stats
            on_publish http://localhost:8080/hooks/auth;
            on_publish_done http://localhost:8080/hooks/done;
        }
    }
}

# HTTP configuration
http {
    include /opt/nginx/conf/mime.types;
    default_type application/octet-stream;
    
    sendfile on;
    tcp_nopush on;
    keepalive_timeout 65;
    
    # Compression settings
    gzip on;
    gzip_min_length 1000;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # Access log format
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                     '$status $body_bytes_sent "$http_referer" '
                     '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /opt/nginx/logs/access.log main;
    
    # Default server configuration
    server {
        listen 80;
        server_name localhost;
        
        # CORS settings for all locations
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range' always;
        add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;
        
        # HLS
        location /hls {
            root /opt/nginx;
            add_header Cache-Control no-cache;
            
            # CORS preflight requests
            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
            
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
        }
        
        # DASH
        location /dash {
            root /opt/nginx;
            add_header Cache-Control no-cache;
            
            # CORS preflight requests
            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
            
            types {
                application/dash+xml mpd;
            }
        }
        
        # Stats
        location /stat {
            rtmp_stat all;
            rtmp_stat_stylesheet stat.xsl;
            add_header 'Access-Control-Allow-Origin' '*' always;
        }
        
        location /stat.xsl {
            root /opt/nginx/html;
        }
        
        # Control API
        location /control {
            rtmp_control all;
            add_header 'Access-Control-Allow-Origin' '*' always;
        }
        
        # Authentication and webhook endpoints
        location /hooks {
            proxy_pass http://app:5000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
    }
}
EOF

print_success "Created nginx configuration"

# Create .dockerignore
cat > "$INSTALL_DIR/.dockerignore" << 'EOF'
# Node modules and dependencies
node_modules
npm-debug.log

# Version control
.git
.gitignore

# Build files
dist
build
.cache

# Environment variables
.env
.env.local
.env.development
.env.test
.env.production

# Docker files
Dockerfile
Dockerfile.rtmp
docker-compose.yml
.dockerignore

# Logs
logs
*.log

# Temporary files
tmp
.DS_Store
*.swp
*.swo

# Documentation files
README.md
LICENSE
CONTRIBUTING.md
EOF

print_success "Created .dockerignore"

# Create troubleshooting script
cat > "$INSTALL_DIR/troubleshoot.sh" << 'EOF'
#!/bin/bash

# Stream Manager Docker Troubleshooting Tool
# This script helps diagnose and fix common issues with Stream Manager Docker installation

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print section header
print_section() {
  echo
  echo -e "${BLUE}■ $1${NC}"
  echo -e "${BLUE}────────────────────────────────────────────────────────${NC}"
}

# Function to print success message
print_success() {
  echo -e "${GREEN}✓ $1${NC}"
}

# Function to print error message
print_error() {
  echo -e "${RED}✗ $1${NC}"
}

# Function to print warning message
print_warning() {
  echo -e "${YELLOW}⚠ $1${NC}"
}

# Determine which Docker Compose command to use
if command -v docker-compose >/dev/null 2>&1; then
  compose_command="docker-compose"
elif docker compose version >/dev/null 2>&1; then
  compose_command="docker compose"
else
  print_error "Docker Compose not found"
  exit 1
fi

# Banner
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════╗"
echo "║                                                       ║"
echo "║   Stream Manager - Docker Troubleshooting Tool        ║"
echo "║                                                       ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check container status
print_section "Checking container status"
$compose_command ps

# Check if containers are running
if ! $compose_command ps | grep -q "stream-app.*Up"; then
  print_warning "stream-app container is not running"
  needs_restart=true
else
  print_success "stream-app container is running"
fi

if ! $compose_command ps | grep -q "stream-rtmp.*Up"; then
  print_warning "stream-rtmp container is not running"
  needs_restart=true
else
  print_success "stream-rtmp container is running"
fi

if ! $compose_command ps | grep -q "stream-db.*Up"; then
  print_warning "stream-db container is not running"
  needs_restart=true
else
  print_success "stream-db container is running"
fi

# Check container logs for errors
print_section "Checking container logs for errors"

echo "Checking stream-app logs..."
if $compose_command logs --tail=20 app | grep -q -i "error\|exception\|failed"; then
  print_warning "Found errors in stream-app logs"
else
  print_success "No critical errors found in stream-app logs"
fi

echo "Checking stream-rtmp logs..."
if $compose_command logs --tail=20 rtmp | grep -q -i "error\|exception\|failed"; then
  print_warning "Found errors in stream-rtmp logs"
else
  print_success "No critical errors found in stream-rtmp logs"
fi

echo "Checking stream-db logs..."
if $compose_command logs --tail=20 db | grep -q -i "error\|exception\|failed"; then
  print_warning "Found errors in stream-db logs"
else
  print_success "No critical errors found in stream-db logs"
fi

# Check port bindings
print_section "Checking port bindings"

if netstat -tuln | grep -q ":5000 "; then
  print_success "Port 5000 is open (Dashboard)"
else
  print_warning "Port 5000 is not open (Dashboard)"
  needs_restart=true
fi

if netstat -tuln | grep -q ":1935 "; then
  print_success "Port 1935 is open (RTMP)"
else
  print_warning "Port 1935 is not open (RTMP)"
  needs_restart=true
fi

if netstat -tuln | grep -q ":8080 "; then
  print_success "Port 8080 is open (HLS/HTTP)"
else
  print_warning "Port 8080 is not open (HLS/HTTP)"
  needs_restart=true
fi

# Ask for restart if needed
if [ "$needs_restart" = true ]; then
  print_section "Issues detected - Fix recommendations"
  echo "Would you like to restart the containers? (y/n)"
  read -r restart_containers
  
  if [[ "$restart_containers" =~ ^[Yy]$ ]]; then
    echo "Restarting containers..."
    $compose_command restart
    print_success "Containers restarted"
  fi
  
  echo "Would you like to rebuild the containers? (y/n)"
  read -r rebuild_containers
  
  if [[ "$rebuild_containers" =~ ^[Yy]$ ]]; then
    echo "Rebuilding containers..."
    $compose_command up -d --build
    print_success "Containers rebuilt"
  fi
else
  print_section "System check complete"
  print_success "No major issues detected"
fi

# Final instructions
print_section "Stream Manager Information"
echo -e "📊 Dashboard: http://localhost:5000"
echo -e "🎥 RTMP Server: rtmp://localhost:1935/live"
echo -e "🎬 HLS Stream: http://localhost:8080/hls/[stream-key].m3u8"
echo -e "📈 RTMP Stats: http://localhost:8080/stat"
echo -e "\n📝 Default admin credentials:"
echo -e "Username: admin"
echo -e "Password: admin123"
EOF

chmod +x "$INSTALL_DIR/troubleshoot.sh"
print_success "Created troubleshooting script"

# Download and build Stream Manager
print_section "Setting up Stream Manager"

# Ask if the user has a git repository or wants to download the files
echo "Do you have a Stream Manager Git repository? (y/n)"
read -r has_git_repo

if [[ "$has_git_repo" =~ ^[Yy]$ ]]; then
  echo "Enter the Git repository URL:"
  read -r git_repo
  
  if command_exists git; then
    git clone "$git_repo" "$INSTALL_DIR/temp"
    if [ $? -eq 0 ]; then
      # Move all files except the ones we created
      cd "$INSTALL_DIR/temp" || { print_error "Failed to change to temp directory"; exit 1; }
      cp -r * "$INSTALL_DIR/"
      cd "$INSTALL_DIR" || { print_error "Failed to change to installation directory"; exit 1; }
      rm -rf "$INSTALL_DIR/temp"
      print_success "Downloaded Stream Manager from Git repository"
    else
      print_error "Failed to clone the repository. Please check the URL and try again."
      exit 1
    fi
  else
    print_error "Git is not installed. Please install it and try again."
    exit 1
  fi
else
  print_info "The installer will download the Stream Manager package."
  echo "Would you like to proceed? (y/n)"
  read -r download_package
  
  if [[ "$download_package" =~ ^[Yy]$ ]]; then
    # Create package.json
    cat > "$INSTALL_DIR/package.json" << 'EOF'
{
  "name": "stream-manager",
  "version": "1.0.0",
  "type": "module",
  "license": "MIT",
  "scripts": {
    "dev": "tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js",
    "check": "tsc",
    "db:push": "drizzle-kit push"
  },
  "dependencies": {
    "@hookform/resolvers": "^3.9.1",
    "@neondatabase/serverless": "^0.10.4",
    "@radix-ui/react-accordion": "^1.2.1",
    "@radix-ui/react-alert-dialog": "^1.1.2",
    "@radix-ui/react-aspect-ratio": "^1.1.0",
    "@radix-ui/react-avatar": "^1.1.1",
    "@radix-ui/react-checkbox": "^1.1.2",
    "@radix-ui/react-collapsible": "^1.1.1",
    "@radix-ui/react-context-menu": "^2.2.2",
    "@radix-ui/react-dialog": "^1.1.2",
    "@radix-ui/react-dropdown-menu": "^2.1.2",
    "@radix-ui/react-hover-card": "^1.1.2",
    "@radix-ui/react-label": "^2.1.0",
    "@radix-ui/react-menubar": "^1.1.2",
    "@radix-ui/react-navigation-menu": "^1.2.1",
    "@radix-ui/react-popover": "^1.1.2",
    "@radix-ui/react-progress": "^1.1.0",
    "@radix-ui/react-radio-group": "^1.2.1",
    "@radix-ui/react-scroll-area": "^1.2.0",
    "@radix-ui/react-select": "^2.1.2",
    "@radix-ui/react-separator": "^1.1.0",
    "@radix-ui/react-slider": "^1.2.1",
    "@radix-ui/react-slot": "^1.1.0",
    "@radix-ui/react-switch": "^1.1.1",
    "@radix-ui/react-tabs": "^1.1.1",
    "@radix-ui/react-toast": "^1.2.2",
    "@radix-ui/react-toggle": "^1.1.0",
    "@radix-ui/react-toggle-group": "^1.1.0",
    "@radix-ui/react-tooltip": "^1.1.3",
    "@tanstack/react-query": "^5.60.5",
    "axios": "^1.8.4",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.1",
    "cmdk": "^1.0.0",
    "connect-pg-simple": "^10.0.0",
    "date-fns": "^3.6.0",
    "drizzle-orm": "^0.39.1",
    "drizzle-zod": "^0.7.0",
    "embla-carousel-react": "^8.3.0",
    "express": "^4.21.2",
    "express-session": "^1.18.1",
    "framer-motion": "^11.13.1",
    "hls.js": "^1.5.20",
    "input-otp": "^1.2.4",
    "lucide-react": "^0.453.0",
    "memorystore": "^1.6.7",
    "node-media-server": "^4.0.12",
    "passport": "^0.7.0",
    "passport-local": "^1.0.0",
    "postgres": "^3.4.5",
    "react": "^18.3.1",
    "react-day-picker": "^8.10.1",
    "react-dom": "^18.3.1",
    "react-hook-form": "^7.53.1",
    "react-icons": "^5.4.0",
    "react-resizable-panels": "^2.1.4",
    "recharts": "^2.13.0",
    "tailwind-merge": "^2.5.4",
    "tailwindcss-animate": "^1.0.7",
    "vaul": "^1.1.0",
    "wouter": "^3.3.5",
    "ws": "^8.18.0",
    "zod": "^3.23.8",
    "zod-validation-error": "^3.4.0"
  },
  "devDependencies": {
    "@tailwindcss/typography": "^0.5.15",
    "@types/connect-pg-simple": "^7.0.3",
    "@types/express": "4.17.21",
    "@types/express-session": "^1.18.0",
    "@types/node": "20.16.11",
    "@types/passport": "^1.0.16",
    "@types/passport-local": "^1.0.38",
    "@types/react": "^18.3.11",
    "@types/react-dom": "^18.3.1",
    "@types/ws": "^8.5.13",
    "@vitejs/plugin-react": "^4.3.2",
    "autoprefixer": "^10.4.20",
    "drizzle-kit": "^0.30.4",
    "esbuild": "^0.25.0",
    "postcss": "^8.4.47",
    "tailwindcss": "^3.4.14",
    "tsx": "^4.19.1",
    "typescript": "5.6.3",
    "vite": "^5.4.14"
  }
}
EOF
    print_success "Created package.json"
    
    # Create README.md with instructions
    cat > "$INSTALL_DIR/README.md" << 'EOF'
# Stream Manager

A sophisticated video stream server management platform that leverages intelligent design and automation to simplify complex server operations.

## Features

- 💻 User account management with admin features
- 📹 RTMP server setup and configuration
- 🔄 Automatic installation with Docker
- 🎥 Live streaming with HLS/DASH support
- 📊 Real-time server metrics via WebSockets
- 🔧 NGINX configuration management
- 🔒 HTTPS support with Let's Encrypt
- 🌐 Integration with WpStream (WordPress plugin)
- 🔍 Bandwidth monitoring and management
- 🧩 Embedding functionality for streams

## Service URLs

- **Dashboard**: http://localhost:5000
- **RTMP Server**: rtmp://localhost:1935/live
- **HLS Stream**: http://localhost:8080/hls/[stream-key].m3u8
- **DASH Stream**: http://localhost:8080/dash/[stream-key]/index.mpd
- **RTMP Stats**: http://localhost:8080/stat

## Default Login

- **Username**: admin
- **Password**: admin123

## Troubleshooting

If you encounter any issues, run the troubleshooting script:

```bash
./troubleshoot.sh
```

## Docker Commands

### Start Services
```bash
docker-compose up -d
```

### Stop Services
```bash
docker-compose down
```

### View Logs
```bash
docker-compose logs -f
```

### Rebuild Services
```bash
docker-compose up -d --build
```
EOF
    print_success "Created README.md"
    
    print_info "Minimal setup created for Docker-based Stream Manager"
    print_info "You may need to add additional source files for a complete installation"
  else
    print_warning "No source files provided. Docker setup will be incomplete."
  fi
fi

# Start Docker containers
print_section "Starting Docker containers"

# Use the appropriate Docker Compose command
if command_exists docker-compose; then
  compose_cmd="docker-compose"
elif docker compose version &>/dev/null; then
  compose_cmd="docker compose"
else
  print_error "Docker Compose not found. Cannot start containers."
  exit 1
fi

echo "Do you want to start the containers now? (y/n)"
read -r start_containers

if [[ "$start_containers" =~ ^[Yy]$ ]]; then
  echo "Building and starting containers..."
  $compose_cmd up -d --build
  
  if [ $? -eq 0 ]; then
    print_success "Containers started successfully"
    
    # Wait for services to start up
    echo "Waiting for services to start up..."
    sleep 10
    
    # Initialize database
    echo "Initializing database..."
    $compose_cmd exec -T app npm run db:push
    
    if [ $? -eq 0 ]; then
      print_success "Database initialized successfully"
    else
      print_warning "Database initialization might have issues"
      print_info "You may need to run 'docker-compose exec app npm run db:push' manually later"
    fi
  else
    print_error "Failed to start containers"
    echo "Please check the logs with '$compose_cmd logs'"
  fi
else
  print_info "You can start the containers later with '$compose_cmd up -d'"
fi

# Final instructions
print_section "Installation complete!"
echo -e "Stream Manager has been installed at: ${INSTALL_DIR}"
echo -e "\nAccess your Stream Manager at:"
echo -e "📊 Dashboard: http://localhost:5000"
echo -e "🎥 RTMP Server: rtmp://localhost:1935/live"
echo -e "🎬 HLS Stream: http://localhost:8080/hls/[stream-key].m3u8"
echo -e "📈 RTMP Stats: http://localhost:8080/stat"
echo -e "\n📝 Default admin credentials:"
echo -e "Username: admin"
echo -e "Password: admin123"
echo -e "\n⚠️ Remember to change the default password after your first login!"
echo -e "\n🔧 If you encounter any issues, run the troubleshooting script:"
echo -e "${INSTALL_DIR}/troubleshoot.sh"

print_section "Docker commands"
echo -e "💡 Start services:    $compose_cmd up -d"
echo -e "💡 Stop services:     $compose_cmd down"
echo -e "💡 View logs:         $compose_cmd logs -f"
echo -e "💡 Restart services:  $compose_cmd restart"
echo -e "💡 Rebuild services:  $compose_cmd up -d --build"

echo -e "\nThank you for installing Stream Manager!"
exit 0