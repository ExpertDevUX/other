import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Server } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface ServerStatusProps {
  serverId: number;
}

export function ServerStatus({ serverId }: ServerStatusProps) {
  const { data: server, isLoading } = useQuery<Server>({
    queryKey: [`/api/rtmp/status/${serverId}`],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-10" />
            </div>
            <Skeleton className="h-2.5 w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-10" />
            </div>
            <Skeleton className="h-2.5 w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-10" />
            </div>
            <Skeleton className="h-2.5 w-full" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-10" />
            </div>
            <Skeleton className="h-2.5 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!server) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-gray-500">Server information not available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Format uptime
  const formatUptime = (seconds: number = 0) => {
    if (seconds === 0) return 'Not Running';
    
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    
    if (days > 0) {
      return `${days}d ${hours}h`;
    }
    
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Server Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600">CPU Usage</span>
            <span className="text-sm font-medium">{server.cpuUsage || 0}%</span>
          </div>
          <Progress 
            value={server.cpuUsage || 0} 
            className="h-2.5 bg-gray-200" 
          />
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600">Memory Usage</span>
            <span className="text-sm font-medium">{server.memoryUsage || 0}%</span>
          </div>
          <Progress 
            value={server.memoryUsage || 0} 
            className="h-2.5 bg-gray-200"
            indicatorClassName={(server.memoryUsage || 0) > 60 ? "bg-amber-500" : undefined}
          />
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600">Disk Usage</span>
            <span className="text-sm font-medium">{server.diskUsage || 0}%</span>
          </div>
          <Progress 
            value={server.diskUsage || 0} 
            className="h-2.5 bg-gray-200"
            indicatorClassName={(server.diskUsage || 0) < 25 ? "bg-green-500" : undefined}
          />
        </div>
        
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-600">Network</span>
            <span className="text-sm font-medium">{server.networkUsage || 0}%</span>
          </div>
          <Progress 
            value={server.networkUsage || 0} 
            className="h-2.5 bg-gray-200"
            indicatorClassName={(server.networkUsage || 0) > 80 ? "bg-red-500" : undefined}
          />
        </div>
        
        <div className="mt-4 text-right">
          <span className="text-sm text-gray-500">
            {formatUptime(server.uptime || 0)} uptime
          </span>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 rounded-b-lg px-6 py-4">
        <Button 
          variant="link" 
          className="text-primary text-sm font-medium flex items-center p-0"
          asChild
        >
          <a href="/metrics">
            <span>View detailed metrics</span>
            <ArrowRight className="ml-1 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}
