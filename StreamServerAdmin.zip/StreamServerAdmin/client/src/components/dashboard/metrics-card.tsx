import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ArrowDown, ArrowUp, LucideIcon } from "lucide-react";

interface MetricsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: number | string;
  changeDirection?: 'up' | 'down';
  suffix?: string;
  className?: string;
}

export function MetricsCard({
  title,
  value,
  icon: Icon,
  change,
  changeDirection,
  suffix,
  className
}: MetricsCardProps) {
  return (
    <Card className={cn("", className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <Icon className="h-5 w-5 text-primary" />
        </div>
        
        <div className="flex items-end justify-between">
          <p className="text-3xl font-semibold">
            {value}
            {suffix && <span className="text-lg ml-1">{suffix}</span>}
          </p>
          
          {change && (
            <div className={cn(
              "flex items-center",
              changeDirection === 'up' ? 'text-green-600' : 'text-red-600'
            )}>
              {changeDirection === 'up' ? (
                <ArrowUp className="h-4 w-4 mr-1" />
              ) : (
                <ArrowDown className="h-4 w-4 mr-1" />
              )}
              <span className="text-sm">{change}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
