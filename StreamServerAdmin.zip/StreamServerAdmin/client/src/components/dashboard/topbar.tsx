import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Menu, 
  Search, 
  Bell
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { ThemeToggle } from "@/components/theme-toggle";
import { UserDropdown } from "@/components/user-dropdown";

interface TopBarProps {
  title: string;
  onMenuToggle?: () => void;
}

export function TopBar({ title, onMenuToggle }: TopBarProps) {
  const isMobile = useIsMobile();

  return (
    <header className="bg-background border-b shadow-sm z-10">
      <div className="px-6 py-3 flex items-center justify-between">
        {isMobile && (
          <Button 
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="mr-2 text-gray-600 hover:text-primary"
          >
            <Menu className="h-5 w-5" />
          </Button>
        )}
        
        <div className="flex-1 ml-0">
          <h2 className="text-xl font-medium text-foreground">{title}</h2>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative hidden md:block">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            <Input 
              type="text" 
              placeholder="Search..." 
              className="pl-10 pr-4 rounded-lg" 
            />
          </div>
          
          <ThemeToggle />
          
          <Button
            variant="ghost"
            size="icon"
            className="p-2 rounded-full hover:bg-gray-100 relative"
          >
            <Bell className="h-5 w-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
          </Button>
          
          {/* User dropdown with logout functionality */}
          <UserDropdown />
        </div>
      </div>
    </header>
  );
}
