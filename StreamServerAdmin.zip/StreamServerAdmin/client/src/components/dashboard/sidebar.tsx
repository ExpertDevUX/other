import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Video, 
  Users, 
  Server, 
  BarChart, 
  Settings,
  Menu,
  ChevronLeft,
  Plug,
  LineChart,
  Gauge,
  Cloud,
  HardDrive,
  UserCircle,
  Component,
  Lock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const { user } = useAuth();
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const [collapsed, setCollapsed] = useState(isMobile);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  // Reorganize navigation items with logical grouping
  const navItems = [
    // Main Navigation
    { 
      group: "Main", 
      items: [
        { path: "/", label: "Dashboard", icon: <LayoutDashboard className="mr-3 h-5 w-5" /> },
        { path: "/streams", label: "Streams", icon: <Video className="mr-3 h-5 w-5" /> }
      ]
    },
    // Server Management (admin only)
    { 
      group: "Server Management", 
      items: [
        { path: "/rtmp-config", label: "RTMP Configuration", icon: <Server className="mr-3 h-5 w-5" />, adminOnly: true },
        { path: "/server-config", label: "Server Settings", icon: <Settings className="mr-3 h-5 w-5" />, adminOnly: true },
        { path: "/nginx-management", label: "NGINX Management", icon: <Component className="mr-3 h-5 w-5" />, adminOnly: true },
        { path: "/ssl-settings", label: "SSL & Security", icon: <Lock className="mr-3 h-5 w-5" />, adminOnly: true },
        { path: "/metrics", label: "Server Metrics", icon: <LineChart className="mr-3 h-5 w-5" /> },
        { path: "/vps-info", label: "VPS Information", icon: <Cloud className="mr-3 h-5 w-5" />, adminOnly: true }
      ]
    },
    // System Tools (admin only)
    { 
      group: "System", 
      items: [
        { path: "/users", label: "Users", icon: <Users className="mr-3 h-5 w-5" />, adminOnly: true },
        { path: "/analytics", label: "Analytics", icon: <BarChart className="mr-3 h-5 w-5" /> },
        { path: "/integrations", label: "Integrations", icon: <Plug className="mr-3 h-5 w-5" /> },
        { path: "/storage", label: "Storage", icon: <HardDrive className="mr-3 h-5 w-5" /> },
        { path: "/settings", label: "User Settings", icon: <UserCircle className="mr-3 h-5 w-5" /> }
      ]
    }
  ];

  const sidebarWidth = collapsed ? "w-0 md:w-16" : "w-64";

  return (
    <div className={cn(
      "h-full bg-gray-900 text-white transition-all duration-300 flex-shrink-0",
      sidebarWidth,
      className
    )}>
      <div className="flex items-center justify-between px-4 py-5 border-b border-gray-800">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Video className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-medium">Stream Manager</h1>
          </div>
        )}
        <Button 
          variant="ghost" 
          size="icon"
          onClick={toggleSidebar}
          className="text-white hover:bg-gray-800"
        >
          {collapsed ? <Menu className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>
      
      {!collapsed && user && (
        <div className="px-4 py-3 mb-2">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-medium">
              {user.username.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="font-medium">{user.fullName || user.username}</div>
              <div className="text-sm text-gray-500">{user.isAdmin ? "Administrator" : "User"}</div>
            </div>
          </div>
        </div>
      )}
      
      <div className="overflow-y-auto h-[calc(100vh-150px)]">
        {navItems.map((group, idx) => (
          <div key={idx} className="py-2">
            {!collapsed && (
              <div className="px-4 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {group.group}
              </div>
            )}
            <ul>
              {group.items.map((item) => {
                // For admin-only pages
                if (item.adminOnly && user && !user.isAdmin) {
                  return null;
                }
                
                const isActive = location === item.path;
                
                return (
                  <li className="mb-1" key={item.path}>
                    <Link 
                      href={item.path} 
                      onClick={(e) => {
                        // Smooth scroll to top when navigation changes
                        const mainContent = document.getElementById('main-content');
                        if (mainContent) {
                          mainContent.scrollTo({ top: 0, behavior: 'smooth' });
                        }
                      }}
                      className={cn(
                        "flex items-center px-4 py-2 rounded-r-lg transition-colors cursor-pointer",
                        isActive 
                          ? "bg-primary text-white" 
                          : "text-gray-400 hover:text-white hover:bg-gray-800",
                        collapsed && "justify-center px-0"
                      )}>
                      {item.icon}
                      {!collapsed && <span>{item.label}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
