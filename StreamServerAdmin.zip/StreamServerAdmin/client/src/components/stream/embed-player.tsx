import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { apiRequest } from "@/lib/queryClient";
import type { Stream } from "@shared/schema";
import Hls from "hls.js";

interface EmbedPlayerProps {
  streamKey: string;
  autoplay?: boolean;
  controls?: boolean;
  muted?: boolean;
  width?: string | number;
  height?: string | number;
  className?: string;
}

export function EmbedPlayer({
  streamKey,
  autoplay = true,
  controls = true,
  muted = false,
  width = "100%",
  height = "100%",
  className = "",
}: EmbedPlayerProps) {
  const [stream, setStream] = useState<Stream | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  
  useEffect(() => {
    const fetchStream = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const res = await apiRequest("GET", `/api/streams/key/${streamKey}`);
        const data = await res.json();
        
        if (res.ok) {
          setStream(data);
        } else {
          setError(data.error || "Failed to load stream");
        }
      } catch (err) {
        setError("Stream not found or unavailable");
      } finally {
        setLoading(false);
      }
    };
    
    fetchStream();
  }, [streamKey]);
  
  // Set up HLS.js when the video element is mounted and stream is active
  useEffect(() => {
    if (!stream?.isActive || !videoRef.current) return;
    
    // Clean up any existing HLS instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    
    // Build the video URL
    const videoUrl = `/rtmp/${stream.streamKey}/index.m3u8`;
    
    // Use HLS.js if supported
    if (Hls.isSupported()) {
      const hls = new Hls({
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
        enableWorker: true,
        lowLatencyMode: true,
      });
      
      hls.loadSource(videoUrl);
      hls.attachMedia(videoRef.current);
      
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (autoplay && videoRef.current) {
          videoRef.current.play().catch(error => {
            console.warn("Autoplay failed:", error);
          });
        }
      });
      
      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.error("HLS network error, trying to recover...");
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.error("HLS media error, trying to recover...");
              hls.recoverMediaError();
              break;
            default:
              console.error("HLS fatal error:", data);
              hls.destroy();
              setError("Failed to play stream: " + data.details);
              break;
          }
        }
      });
      
      hlsRef.current = hls;
    } 
    // Fallback for browsers with native HLS support (Safari, iOS)
    else if (videoRef.current.canPlayType('application/vnd.apple.mpegurl')) {
      videoRef.current.src = videoUrl;
      if (autoplay) {
        videoRef.current.play().catch(error => {
          console.warn("Autoplay failed:", error);
        });
      }
    }
    // No HLS support
    else {
      setError("Your browser does not support HLS playback");
    }
    
    // Clean up on unmount
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [stream, autoplay, streamKey]);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center bg-black/5 w-full h-full min-h-[240px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error || !stream) {
    return (
      <Alert variant="destructive" className="m-4">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          {error || "Stream not found or unavailable"}
        </AlertDescription>
      </Alert>
    );
  }
  
  // Check if stream is active
  if (!stream.isActive) {
    return (
      <div className="flex flex-col items-center justify-center bg-black/5 w-full h-full min-h-[240px] p-4 text-center">
        <AlertCircle className="h-8 w-8 mb-2 text-amber-500" />
        <h3 className="font-semibold text-lg mb-1">Stream Offline</h3>
        <p className="text-sm text-muted-foreground">
          This stream is currently offline. Please check back later.
        </p>
      </div>
    );
  }
  
  return (
    <Card className={`overflow-hidden ${className}`} style={{ width, height }}>
      <video
        ref={videoRef}
        autoPlay={autoplay}
        controls={controls}
        muted={muted}
        playsInline
        className="w-full h-full object-contain bg-black"
      />
    </Card>
  );
}