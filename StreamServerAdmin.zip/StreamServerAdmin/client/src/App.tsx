import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import DashboardPage from "./pages/dashboard-page";
import AuthPage from "./pages/auth-page";
import StreamsPage from "./pages/streams-page";
import UsersPage from "./pages/users-page";
import RTMPConfigPage from "./pages/rtmp-config-page";
import AnalyticsPage from "./pages/analytics-page";
import SettingsPage from "./pages/settings-page";
import ProfileSettingsPage from "./pages/profile-settings-page";
import StorageSettingsPage from "./pages/storage-settings-page";
import IntegrationPage from "./pages/integration-page";
import EmbedPage from "./pages/embed-page";
import DemoPage from "./pages/demo-page";
import ServerMetricsPage from "./pages/server-metrics-page";
import VpsInfoPage from "./pages/vps-info-page";
import ServerConfigPage from "./pages/server-config-page";
import NginxManagementPage from "./pages/nginx-management-page";
import SSLSettingsPage from "./pages/ssl-settings-page";
import { ThemeProvider } from "@/components/theme-provider";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/streams" component={StreamsPage} />
      <ProtectedRoute path="/users" component={UsersPage} />
      <ProtectedRoute path="/rtmp-config" component={RTMPConfigPage} />
      <ProtectedRoute path="/analytics" component={AnalyticsPage} />
      <ProtectedRoute path="/metrics" component={ServerMetricsPage} />
      <ProtectedRoute path="/vps-info" component={VpsInfoPage} />
      <ProtectedRoute path="/server-config" component={ServerConfigPage} />
      <ProtectedRoute path="/settings" component={ProfileSettingsPage} />
      <ProtectedRoute path="/storage" component={StorageSettingsPage} />
      <ProtectedRoute path="/integrations" component={IntegrationPage} />
      <ProtectedRoute path="/nginx-management" component={NginxManagementPage} />
      <ProtectedRoute path="/ssl-settings" component={SSLSettingsPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/embed/:streamKey" component={EmbedPage} />
      <Route path="/demo" component={DemoPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system">
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
