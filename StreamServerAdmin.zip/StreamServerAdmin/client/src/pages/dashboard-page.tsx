import { DashboardLayout } from "@/components/dashboard/layout";
import { MetricsCard } from "@/components/dashboard/metrics-card";
import { ServerStatus } from "@/components/dashboard/server-status";
import { ServerMetrics } from "@/components/dashboard/server-metrics";
import { QuickActions } from "@/components/dashboard/quick-actions";
import { ActiveStreams } from "@/components/dashboard/active-streams";
import { ActivityLog } from "@/components/dashboard/activity-log";
import { useQuery } from "@tanstack/react-query";
import { Stream, Server } from "@shared/schema";
import { Video, Users, Gauge, Server as ServerIcon } from "lucide-react";

export default function DashboardPage() {
  const { data: activeStreams } = useQuery<Stream[]>({
    queryKey: ["/api/streams/active"],
  });
  
  const { data: servers } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });
  
  const defaultServer = servers?.[0];
  
  // Calculate total viewers across all active streams
  const totalViewers = activeStreams?.reduce((sum, stream) => sum + (stream.viewers || 0), 0) || 0;
  
  // Calculate total bandwidth used by active streams (in GB)
  const totalBandwidth = (
    activeStreams?.reduce((sum, stream) => sum + (stream.bandwidth || 0), 0) || 0
  ) / (1024 * 1024 * 1024); // Convert bytes to GB
  
  // Get formatted server status
  const serverStatus = defaultServer?.status === "online" ? "Healthy" : "Offline";

  return (
    <DashboardLayout title="Dashboard">
      {/* Overview Section with Metrics */}
      <section className="mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricsCard
            title="Active Streams"
            value={activeStreams?.length || 0}
            icon={Video}
            change={"+2"}
            changeDirection="up"
          />
          
          <MetricsCard
            title="Total Viewers"
            value={totalViewers}
            icon={Users}
            change={"+18%"}
            changeDirection="up"
          />
          
          <MetricsCard
            title="Bandwidth Usage"
            value={totalBandwidth.toFixed(1)}
            suffix="GB"
            icon={Gauge}
            change={"+24%"}
            changeDirection="up"
          />
          
          <MetricsCard
            title="Server Status"
            value={serverStatus}
            icon={ServerIcon}
            suffix={defaultServer?.uptime ? `${Math.floor(defaultServer.uptime / 86400)}d uptime` : ""}
          />
        </div>
      </section>
      
      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Streams Table - Takes up 2/3 of the width on large screens */}
        <div className="lg:col-span-2">
          <ActiveStreams />
        </div>
        
        {/* Server Status and Quick Actions - Takes up 1/3 of the width on large screens */}
        <div className="space-y-6">
          {defaultServer && <ServerStatus serverId={defaultServer.id} />}
          <QuickActions />
        </div>
      </div>
      
      {/* Server Metrics Section */}
      <section className="mt-6 mb-6">
        {defaultServer && <ServerMetrics serverId={defaultServer.id} />}
      </section>
      
      {/* Recent Activity Section */}
      <section className="mt-6">
        <ActivityLog />
      </section>
    </DashboardLayout>
  );
}
