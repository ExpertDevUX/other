import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, AlertCircle, Copy, Check } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface DemoStreamData {
  id: number;
  name: string;
  streamKey: string;
  embedUrl: string;
  iframeCode: string;
}

export default function DemoPage() {
  const [copied, setCopied] = useState<string | null>(null);
  
  const { data, isLoading, error } = useQuery<DemoStreamData>({
    queryKey: ["/api/demo-stream"],
  });
  
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
        <p>Loading demo stream...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <Alert variant="destructive" className="max-w-xl">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error loading demo</AlertTitle>
          <AlertDescription>
            There was an error loading the demo stream. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="border-b py-6">
        <div className="container flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">WPStream Demo</h1>
            <p className="text-muted-foreground">Embed streaming functionality on any website</p>
          </div>
          <Button onClick={() => window.location.href = "/auth"}>Sign In</Button>
        </div>
      </header>
      
      <main className="container py-8 flex-1">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Live Stream Preview</CardTitle>
                <CardDescription>
                  This is a demo stream showing our embed functionality
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="responsive-iframe-container">
                  <iframe 
                    src={`/embed/${data?.streamKey}`} 
                    frameBorder="0" 
                    allowFullScreen 
                  />
                </div>
              </CardContent>
            </Card>
            
            <h2 className="text-lg font-semibold mb-4">Features</h2>
            <ul className="space-y-2 list-disc list-inside">
              <li>Responsive video player with adaptive streaming</li>
              <li>Low-latency broadcasting for real-time interaction</li>
              <li>Support for custom branding and overlays</li>
              <li>Simple integration with any website or CMS</li>
              <li>WordPress plugin with shortcodes for easy embedding</li>
              <li>Analytics and viewer tracking</li>
            </ul>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Embedding Options</CardTitle>
                <CardDescription>
                  Choose how you want to embed streams on your website
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="iframe">
                  <TabsList className="grid w-full grid-cols-3 mb-4">
                    <TabsTrigger value="iframe">Iframe</TabsTrigger>
                    <TabsTrigger value="widget">Widget</TabsTrigger>
                    <TabsTrigger value="wp">WordPress</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="iframe">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium mb-2">Iframe Embed Code</h3>
                        <div className="relative">
                          <Input
                            readOnly
                            className="font-mono text-xs pr-24"
                            value={data?.iframeCode || ''}
                            onClick={(e) => e.currentTarget.select()}
                          />
                          <Button 
                            className="absolute right-1 top-1 h-8" 
                            size="sm"
                            onClick={() => copyToClipboard(data?.iframeCode || '', 'iframe')}
                          >
                            {copied === 'iframe' ? (
                              <>
                                <Check className="mr-1 h-4 w-4" />
                                Copied
                              </>
                            ) : (
                              <>
                                <Copy className="mr-1 h-4 w-4" />
                                Copy
                              </>
                            )}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Add this code to any HTML page to embed the stream.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="widget">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium mb-2">JavaScript Widget</h3>
                        <div className="relative">
                          <Input
                            readOnly
                            className="font-mono text-xs pr-24"
                            value={`<div class="wpstream-widget" data-stream-key="${data?.streamKey}"></div>`}
                            onClick={(e) => e.currentTarget.select()}
                          />
                          <Button 
                            className="absolute right-1 top-1 h-8" 
                            size="sm"
                            onClick={() => copyToClipboard(`<div class="wpstream-widget" data-stream-key="${data?.streamKey}"></div>`, 'widget-div')}
                          >
                            {copied === 'widget-div' ? (
                              <>
                                <Check className="mr-1 h-4 w-4" />
                                Copied
                              </>
                            ) : (
                              <>
                                <Copy className="mr-1 h-4 w-4" />
                                Copy
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium mb-2">Script Tag</h3>
                        <div className="relative">
                          <Input
                            readOnly
                            className="font-mono text-xs pr-24"
                            value={`<script src="${window.location.origin}/widget.js"></script>`}
                            onClick={(e) => e.currentTarget.select()}
                          />
                          <Button 
                            className="absolute right-1 top-1 h-8" 
                            size="sm"
                            onClick={() => copyToClipboard(`<script src="${window.location.origin}/widget.js"></script>`, 'widget-script')}
                          >
                            {copied === 'widget-script' ? (
                              <>
                                <Check className="mr-1 h-4 w-4" />
                                Copied
                              </>
                            ) : (
                              <>
                                <Copy className="mr-1 h-4 w-4" />
                                Copy
                              </>
                            )}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Add the widget div where you want the player, and the script tag at the end of your body.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="wp">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium mb-2">WordPress Shortcode</h3>
                        <div className="relative">
                          <Input
                            readOnly
                            className="font-mono text-xs pr-24"
                            value={`[wpstream_player key="${data?.streamKey}"]`}
                            onClick={(e) => e.currentTarget.select()}
                          />
                          <Button 
                            className="absolute right-1 top-1 h-8" 
                            size="sm"
                            onClick={() => copyToClipboard(`[wpstream_player key="${data?.streamKey}"]`, 'shortcode')}
                          >
                            {copied === 'shortcode' ? (
                              <>
                                <Check className="mr-1 h-4 w-4" />
                                Copied
                              </>
                            ) : (
                              <>
                                <Copy className="mr-1 h-4 w-4" />
                                Copy
                              </>
                            )}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Use with our WordPress plugin. Install the WPStream plugin on your WordPress site first.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
            
            <div className="mt-8">
              <h2 className="text-lg font-semibold mb-2">Get Started</h2>
              <p className="mb-4">
                Create your own streaming channels and manage them with your customized dashboard.
              </p>
              <Button onClick={() => window.location.href = "/auth"}>Sign Up Now</Button>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="border-t py-6 bg-muted/50">
        <div className="container text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} WPStream. All rights reserved.
        </div>
      </footer>
    </div>
  );
}