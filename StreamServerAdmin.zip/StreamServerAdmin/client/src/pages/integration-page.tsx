import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Switch } from "@/components/ui/switch";
import { DashboardLayout } from "@/components/dashboard/layout";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { insertIntegrationSchema, wpStreamConfigSchema, type Integration } from "@shared/schema";

// Enhanced schema with validation rules
const wpStreamFormSchema = wpStreamConfigSchema.extend({
  enabled: z.boolean().default(true)
});

type WpStreamFormValues = z.infer<typeof wpStreamFormSchema>;

export default function IntegrationPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testStatus, setTestStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  
  // Get WpStream integration if it exists
  const { data: wpStreamIntegration, isLoading } = useQuery<Integration | null>({
    queryKey: ["/api/integrations/type/wpstream"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/integrations/type/wpstream");
        if (res.status === 404) return null;
        return await res.json();
      } catch (error) {
        console.error("Error fetching WpStream integration:", error);
        return null;
      }
    }
  });

  // Form setup
  const form = useForm<WpStreamFormValues>({
    resolver: zodResolver(wpStreamFormSchema),
    defaultValues: {
      wpUrl: "",
      apiKey: "",
      apiSecret: "",
      syncStreams: true,
      syncEvents: true,
      enabled: true
    }
  });

  // Populate form when integration data is loaded
  useEffect(() => {
    if (wpStreamIntegration && wpStreamIntegration.config) {
      const config = wpStreamIntegration.config as unknown as WpStreamFormValues;
      form.reset({
        wpUrl: config.wpUrl || "",
        apiKey: config.apiKey || "",
        apiSecret: config.apiSecret || "",
        syncStreams: config.syncStreams ?? true,
        syncEvents: config.syncEvents ?? true,
        enabled: wpStreamIntegration.enabled ?? true
      });
    }
  }, [wpStreamIntegration, form]);

  // Save integration settings
  const saveMutation = useMutation({
    mutationFn: async (data: WpStreamFormValues) => {
      const payload = {
        name: "WpStream Integration",
        type: "wpstream",
        config: data,
        enabled: data.enabled
      };
      
      if (wpStreamIntegration) {
        // Update existing integration
        const res = await apiRequest(
          "PATCH", 
          `/api/integrations/${wpStreamIntegration.id}`, 
          payload
        );
        return await res.json();
      } else {
        // Create new integration
        const res = await apiRequest(
          "POST", 
          "/api/integrations", 
          payload
        );
        return await res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: "Integration settings saved",
        description: "Your WpStream integration settings have been updated."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/type/wpstream"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save settings",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Test connection to WpStream
  const testConnection = async () => {
    setTestStatus("loading");
    try {
      const data = form.getValues();
      const res = await apiRequest(
        "POST", 
        "/api/integrations/wpstream/test", 
        data
      );
      
      const result = await res.json();
      if (result.success) {
        setTestStatus("success");
        toast({
          title: "Connection successful",
          description: "Successfully connected to WpStream."
        });
      } else {
        setTestStatus("error");
        toast({
          title: "Connection failed",
          description: result.message || "Failed to connect to WpStream.",
          variant: "destructive"
        });
      }
    } catch (error) {
      setTestStatus("error");
      toast({
        title: "Connection failed",
        description: "Failed to connect to WpStream. Please check your credentials.",
        variant: "destructive"
      });
    }
  };

  const onSubmit = (data: WpStreamFormValues) => {
    saveMutation.mutate(data);
  };

  // Status indicator for connection test
  const renderTestStatus = () => {
    switch (testStatus) {
      case "loading":
        return <Loader2 className="h-4 w-4 animate-spin" />;
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  // No need for manual scroll reset since it's handled by DashboardLayout

  return (
    <DashboardLayout title="Integrations">
      <div className="container mx-auto py-6 max-w-4xl">
        <Card className="mb-0">
          <CardHeader className="sticky top-0 z-10 bg-card">
            <CardTitle>WpStream Integration</CardTitle>
            <CardDescription>
              Configure integration with WpStream WordPress plugin for syncing streams and events
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-6">
            {isLoading ? (
              <div className="flex justify-center py-6">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <Form {...form}>
                <form id="integration-form" onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="wpUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>WordPress Site URL</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://yourwordpress.com" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          The URL of your WordPress site with WpStream plugin installed
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="apiKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>API Key</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="WpStream API Key" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          API Key from WpStream configuration in WordPress
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="apiSecret"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>API Secret</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="WpStream API Secret" 
                            type="password"
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          API Secret from WpStream configuration in WordPress
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="syncStreams"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Sync Streams</FormLabel>
                            <FormDescription>
                              Synchronize stream information with WpStream
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="syncEvents"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Sync Events</FormLabel>
                            <FormDescription>
                              Send stream events to WpStream (start/stop/viewers)
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="enabled"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Enable Integration</FormLabel>
                          <FormDescription>
                            Turn integration on or off without removing the settings
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={testConnection}
                      disabled={testStatus === "loading" || saveMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      Test Connection {renderTestStatus()}
                    </Button>
                    
                    <Button 
                      type="submit" 
                      disabled={saveMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      {saveMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                      Save Settings
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}