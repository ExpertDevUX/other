import { DashboardLayout } from "@/components/dashboard/layout";
import { useQuery } from "@tanstack/react-query";
import { Stream, Activity, Server } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart as BarChartIcon, 
  LineChart as LineChartIcon, 
  PieChart as PieChartIcon, 
  Activity as ActivityIcon,
  Loader2
} from "lucide-react";
import { useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Chart colors from theme
const CHART_COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

// Time range options
const TIME_RANGES = [
  { value: "24h", label: "Last 24 Hours" },
  { value: "7d", label: "Last 7 Days" },
  { value: "30d", label: "Last 30 Days" },
  { value: "90d", label: "Last 90 Days" },
];

// Generate mock data for demonstration purposes
// In a real app, this would come from the API
const generateViewerData = (days: number) => {
  const data = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      viewers: Math.floor(Math.random() * 200) + 50,
    });
  }
  
  return data;
};

const generateBandwidthData = (days: number) => {
  const data = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      inbound: Math.floor(Math.random() * 50) + 10,
      outbound: Math.floor(Math.random() * 100) + 30,
    });
  }
  
  return data;
};

const generateStreamData = () => {
  return [
    { name: "Gaming", viewers: 420, percentage: 42 },
    { name: "IRL", viewers: 280, percentage: 28 },
    { name: "Music", viewers: 190, percentage: 19 },
    { name: "Talk Shows", viewers: 110, percentage: 11 },
  ];
};

const generateServerMetrics = (days: number) => {
  const data = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      cpu: Math.floor(Math.random() * 40) + 10,
      memory: Math.floor(Math.random() * 30) + 30,
      network: Math.floor(Math.random() * 60) + 20,
    });
  }
  
  return data;
};

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("7d");
  
  // Get time range in days
  const getDays = () => {
    switch (timeRange) {
      case "24h": return 1;
      case "7d": return 7;
      case "30d": return 30;
      case "90d": return 90;
      default: return 7;
    }
  };
  
  const { data: streams, isLoading: isLoadingStreams } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });
  
  const { data: activities, isLoading: isLoadingActivities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });
  
  const { data: servers, isLoading: isLoadingServers } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });
  
  const isLoading = isLoadingStreams || isLoadingActivities || isLoadingServers;
  
  // Generate data based on selected time range
  const viewerData = generateViewerData(getDays());
  const bandwidthData = generateBandwidthData(getDays());
  const streamTypeData = generateStreamData();
  const serverMetricsData = generateServerMetrics(getDays());
  
  // Calculate summary metrics
  const totalViewers = viewerData.reduce((sum, item) => sum + item.viewers, 0);
  const avgViewers = Math.round(totalViewers / viewerData.length);
  const peakViewers = Math.max(...viewerData.map(item => item.viewers));
  
  const totalBandwidth = bandwidthData.reduce((sum, item) => sum + item.inbound + item.outbound, 0);
  const avgBandwidth = Math.round(totalBandwidth / bandwidthData.length);

  return (
    <DashboardLayout title="Analytics">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Stream Analytics</h1>
          <p className="text-muted-foreground">
            View detailed analytics and performance metrics for your streams
          </p>
        </div>
        
        <div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              {TIME_RANGES.map((range) => (
                <SelectItem key={range.value} value={range.value}>
                  {range.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Average Viewers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{avgViewers}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {timeRange === "24h" ? "Past 24 hours" : `Past ${getDays()} days`}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Peak Viewers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{peakViewers}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {timeRange === "24h" ? "Past 24 hours" : `Past ${getDays()} days`}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Active Streams
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{streams?.filter(s => s.isActive).length || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Currently live
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Bandwidth Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{avgBandwidth} <span className="text-xl">GB</span></div>
                <p className="text-xs text-muted-foreground mt-1">
                  Avg. daily usage
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="viewership" className="space-y-6">
            <TabsList>
              <TabsTrigger value="viewership" className="flex items-center">
                <LineChartIcon className="h-4 w-4 mr-2" />
                Viewership
              </TabsTrigger>
              <TabsTrigger value="bandwidth" className="flex items-center">
                <BarChartIcon className="h-4 w-4 mr-2" />
                Bandwidth
              </TabsTrigger>
              <TabsTrigger value="streams" className="flex items-center">
                <PieChartIcon className="h-4 w-4 mr-2" />
                Streams
              </TabsTrigger>
              <TabsTrigger value="server" className="flex items-center">
                <ActivityIcon className="h-4 w-4 mr-2" />
                Server Performance
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="viewership">
              <Card>
                <CardHeader>
                  <CardTitle>Viewer Trends</CardTitle>
                  <CardDescription>
                    Number of viewers over time
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={viewerData}
                        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      >
                        <defs>
                          <linearGradient id="colorViewers" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={CHART_COLORS[0]} stopOpacity={0.8}/>
                            <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0.1}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Area 
                          type="monotone" 
                          dataKey="viewers" 
                          stroke={CHART_COLORS[0]} 
                          fillOpacity={1} 
                          fill="url(#colorViewers)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="bandwidth">
              <Card>
                <CardHeader>
                  <CardTitle>Bandwidth Usage</CardTitle>
                  <CardDescription>
                    Inbound and outbound bandwidth usage over time (GB)
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={bandwidthData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="inbound" fill={CHART_COLORS[1]} name="Inbound (GB)" />
                        <Bar dataKey="outbound" fill={CHART_COLORS[2]} name="Outbound (GB)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="streams">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Stream Types</CardTitle>
                    <CardDescription>
                      Distribution of viewers by stream category
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={streamTypeData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="viewers"
                            label={({ name, percentage }) => `${name}: ${percentage}%`}
                          >
                            {streamTypeData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Stream Performance</CardTitle>
                    <CardDescription>
                      Top performing streams by viewer count
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={streams?.slice(0, 5).map(s => ({
                            name: s.name,
                            viewers: s.viewers || 0
                          })) || []}
                          margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                          <XAxis type="number" />
                          <YAxis type="category" dataKey="name" />
                          <Tooltip />
                          <Bar dataKey="viewers" fill={CHART_COLORS[3]} name="Viewers" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="server">
              <Card>
                <CardHeader>
                  <CardTitle>Server Metrics</CardTitle>
                  <CardDescription>
                    CPU, memory, and network usage over time
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={serverMetricsData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="cpu" stroke={CHART_COLORS[0]} name="CPU (%)" />
                        <Line type="monotone" dataKey="memory" stroke={CHART_COLORS[1]} name="Memory (%)" />
                        <Line type="monotone" dataKey="network" stroke={CHART_COLORS[2]} name="Network (%)" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </DashboardLayout>
  );
}
