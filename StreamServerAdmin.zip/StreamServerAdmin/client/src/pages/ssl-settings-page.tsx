import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle, Clock, ExternalLink, Lock, ShieldAlert, ShieldCheck, XCircle } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/layout";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

interface SSLStatus {
  installed: boolean;
  domain: string | null;
  expiryDate: string | null;
  autoRenewal: boolean;
  lastRenewalAttempt: string | null;
  certPath: string | null;
  keyPath: string | null;
}

interface PortInfo {
  port: number;
  service: string;
  required: boolean;
  description: string;
}

const sslFormSchema = z.object({
  domain: z.string().min(3, "Domain must be at least 3 characters")
    .refine(val => /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/.test(val), {
      message: "Please enter a valid domain name (e.g. example.com)"
    }),
  email: z.string().email("Please enter a valid email address"),
  autoRenewal: z.boolean().default(true)
});

type SSLFormValues = z.infer<typeof sslFormSchema>;

export default function SSLSettingsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showInstructions, setShowInstructions] = useState(false);
  
  // Fetch current SSL status
  const { data: sslStatus, isLoading: isStatusLoading } = useQuery<SSLStatus>({
    queryKey: ['/api/ssl/status'],
    enabled: !!user?.isAdmin,
    refetchInterval: 60000 // Refresh every minute
  });
  
  // Fetch required ports
  const { data: portsInfo, isLoading: isPortsLoading } = useQuery<PortInfo[]>({
    queryKey: ['/api/ssl/ports'],
    enabled: !!user
  });
  
  // Configure form
  const form = useForm<SSLFormValues>({
    resolver: zodResolver(sslFormSchema),
    defaultValues: {
      domain: "",
      email: "",
      autoRenewal: true
    }
  });
  
  // Get site configuration to pre-fill domain
  const { data: siteConfig } = useQuery<{
    domain?: string;
    adminEmail?: string;
  }>({
    queryKey: ['/api/site-config'],
    enabled: !!user?.isAdmin
  });
  
  useEffect(() => {
    if (siteConfig?.domain) {
      form.setValue('domain', siteConfig.domain);
    }
    if (siteConfig?.adminEmail) {
      form.setValue('email', siteConfig.adminEmail);
    }
  }, [siteConfig, form]);
  
  // Install SSL mutation
  const installSSLMutation = useMutation({
    mutationFn: async (data: SSLFormValues) => {
      const res = await apiRequest('POST', '/api/ssl/install', data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "SSL Certificate Request Initiated",
        description: "The SSL certificate installation process has started. This may take a few minutes to complete.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ssl/status'] });
    },
    onError: (error: Error) => {
      toast({
        title: "SSL Certificate Installation Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Renew SSL mutation
  const renewSSLMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/ssl/renew', {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "SSL Certificate Renewal Initiated",
        description: "The SSL certificate renewal process has started. This may take a few minutes to complete.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ssl/status'] });
    },
    onError: (error: Error) => {
      toast({
        title: "SSL Certificate Renewal Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Form submission handler
  const onSubmit = (data: SSLFormValues) => {
    installSSLMutation.mutate(data);
  };
  
  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString();
  };
  
  // Check if certificate is expired or about to expire
  const getCertificateStatus = () => {
    if (!sslStatus?.expiryDate) return 'notInstalled';
    const expiryDate = new Date(sslStatus.expiryDate);
    const today = new Date();
    const daysToExpiry = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysToExpiry < 0) return 'expired';
    if (daysToExpiry < 7) return 'warning';
    return 'valid';
  };
  
  // Render certificate status badge
  const renderStatusBadge = () => {
    const status = getCertificateStatus();
    
    switch(status) {
      case 'notInstalled':
        return <Badge variant="outline" className="bg-muted text-muted-foreground"><ShieldAlert className="h-4 w-4 mr-1" /> Not Installed</Badge>;
      case 'expired':
        return <Badge variant="destructive"><XCircle className="h-4 w-4 mr-1" /> Expired</Badge>;
      case 'warning':
        return <Badge variant="outline" className="bg-yellow-200 text-yellow-800"><Clock className="h-4 w-4 mr-1" /> Expiring Soon</Badge>;
      case 'valid':
        return <Badge variant="outline" className="bg-green-100 text-green-800"><CheckCircle className="h-4 w-4 mr-1" /> Valid</Badge>;
      default:
        return null;
    }
  };
  
  return (
    <DashboardLayout title="SSL Settings">
      {!user?.isAdmin ? (
        <Alert variant="destructive" className="mb-6">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Access Denied</AlertTitle>
          <AlertDescription>
            You need administrator privileges to access SSL configuration.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <div className="grid gap-6 md:grid-cols-2">
            {/* SSL Status Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Lock className="mr-2 h-5 w-5" />
                    SSL Status
                  </div>
                  {renderStatusBadge()}
                </CardTitle>
                <CardDescription>
                  Current SSL certificate information for your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isStatusLoading ? (
                  <div className="h-[200px] flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-sm font-medium">Status:</div>
                      <div className="text-sm">
                        {sslStatus?.installed ? (
                          <span className="text-green-600 font-medium flex items-center">
                            <ShieldCheck className="h-4 w-4 mr-1" /> Installed
                          </span>
                        ) : (
                          <span className="text-muted-foreground flex items-center">
                            <ShieldAlert className="h-4 w-4 mr-1" /> Not Installed
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-sm font-medium">Domain:</div>
                      <div className="text-sm">{sslStatus?.domain || 'Not configured'}</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-sm font-medium">Expiry Date:</div>
                      <div className="text-sm">{formatDate(sslStatus?.expiryDate || null)}</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-sm font-medium">Auto Renewal:</div>
                      <div className="text-sm">
                        {sslStatus?.autoRenewal ? (
                          <span className="text-green-600 font-medium">Enabled</span>
                        ) : (
                          <span className="text-amber-600">Disabled</span>
                        )}
                      </div>
                    </div>
                    
                    {sslStatus?.installed && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => renewSSLMutation.mutate()}
                        disabled={renewSSLMutation.isPending}
                        className="w-full mt-4"
                      >
                        {renewSSLMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                            Renewing...
                          </>
                        ) : (
                          'Renew Certificate'
                        )}
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* SSL Install Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center">
                  <Lock className="mr-2 h-5 w-5" />
                  Install SSL Certificate
                </CardTitle>
                <CardDescription>
                  Install a free Let's Encrypt SSL certificate for your domain
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="domain"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Domain Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="example.com"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Enter your fully qualified domain name
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="admin@example.com"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Used for renewal notifications
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="autoRenewal"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Auto Renewal</FormLabel>
                            <FormDescription>
                              Automatically renew SSL certificate before expiry
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <div className="pt-2">
                      <Button
                        type="submit"
                        disabled={installSSLMutation.isPending}
                        className="w-full"
                      >
                        {installSSLMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                            Installing...
                          </>
                        ) : (
                          'Install SSL Certificate'
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
          
          {/* Instructions Toggle */}
          <div className="mt-6">
            <Button 
              variant="ghost" 
              onClick={() => setShowInstructions(!showInstructions)}
              className="flex items-center text-sm text-muted-foreground hover:text-foreground"
            >
              {showInstructions ? 'Hide' : 'Show'} SSL Setup Instructions
            </Button>
          </div>
          
          {/* Setup Instructions */}
          {showInstructions && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>SSL Setup Instructions</CardTitle>
                <CardDescription>
                  Follow these steps to set up SSL for your streaming server
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">1. Point your domain to this server</h3>
                  <p className="text-sm text-muted-foreground">
                    Create an A record in your domain's DNS settings that points to your server's IP address.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">2. Open required ports</h3>
                  <p className="text-sm text-muted-foreground">
                    Ensure that ports 80 and 443 are open on your server's firewall for Let's Encrypt validation.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">3. Install the SSL certificate</h3>
                  <p className="text-sm text-muted-foreground">
                    Fill out the form with your domain name and contact email, then click "Install SSL Certificate".
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">4. Test the secure connection</h3>
                  <p className="text-sm text-muted-foreground">
                    After installation completes, visit your domain with https:// to verify it's working properly.
                  </p>
                </div>
                
                <Alert>
                  <AlertTitle className="flex items-center">
                    <ShieldCheck className="h-4 w-4 mr-2" />
                    Important Notes
                  </AlertTitle>
                  <AlertDescription className="text-sm mt-2">
                    <ul className="list-disc pl-5 space-y-1">
                      <li>The domain must be publicly accessible for Let's Encrypt validation</li>
                      <li>SSL installation may take up to 5 minutes to complete</li>
                      <li>Certificates are valid for 90 days and will auto-renew if enabled</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}
          
          {/* Required Ports Table */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ExternalLink className="mr-2 h-5 w-5" />
                Required Network Ports
              </CardTitle>
              <CardDescription>
                The following ports need to be open for your streaming server to function properly
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isPortsLoading ? (
                <div className="h-[200px] flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Port</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>Required</TableHead>
                      <TableHead className="hidden md:table-cell">Description</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {portsInfo?.map((port) => (
                      <TableRow key={port.port}>
                        <TableCell className="font-medium">{port.port}</TableCell>
                        <TableCell>{port.service}</TableCell>
                        <TableCell>
                          {port.required ? (
                            <Badge variant="outline" className="bg-green-100 text-green-800">Required</Badge>
                          ) : (
                            <Badge variant="outline" className="bg-blue-100 text-blue-800">Optional</Badge>
                          )}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">{port.description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </DashboardLayout>
  );
}