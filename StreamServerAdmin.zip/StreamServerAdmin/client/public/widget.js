/**
 * WPStream Widget Embed Script
 * This script creates embedded players for streams using data attributes
 */
(function() {
  // Get base URL from script tag
  const scripts = document.getElementsByTagName('script');
  const currentScript = scripts[scripts.length - 1];
  const scriptSrc = currentScript.src;
  const baseUrl = scriptSrc.substring(0, scriptSrc.lastIndexOf('/'));
  
  // Find all widgets on the page
  const widgets = document.querySelectorAll('.wpstream-widget');
  
  function createPlayer(element) {
    const streamKey = element.getAttribute('data-stream-key');
    if (!streamKey) {
      console.error('WPStream widget error: Missing stream key');
      return;
    }
    
    // Get customization options
    const width = element.getAttribute('data-width') || '100%';
    const height = element.getAttribute('data-height') || '360px';
    const autoplay = element.getAttribute('data-autoplay') !== 'false';
    const controls = element.getAttribute('data-controls') !== 'false';
    const muted = element.getAttribute('data-muted') === 'true';
    
    // Create iframe
    const iframe = document.createElement('iframe');
    iframe.src = `${baseUrl}/embed/${streamKey}`;
    iframe.width = width;
    iframe.height = height;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allow', 'autoplay; fullscreen');
    iframe.setAttribute('allowfullscreen', '');
    
    // Add URL parameters
    const params = [];
    if (!autoplay) params.push('autoplay=false');
    if (!controls) params.push('controls=false');
    if (muted) params.push('muted=true');
    
    if (params.length > 0) {
      iframe.src += '?' + params.join('&');
    }
    
    // Replace the widget element with the iframe
    element.parentNode.replaceChild(iframe, element);
  }
  
  // Initialize all widgets
  widgets.forEach(createPlayer);
  
  // Expose API for dynamic usage
  window.WPStream = {
    createPlayer: function(element) {
      createPlayer(element);
    }
  };
})();