# Getting Started with Video Stream Server Manager

This guide will help you get up and running with the Video Stream Server Manager, a powerful platform for managing RTMP streaming servers and video streams.

## Prerequisites

- Node.js 18+ and npm
- PostgreSQL database
- Basic knowledge of terminal/command line

## Installation Options

### Option 1: Local Development

1. **Clone the repository**

   ```bash
   git clone https://github.com/yourusername/video-stream-server.git
   cd video-stream-server
   ```

2. **Run the setup script**

   ```bash
   # Make the script executable
   chmod +x setup.sh
   
   # Run the script
   ./setup.sh
   ```

3. **Edit environment variables**

   Open the `.env` file created by the setup script and update the database connection string and other settings:

   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/database-name
   PORT=5000
   NODE_ENV=development
   SESSION_SECRET=your-session-secret
   ```

4. **Start the development server**

   ```bash
   npm run dev
   ```

5. **Access the application**

   Open your browser and navigate to `http://localhost:5000`

### Option 2: AWS Deployment

1. **Launch an EC2 instance**

   - Create an EC2 instance with Ubuntu 22.04
   - Make sure it has at least 2GB RAM and 1 CPU
   - Configure security groups to allow HTTP (80), HTTPS (443), and RTMP (1935) ports

2. **Connect to your instance**

   ```bash
   ssh -i your-key.pem ubuntu@your-instance-ip
   ```

3. **Download and run the AWS installation script**

   ```bash
   # Download the script
   wget https://raw.githubusercontent.com/yourusername/video-stream-server/main/aws-install.sh
   
   # Make the script executable
   chmod +x aws-install.sh
   
   # Run the script as sudo
   sudo ./aws-install.sh
   ```

4. **Configure the environment variables**

   Edit the `.env` file in the `/opt/stream-manager` directory to set up your database connection and other settings.

5. **Access the application**

   Open your browser and navigate to `http://your-server-ip`

## Default Credentials

After installation, you can log in with the default administrator account:

- **Username:** admin
- **Password:** admin123

**Important:** Change these credentials immediately after your first login for security purposes.

## Core Features

1. **User Management**
   - Create and manage user accounts
   - Set up role-based access control

2. **Stream Management**
   - Create and configure video streams
   - Generate and manage stream keys
   - Monitor active streams

3. **Server Management**
   - Configure RTMP server settings
   - Monitor server performance
   - Restart server when needed

4. **WordPress Integration**
   - Connect with WpStream WordPress plugin
   - Synchronize streams and events

5. **Embedding**
   - Generate embed codes for streams
   - Create iframe widgets
   - Set up custom embedding

## Troubleshooting

### Database Connection Issues

If you encounter database connection errors:

1. Verify your PostgreSQL server is running
2. Check the `DATABASE_URL` environment variable is correct
3. Ensure your database user has proper permissions

### RTMP Server Issues

If the RTMP server isn't working:

1. Check if port 1935 is open and not blocked by a firewall
2. Verify the RTMP server process is running
3. Check server logs for any errors

### Permission Issues (AWS)

If you encounter permission issues on AWS:

1. Make sure you're running installation commands with `sudo`
2. Check directory permissions with `ls -la`
3. Verify the application has write access to necessary directories

## Getting Help

If you need assistance:

- Check the [GitHub Issues](https://github.com/yourusername/video-stream-server/issues) for existing problems and solutions
- Create a new issue with detailed information about your problem
- Contact support at info@hwosecurity.org

## Next Steps

After installation, we recommend:

1. **Change default credentials** for security
2. **Set up SSL/TLS encryption** for production environments
3. **Configure automatic backups** to prevent data loss
4. **Explore advanced features** like quality profiles and cloud integration

Thank you for using Video Stream Server Manager!