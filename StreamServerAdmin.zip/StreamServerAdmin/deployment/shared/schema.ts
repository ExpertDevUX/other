import { pgTable, text, serial, integer, boolean, timestamp, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Cloud provider types
export const CLOUD_PROVIDERS = {
  AWS: "aws",
  DIGITAL_OCEAN: "digital_ocean",
  OVH: "ovh",
  SURFCLOUD: "surfcloud",
  CUSTOM: "custom"
} as const;

// Video quality options
export const VIDEO_QUALITY = {
  UHD_4K: "4k",
  FHD_1080P: "1080p",
  HD_720P: "720p",
  SD_480P: "480p",
  LD_360P: "360p",
  AUTO: "auto"
} as const;

// Quality profiles schema
export const qualityProfiles = pgTable("quality_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  videoBitrate: integer("video_bitrate").notNull(), // in Kbps
  audioBitrate: integer("audio_bitrate").notNull(), // in Kbps
  resolution: text("resolution").notNull(), // e.g., "3840x2160", "1920x1080"
  framerate: integer("framerate").default(30),
  keyframeInterval: integer("keyframe_interval").default(2), // in seconds
  preset: text("preset").default("veryfast"), // x264 preset
  profile: text("profile").default("main"), // h.264 profile
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQualityProfileSchema = createInsertSchema(qualityProfiles).pick({
  name: true,
  userId: true,
  videoBitrate: true,
  audioBitrate: true,
  resolution: true,
  framerate: true,
  keyframeInterval: true,
  preset: true,
  profile: true,
  isDefault: true,
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  email: text("email"),
  fullName: text("full_name"),
  logoUrl: text("logo_url"),
  customCss: text("custom_css"),
  theme: text("theme").default("default"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  isAdmin: true,
  logoUrl: true,
  customCss: true,
  theme: true,
});

// Stream schema
export const streams = pgTable("streams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  streamKey: text("stream_key").notNull().unique(),
  userId: integer("user_id").notNull(),
  isActive: boolean("is_active").default(false),
  viewers: integer("viewers").default(0),
  startedAt: timestamp("started_at"),
  duration: integer("duration").default(0), // in seconds
  quality: text("quality"),
  bandwidth: integer("bandwidth").default(0), // in bytes
  wpStreamId: integer("wp_stream_id"), // ID in WpStream system (if synced)
  isRecording: boolean("is_recording").default(false),
  recordingPath: text("recording_path"),
  hasRecordings: boolean("has_recordings").default(false),
  enableWebRTC: boolean("enable_webrtc").default(false),
  enableHLS: boolean("enable_hls").default(true),
  enableLowLatency: boolean("enable_low_latency").default(false),
  thumbnailUrl: text("thumbnail_url"),
  lastRecordingDate: timestamp("last_recording_date"),
  description: text("description"),
  isPublic: boolean("is_public").default(true),
  category: text("category"),
  tags: text("tags").array(),
  serverId: integer("server_id"),
});

export const insertStreamSchema = createInsertSchema(streams).pick({
  name: true,
  streamKey: true,
  userId: true,
  isActive: true,
  quality: true,
  enableWebRTC: true,
  enableHLS: true,
  enableLowLatency: true,
  description: true,
  isPublic: true,
  category: true,
  tags: true,
  serverId: true,
});

// Server schema
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  host: text("host").notNull(),
  port: integer("port").notNull(),
  isInstalled: boolean("is_installed").default(false),
  status: text("status").default("offline"),
  cpuUsage: integer("cpu_usage").default(0),
  memoryUsage: integer("memory_usage").default(0),
  diskUsage: integer("disk_usage").default(0),
  networkUsage: integer("network_usage").default(0),
  uptime: integer("uptime").default(0), // in seconds
  config: json("config"),
});

export const insertServerSchema = createInsertSchema(servers).pick({
  name: true,
  host: true,
  port: true,
  isInstalled: true,
  status: true,
  config: true,
});

// Activity schema
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // e.g., "stream_started", "server_config_updated"
  message: text("message").notNull(),
  userId: integer("user_id"),
  timestamp: timestamp("timestamp").defaultNow(),
  relatedId: integer("related_id"), // ID of related entity (stream, server, etc.)
  relatedType: text("related_type"), // Type of related entity ("stream", "server", etc.)
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  type: true,
  message: true,
  userId: true,
  relatedId: true,
  relatedType: true,
});

// Integration schema for WordPress and WpStream
export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "wpstream", "youtube", etc.
  name: text("name").notNull(),
  enabled: boolean("enabled").default(false),
  config: json("config").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertIntegrationSchema = createInsertSchema(integrations).pick({
  type: true,
  name: true,
  enabled: true,
  config: true,
});

// WpStream integration config schema
export const wpStreamConfigSchema = z.object({
  wpUrl: z.string().url(),
  apiKey: z.string().min(1),
  apiSecret: z.string().min(1),
  syncStreams: z.boolean().default(true),
  syncEvents: z.boolean().default(true),
});

// Cloud provider schema
export const cloudProviders = pgTable("cloud_providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // aws, digital_ocean, ovh, surfcloud, custom
  apiKey: text("api_key").notNull(),
  apiSecret: text("api_secret"),
  region: text("region"),
  userId: integer("user_id").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  config: json("config"), // Provider-specific configuration
});

export const insertCloudProviderSchema = createInsertSchema(cloudProviders).pick({
  name: true,
  type: true,
  apiKey: true,
  apiSecret: true,
  region: true,
  userId: true,
  config: true,
});

// Bandwidth allocation schema
export const bandwidthAllocations = pgTable("bandwidth_allocations", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  streamId: integer("stream_id"),
  allocated: integer("allocated").notNull().default(0), // in Kbps
  used: integer("used").default(0), // in Kbps
  throttled: boolean("throttled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBandwidthAllocationSchema = createInsertSchema(bandwidthAllocations).pick({
  serverId: true,
  streamId: true,
  allocated: true,
  used: true,
  throttled: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stream = typeof streams.$inferSelect;
export type InsertStream = z.infer<typeof insertStreamSchema>;

export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;

export type WpStreamConfig = z.infer<typeof wpStreamConfigSchema>;

export type CloudProvider = typeof cloudProviders.$inferSelect;
export type InsertCloudProvider = z.infer<typeof insertCloudProviderSchema>;

export type BandwidthAllocation = typeof bandwidthAllocations.$inferSelect;
export type InsertBandwidthAllocation = z.infer<typeof insertBandwidthAllocationSchema>;

export type QualityProfile = typeof qualityProfiles.$inferSelect;
export type InsertQualityProfile = z.infer<typeof insertQualityProfileSchema>;

// Provider-specific config schemas
export const awsConfigSchema = z.object({
  accessKeyId: z.string().min(1),
  secretAccessKey: z.string().min(1),
  region: z.string().min(1),
  instanceType: z.string().default("t2.micro"),
  securityGroupId: z.string().optional(),
  subnetId: z.string().optional(),
  vpcId: z.string().optional(),
  keyName: z.string().optional(),
});

export const digitalOceanConfigSchema = z.object({
  token: z.string().min(1),
  region: z.string().min(1),
  size: z.string().default("s-1vcpu-1gb"),
  sshKeyIds: z.array(z.string()).optional(),
});

export const ovhConfigSchema = z.object({
  applicationKey: z.string().min(1),
  applicationSecret: z.string().min(1),
  consumerKey: z.string().min(1),
  serviceName: z.string().min(1),
  region: z.string().default("rbx"),
  flavor: z.string().default("s1-2"),
});

export const surfcloudConfigSchema = z.object({
  token: z.string().min(1),
  region: z.string().min(1),
  plan: z.string().default("standard"),
});

export type AwsConfig = z.infer<typeof awsConfigSchema>;
export type DigitalOceanConfig = z.infer<typeof digitalOceanConfigSchema>;
export type OvhConfig = z.infer<typeof ovhConfigSchema>;
export type SurfcloudConfig = z.infer<typeof surfcloudConfigSchema>;

// Site configuration schema
export const siteConfig = pgTable("site_config", {
  id: serial("id").primaryKey(),
  siteName: text("site_name").notNull().default("Stream Manager"),
  domain: text("domain"),
  hostname: text("hostname"),
  primaryColor: text("primary_color").default("#3b82f6"),
  siteDescription: text("site_description").default("Video Stream Server Management Platform"),
  faviconUrl: text("favicon_url"),
  contactEmail: text("contact_email"),
  dbName: text("db_name"),
  dbUser: text("db_user"),
  dbHost: text("db_host"),
  isConfigured: boolean("is_configured").default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSiteConfigSchema = createInsertSchema(siteConfig).pick({
  siteName: true,
  domain: true,
  hostname: true,
  primaryColor: true,
  siteDescription: true,
  faviconUrl: true,
  contactEmail: true,
  dbName: true,
  dbUser: true,
  dbHost: true,
  isConfigured: true,
});

export type SiteConfig = typeof siteConfig.$inferSelect;
export type InsertSiteConfig = z.infer<typeof insertSiteConfigSchema>;
