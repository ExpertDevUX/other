import axios, { AxiosInstance } from 'axios';
import { Stream } from '@shared/schema';

/**
 * WpStream Integration Client
 * 
 * This module provides integration with WpStream WordPress plugin
 * for stream management and synchronization.
 */

interface WpStreamConfig {
  wpUrl: string;                // WordPress site URL
  apiKey: string;              // WpStream API key
  apiSecret: string;           // WpStream API secret
  syncStreams: boolean;        // Whether to sync streams with WpStream
  syncEvents: boolean;         // Whether to sync events with WpStream
}

interface WpStreamStream {
  id: number;
  title: string;
  stream_key: string;
  user_id: number;
  status: 'live' | 'offline';
  viewers: number;
  started_at?: string;
  duration?: number;
  description?: string;
}

export class WpStreamClient {
  private client: AxiosInstance;
  private config: WpStreamConfig;
  
  constructor(config: WpStreamConfig) {
    this.config = config;
    
    // Initialize axios client with base configuration
    this.client = axios.create({
      baseURL: `${config.wpUrl}/wp-json/wpstream/v1`,
      headers: {
        'X-WP-Stream-API-Key': config.apiKey,
        'X-WP-Stream-API-Secret': config.apiSecret,
        'Content-Type': 'application/json'
      }
    });
  }
  
  /**
   * Get streams from WpStream
   */
  async getStreams(): Promise<WpStreamStream[]> {
    try {
      const response = await this.client.get('/streams');
      return response.data;
    } catch (error) {
      console.error('Error fetching streams from WpStream:', error);
      return [];
    }
  }
  
  /**
   * Create or update a stream in WpStream
   */
  async syncStream(stream: Stream): Promise<boolean> {
    if (!this.config.syncStreams) return false;
    
    try {
      // Check if stream exists in WpStream
      const wpStreams = await this.getStreams();
      const existingStream = wpStreams.find(s => s.stream_key === stream.streamKey);
      
      const wpStreamData = {
        title: stream.name,
        stream_key: stream.streamKey,
        user_id: stream.userId,
        status: stream.isActive ? 'live' : 'offline',
        viewers: stream.viewers || 0,
        started_at: stream.startedAt ? new Date(stream.startedAt).toISOString() : undefined,
        duration: stream.duration || 0
      };
      
      // If stream exists, update it, otherwise create it
      if (existingStream) {
        await this.client.put(`/streams/${existingStream.id}`, wpStreamData);
      } else {
        await this.client.post('/streams', wpStreamData);
      }
      
      return true;
    } catch (error) {
      console.error('Error syncing stream with WpStream:', error);
      return false;
    }
  }
  
  /**
   * Send an event to WpStream
   */
  async sendEvent(eventType: string, streamKey: string, data: any = {}): Promise<boolean> {
    if (!this.config.syncEvents) return false;
    
    try {
      await this.client.post('/events', {
        type: eventType,
        stream_key: streamKey,
        data
      });
      return true;
    } catch (error) {
      console.error(`Error sending event ${eventType} to WpStream:`, error);
      return false;
    }
  }
  
  /**
   * Stream started event
   */
  async streamStarted(streamKey: string, data: any = {}): Promise<boolean> {
    return this.sendEvent('stream_started', streamKey, data);
  }
  
  /**
   * Stream ended event
   */
  async streamEnded(streamKey: string, data: any = {}): Promise<boolean> {
    return this.sendEvent('stream_ended', streamKey, data);
  }
  
  /**
   * Stream viewers update event
   */
  async updateViewers(streamKey: string, viewers: number): Promise<boolean> {
    return this.sendEvent('viewers_update', streamKey, { viewers });
  }
  
  /**
   * Check if WpStream connection is working
   */
  async testConnection(): Promise<boolean> {
    try {
      const response = await this.client.get('/status');
      return response.data?.status === 'ok';
    } catch (error) {
      console.error('Error connecting to WpStream:', error);
      return false;
    }
  }
}

// WpStream integration singleton instance (undefined until configured)
let wpStreamClient: WpStreamClient | undefined;

/**
 * Initialize WpStream integration with configuration
 */
export function initWpStreamIntegration(config: WpStreamConfig): WpStreamClient {
  wpStreamClient = new WpStreamClient(config);
  return wpStreamClient;
}

/**
 * Get the WpStream client instance (or undefined if not initialized)
 */
export function getWpStreamClient(): WpStreamClient | undefined {
  return wpStreamClient;
}