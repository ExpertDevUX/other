import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { insertIntegrationSchema, wpStreamConfigSchema } from "@shared/schema";
import { ZodError } from "zod";
import { initWpStreamIntegration, getWpStreamClient } from "./wpstream";

export function setupIntegrationRoutes(app: Express) {
  // Get all integrations
  app.get("/api/integrations", async (req, res) => {
    try {
      const integrations = await storage.getAllIntegrations();
      return res.json(integrations);
    } catch (error) {
      console.error("Error fetching integrations:", error);
      return res.status(500).json({ error: "Failed to fetch integrations" });
    }
  });

  // Get enabled integrations
  app.get("/api/integrations/enabled", async (req, res) => {
    try {
      const integrations = await storage.getEnabledIntegrations();
      return res.json(integrations);
    } catch (error) {
      console.error("Error fetching enabled integrations:", error);
      return res.status(500).json({ error: "Failed to fetch enabled integrations" });
    }
  });

  // Get integration by ID
  app.get("/api/integrations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid integration ID" });
      }

      const integration = await storage.getIntegration(id);
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }

      return res.json(integration);
    } catch (error) {
      console.error("Error fetching integration:", error);
      return res.status(500).json({ error: "Failed to fetch integration" });
    }
  });

  // Get integration by type (e.g., wpstream)
  app.get("/api/integrations/type/:type", async (req, res) => {
    try {
      const type = req.params.type;
      const integration = await storage.getIntegrationByType(type);
      
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }

      return res.json(integration);
    } catch (error) {
      console.error(`Error fetching ${req.params.type} integration:`, error);
      return res.status(500).json({ error: "Failed to fetch integration" });
    }
  });

  // Create integration
  app.post("/api/integrations", async (req, res) => {
    try {
      // Validate data with insertIntegrationSchema
      const data = insertIntegrationSchema.parse(req.body);
      
      // Check if integration of this type already exists
      const existingIntegration = await storage.getIntegrationByType(data.type);
      if (existingIntegration) {
        return res.status(400).json({ 
          error: `Integration of type '${data.type}' already exists` 
        });
      }

      // Create the integration
      const integration = await storage.createIntegration(data);
      
      // Initialize WpStream client if it's a WpStream integration and enabled
      if (data.type === "wpstream" && data.enabled) {
        try {
          const config = wpStreamConfigSchema.parse(data.config);
          initWpStreamIntegration(config);
        } catch (configError) {
          console.error("Error initializing WpStream integration:", configError);
          // We still continue as the integration was created in the database
        }
      }

      return res.status(201).json(integration);
    } catch (error) {
      console.error("Error creating integration:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid integration data", 
          details: error.errors 
        });
      }
      
      return res.status(500).json({ error: "Failed to create integration" });
    }
  });

  // Update integration
  app.patch("/api/integrations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid integration ID" });
      }

      // First check if integration exists
      const existingIntegration = await storage.getIntegration(id);
      if (!existingIntegration) {
        return res.status(404).json({ error: "Integration not found" });
      }

      // Update the integration
      const updatedIntegration = await storage.updateIntegration(id, req.body);
      
      // If this is a WpStream integration and it's enabled, re-initialize the client
      if (
        updatedIntegration && 
        updatedIntegration.type === "wpstream" && 
        updatedIntegration.enabled
      ) {
        try {
          const config = wpStreamConfigSchema.parse(updatedIntegration.config);
          initWpStreamIntegration(config);
        } catch (configError) {
          console.error("Error re-initializing WpStream integration:", configError);
          // We still continue as the integration was updated in the database
        }
      }

      return res.json(updatedIntegration);
    } catch (error) {
      console.error("Error updating integration:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Invalid integration data", 
          details: error.errors 
        });
      }
      
      return res.status(500).json({ error: "Failed to update integration" });
    }
  });

  // Delete integration
  app.delete("/api/integrations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid integration ID" });
      }

      const success = await storage.deleteIntegration(id);
      if (!success) {
        return res.status(404).json({ error: "Integration not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting integration:", error);
      return res.status(500).json({ error: "Failed to delete integration" });
    }
  });

  // -- WpStream Specific Routes --

  // Get WpStream integration - using a more specific route to avoid conflicts
  app.get("/api/integrations/wpstream/config", async (req, res) => {
    try {
      const integration = await storage.getIntegrationByType("wpstream");
      if (!integration) {
        return res.status(404).json({ error: "WpStream integration not found" });
      }
      return res.json(integration);
    } catch (error) {
      console.error("Error fetching WpStream integration:", error);
      return res.status(500).json({ error: "Failed to fetch WpStream integration" });
    }
  });

  // Test WpStream connection
  app.post("/api/integrations/wpstream/test", async (req, res) => {
    try {
      // Validate the config
      const config = wpStreamConfigSchema.parse(req.body);
      
      // Create a temporary client to test the connection
      const tempClient = initWpStreamIntegration(config);
      
      // Test the connection
      const result = await tempClient.testConnection();
      
      return res.json({
        success: result,
        message: result 
          ? "Connection to WpStream successful" 
          : "Failed to connect to WpStream"
      });
    } catch (error) {
      console.error("Error testing WpStream connection:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false,
          error: "Invalid WpStream configuration", 
          details: error.errors 
        });
      }
      
      return res.status(500).json({ 
        success: false,
        error: "Failed to test WpStream connection",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Sync streams with WpStream
  app.post("/api/integrations/wpstream/sync", async (req, res) => {
    try {
      const client = getWpStreamClient();
      if (!client) {
        return res.status(400).json({ 
          error: "WpStream integration not enabled or configured" 
        });
      }

      // Get all streams from our database
      const streams = await storage.getAllStreams();
      
      // Sync each stream with WpStream
      const results = await Promise.all(
        streams.map(async (stream) => {
          const success = await client.syncStream(stream);
          return { streamId: stream.id, streamKey: stream.streamKey, success };
        })
      );
      
      return res.json({ 
        success: true, 
        synced: results.filter(r => r.success).length,
        total: streams.length,
        results 
      });
    } catch (error) {
      console.error("Error syncing streams with WpStream:", error);
      return res.status(500).json({ 
        success: false,
        error: "Failed to sync streams with WpStream" 
      });
    }
  });
}