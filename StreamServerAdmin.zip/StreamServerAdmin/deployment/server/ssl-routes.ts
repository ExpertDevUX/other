/**
 * SSL API Routes
 * Manages SSL certificate installation and configuration
 */

import { Express, Request, Response } from 'express';
import { getSSLStatus, installSSL, renewSSL, getRequiredPorts } from './ssl-module';
import { storage } from './storage';
import { log } from './vite';
import { z } from 'zod';
import { ZodError } from 'zod';
import { fromZodError } from 'zod-validation-error';

const sslConfigSchema = z.object({
  domain: z.string().min(3).refine(
    (val) => /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+$/.test(val), {
      message: "Please enter a valid domain name (e.g. example.com)"
    }),
  email: z.string().email(),
  autoRenewal: z.boolean().default(true)
});

export function setupSSLRoutes(app: Express) {
  log('Setting up SSL routes...', 'ssl');

  // Get current SSL status
  app.get('/api/ssl/status', async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send('Admin permissions required');
    }

    try {
      // Get domain from site config
      const siteConfig = await storage.getSiteConfig();
      const domain = siteConfig?.domain || null;
      
      const status = await getSSLStatus(domain || undefined);
      res.json(status);
    } catch (error) {
      log(`Error getting SSL status: ${error}`, 'ssl');
      res.status(500).json({ error: 'Error getting SSL status' });
    }
  });

  // Install SSL certificate
  app.post('/api/ssl/install', async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send('Admin permissions required');
    }

    try {
      const config = sslConfigSchema.parse(req.body);

      // Update site config with domain
      const siteConfig = await storage.getSiteConfig();
      if (siteConfig) {
        await storage.updateSiteConfig({
          ...siteConfig,
          domain: config.domain
        });
      }
      
      const result = await installSSL(config.domain, config.email);
      
      // Log activity
      await storage.createActivity({
        type: 'ssl_installed',
        message: `SSL certificate for domain ${config.domain} was ${result.success ? 'installed' : 'installation failed'}`,
        userId: req.user.id,
        relatedType: 'config'
      });
      
      res.json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      
      log(`Error installing SSL: ${error}`, 'ssl');
      res.status(500).json({ error: 'Error installing SSL certificate' });
    }
  });

  // Renew SSL certificate
  app.post('/api/ssl/renew', async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send('Admin permissions required');
    }

    try {
      // Get domain from site config
      const siteConfig = await storage.getSiteConfig();
      const domain = siteConfig?.domain;
      
      if (!domain) {
        return res.status(400).json({ error: 'No domain configured' });
      }
      
      const result = await renewSSL(domain);
      
      // Log activity
      await storage.createActivity({
        type: 'ssl_renewed',
        message: `SSL certificate for domain ${domain} was ${result.success ? 'renewed' : 'renewal failed'}`,
        userId: req.user.id,
        relatedType: 'config'
      });
      
      res.json(result);
    } catch (error) {
      log(`Error renewing SSL: ${error}`, 'ssl');
      res.status(500).json({ error: 'Error renewing SSL certificate' });
    }
  });

  // Get required ports information
  app.get('/api/ssl/ports', (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send('Authentication required');
    }

    try {
      const ports = getRequiredPorts();
      res.json(ports);
    } catch (error) {
      log(`Error getting port information: ${error}`, 'ssl');
      res.status(500).json({ error: 'Error getting port information' });
    }
  });
}