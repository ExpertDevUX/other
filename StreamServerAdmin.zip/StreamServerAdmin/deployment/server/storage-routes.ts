import { Express, Request, Response } from "express";
import { z } from "zod";
import { storage } from "./storage";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import { log } from "./vite";

// Define schema for storage settings
const storageSettingsSchema = z.object({
  storagePath: z.string().min(1, "Storage path is required"),
  maxStorageSize: z.coerce.number().positive("Max storage size must be positive"),
  backupPath: z.string().optional(),
  autoBackupEnabled: z.boolean().default(false),
  autoBackupInterval: z.coerce.number().min(1, "Backup interval must be at least 1 hour"),
  encryptionEnabled: z.boolean().default(false),
  encryptionKey: z.string().optional(),
});

// Initialize default storage settings
let storageSettings = {
  storagePath: "/data/storage",
  maxStorageSize: 1000, // MB
  backupPath: "/data/backups",
  autoBackupEnabled: false,
  autoBackupInterval: 24, // hours
  encryptionEnabled: false,
  encryptionKey: "",
};

// Storage metrics
let storageMetrics = {
  used: 0,
  total: 1000,
  available: 0,
  utilization: 0,
  lastBackup: null as Date | null,
  lastCleanup: null as Date | null,
};

// Backup file info
type BackupFile = {
  filename: string;
  timestamp: Date;
  size: number; // MB
};

// Available backups
let availableBackups: BackupFile[] = [];

// Initialize storage system
function initStorageSystem() {
  // Simulate initialization
  log("Initializing storage system...", "storage");
  
  // Simulate reading storage usage
  updateStorageMetrics();
  
  // Simulate encryption setup if enabled
  if (storageSettings.encryptionEnabled && storageSettings.encryptionKey) {
    setupEncryption(storageSettings.encryptionKey);
  }
  
  // Initialize sample backup files
  availableBackups = [
    {
      filename: "backup-2025-01-15T12-30-45.zip",
      timestamp: new Date(2025, 0, 15, 12, 30, 45),
      size: 128 // MB
    },
    {
      filename: "backup-2025-02-20T09-15-22.zip",
      timestamp: new Date(2025, 1, 20, 9, 15, 22),
      size: 145 // MB
    },
    {
      filename: "backup-2025-03-10T18-05-33.zip",
      timestamp: new Date(2025, 2, 10, 18, 5, 33),
      size: 156 // MB
    }
  ];
  
  log("Storage system initialized", "storage");
}

// Update storage metrics
function updateStorageMetrics() {
  // Simulate disk usage calculation (in a real system, this would query the filesystem)
  storageMetrics.used = Math.floor(Math.random() * 500); // Random usage between 0-500 MB
  storageMetrics.total = storageSettings.maxStorageSize;
  
  return storageMetrics;
}

// Create a backup and return the download URL
async function createBackup(): Promise<{ success: boolean, downloadUrl?: string, filename?: string }> {
  try {
    // Simulate backup creation (in a real system, this would zip/archive files)
    log(`Creating backup to ${storageSettings.backupPath}...`, "storage");
    
    // Simulate delay for backup process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate backup filename with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `backup-${timestamp}.zip`;
    
    // In a real system, this would create a zip file at the path
    const backupPath = `${storageSettings.backupPath}/${filename}`;
    
    // Update last backup timestamp
    storageMetrics.lastBackup = new Date();
    
    log("Backup created successfully", "storage");
    
    // Return success with the download URL and filename
    return {
      success: true,
      downloadUrl: `/api/storage/download/${filename}`,
      filename: filename
    };
  } catch (error) {
    log(`Backup creation failed: ${error}`, "storage");
    return { success: false };
  }
}

// Simulate cleaning storage
async function cleanStorage(): Promise<number> {
  try {
    // Simulate storage cleaning (in a real system, this would delete temp files)
    log("Cleaning storage...", "storage");
    
    // Simulate delay for cleaning process
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simulate amount of space freed (random between 50-200 MB)
    const bytesFreed = Math.floor(Math.random() * 150) + 50;
    
    // Update storage metrics
    storageMetrics.used = Math.max(0, storageMetrics.used - bytesFreed);
    
    log(`Storage cleaned, freed ${bytesFreed} MB`, "storage");
    return bytesFreed;
  } catch (error) {
    log(`Storage cleaning failed: ${error}`, "storage");
    return 0;
  }
}

// Setup encryption system
function setupEncryption(key: string) {
  log("Setting up encryption with provided key", "storage");
  // In a real implementation, this would initialize encryption libraries
}

// Encrypt data
function encryptData(data: string, key: string): string {
  // Simple encryption implementation for demonstration
  // In production, use a proper encryption library
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(key.padEnd(32).slice(0, 32)), iv);
    
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    // Return IV + Auth Tag + Encrypted content
    return iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted;
  } catch (error) {
    log(`Encryption error: ${error}`, "storage");
    return data; // Fallback to unencrypted on error
  }
}

// Decrypt data
function decryptData(encryptedData: string, key: string): string {
  // Simple decryption implementation for demonstration
  try {
    const parts = encryptedData.split(':');
    if (parts.length !== 3) {
      throw new Error('Invalid encrypted data format');
    }
    
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encryptedText = parts[2];
    
    const decipher = crypto.createDecipheriv('aes-256-gcm', Buffer.from(key.padEnd(32).slice(0, 32)), iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    log(`Decryption error: ${error}`, "storage");
    return encryptedData; // Return encrypted data on error
  }
}

// Setup storage routes
export function setupStorageRoutes(app: Express) {
  // Initialize storage system
  initStorageSystem();
  
  // Get storage metrics
  app.get("/api/storage/metrics", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    // Update metrics before sending
    const metrics = updateStorageMetrics();
    res.json(metrics);
  });
  
  // Get storage settings
  app.get("/api/storage/settings", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    // Don't send encryption key in response for security
    const safeSettings = {
      ...storageSettings,
      encryptionKey: storageSettings.encryptionKey ? "[ENCRYPTED]" : ""
    };
    
    res.json(safeSettings);
  });
  
  // Update storage settings
  app.patch("/api/storage/settings", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Validate request body
      const validatedData = storageSettingsSchema.parse(req.body);
      
      // Store previous encryption settings to check for changes
      const prevEncryptionEnabled = storageSettings.encryptionEnabled;
      const prevEncryptionKey = storageSettings.encryptionKey;
      
      // Update settings
      storageSettings = {
        ...storageSettings,
        ...validatedData
      };
      
      // If encryption was enabled or key changed, setup encryption
      if ((validatedData.encryptionEnabled && !prevEncryptionEnabled) ||
          (validatedData.encryptionEnabled && 
            validatedData.encryptionKey && 
            validatedData.encryptionKey !== prevEncryptionKey && 
            validatedData.encryptionKey !== "[ENCRYPTED]")) {
        
        setupEncryption(validatedData.encryptionKey || "");
      }
      
      // Update storage metrics with new max size
      updateStorageMetrics();
      
      // Log activity
      await storage.createActivity({
        type: "settings_update",
        userId: req.user.id,
        message: `Storage settings updated: path=${validatedData.storagePath}, size=${validatedData.maxStorageSize}MB, encryption=${validatedData.encryptionEnabled}`,
        relatedType: "storage"
      });
      
      // Don't send encryption key in response for security
      const safeSettings = {
        ...storageSettings,
        encryptionKey: storageSettings.encryptionKey ? "[ENCRYPTED]" : ""
      };
      
      res.json(safeSettings);
    } catch (error: any) {
      console.error("Error updating storage settings:", error);
      
      if (error.errors) {
        return res.status(400).json({ error: "Validation error", details: error.errors });
      }
      
      res.status(500).json({ error: "Failed to update storage settings" });
    }
  });
  
  // Get available backups
  app.get("/api/storage/backups", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Return the list of available backups with download URLs
      const backupsWithUrls = availableBackups.map(backup => ({
        ...backup,
        downloadUrl: `/api/storage/download/${backup.filename}`
      }));
      
      res.json(backupsWithUrls);
    } catch (error) {
      console.error("Error fetching backups:", error);
      res.status(500).json({ error: "Failed to get available backups" });
    }
  });
  
  // Create backup
  app.post("/api/storage/backup", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Create backup
      const result = await createBackup();
      
      if (result.success && result.filename) {
        // Add the backup to the available backups list
        const newBackup: BackupFile = {
          filename: result.filename,
          timestamp: new Date(),
          size: Math.floor(Math.random() * 50) + 100 // Random size between 100-150 MB
        };
        
        // Add to beginning of list
        availableBackups.unshift(newBackup);
        
        // Log activity
        await storage.createActivity({
          type: "backup_created",
          userId: req.user.id,
          message: `Storage backup created manually to ${storageSettings.backupPath}`,
          relatedType: "storage"
        });
        
        res.json({
          success: true,
          message: "Backup created successfully",
          timestamp: storageMetrics.lastBackup,
          downloadUrl: result.downloadUrl,
          filename: result.filename
        });
      } else {
        res.status(500).json({
          success: false,
          message: "Failed to create backup"
        });
      }
    } catch (error) {
      console.error("Error creating backup:", error);
      res.status(500).json({ error: "Failed to create backup" });
    }
  });
  
  // Download backup file
  app.get("/api/storage/download/:filename", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const filename = req.params.filename;
      const filePath = `${storageSettings.backupPath}/${filename}`;
      
      // In a real system, we would check if the file exists before sending it
      
      // Set headers for file download
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      // In a real system, we would stream the file content
      // For this demo, create a simple sample zip content
      const sampleZipContent = Buffer.from([
        0x50, 0x4B, 0x03, 0x04, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x82, 0x96, 0x06, 0x55, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 
        0x64, 0x61, 0x74, 0x61, 0x50, 0x4B, 0x01, 0x02, 0x1E, 0x03, 
        0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x82, 0x96, 0x06, 0x55, 
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x64, 0x61, 0x74, 0x61, 0x50, 0x4B, 0x05, 0x06, 
        0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x32, 0x00, 
        0x00, 0x00, 0x26, 0x00, 0x00, 0x00, 0x00, 0x00
      ]);
      
      // Log activity
      storage.createActivity({
        type: "backup_download",
        userId: req.user.id,
        message: `Backup file "${filename}" downloaded`,
        relatedType: "storage"
      }).catch(err => console.error("Error logging backup download:", err));
      
      // Send the sample zip file
      res.send(sampleZipContent);
    } catch (error) {
      console.error("Error downloading backup:", error);
      res.status(500).send("Failed to download backup file");
    }
  });
  
  // Clean storage
  app.post("/api/storage/clean", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Clean storage
      const bytesFreed = await cleanStorage();
      
      if (bytesFreed > 0) {
        // Log activity
        await storage.createActivity({
          type: "storage_cleaned",
          userId: req.user.id,
          message: `Storage cleaned, freed ${bytesFreed} MB, new usage: ${storageMetrics.used} MB`,
          relatedType: "storage"
        });
        
        res.json({
          success: true,
          message: `Storage cleaned successfully`,
          bytesFreed,
          newUsed: storageMetrics.used
        });
      } else {
        res.json({
          success: true,
          message: "No files needed cleaning",
          bytesFreed: 0
        });
      }
    } catch (error) {
      console.error("Error cleaning storage:", error);
      res.status(500).json({ error: "Failed to clean storage" });
    }
  });
  
  // Encrypt file (utility endpoint for admin use)
  app.post("/api/storage/encrypt", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    try {
      // Admin-only endpoint
      if (!req.user?.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Validate encryption is enabled
      if (!storageSettings.encryptionEnabled || !storageSettings.encryptionKey) {
        return res.status(400).json({ error: "Encryption is not enabled or key is missing" });
      }
      
      // Validate request body
      const { data } = req.body;
      if (!data) {
        return res.status(400).json({ error: "Data to encrypt is required" });
      }
      
      // Encrypt data
      const encrypted = encryptData(data, storageSettings.encryptionKey);
      
      // Log activity without revealing the data
      await storage.createActivity({
        type: "data_encrypted",
        userId: req.user.id,
        message: `Data encrypted (${data.length} bytes)`,
        relatedType: "security"
      });
      
      res.json({
        success: true,
        encryptedData: encrypted
      });
    } catch (error) {
      console.error("Error encrypting data:", error);
      res.status(500).json({ error: "Failed to encrypt data" });
    }
  });
  
  // API endpoint for getting system information including author and support details
  app.get("/api/system/info", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    res.json({
      name: "WP Stream Server Manager",
      version: "2.0.0",
      author: "HWO_Administrator",
      support: "info@hwosecurity.org",
      securityFeatures: [
        "AES-256-GCM data encryption",
        "Secure code obfuscation",
        "Password hashing with scrypt",
        "Rate limiting and IP filtering"
      ],
      environment: {
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch
      }
    });
  });
}