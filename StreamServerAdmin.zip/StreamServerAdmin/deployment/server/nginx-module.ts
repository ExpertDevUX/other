import { exec } from "child_process";
import { promises as fs } from "fs";
import * as path from "path";
import { promisify } from "util";

const execAsync = promisify(exec);

// Path to NGINX configuration files
const NGINX_CONFIG_PATH = "/etc/nginx";
const NGINX_RTMP_CONFIG_PATH = "/etc/nginx/modules-enabled/rtmp.conf";
const NGINX_DEFAULT_CONFIG_PATH = "/etc/nginx/sites-available/default";
const NGINX_LOG_PATH = "/var/log/nginx";

/**
 * Check if NGINX is installed
 */
async function isNginxInstalled(): Promise<boolean> {
  try {
    await execAsync("nginx -v");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Check if NGINX is running
 */
async function isNginxRunning(): Promise<boolean> {
  try {
    await execAsync("systemctl is-active --quiet nginx");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Check if RTMP module is installed
 */
async function isRtmpModuleInstalled(): Promise<boolean> {
  try {
    // First check if nginx is installed at all
    if (!(await isNginxInstalled())) {
      return false;
    }
    
    // Multiple methods to check for RTMP module
    
    // Method 1: Check if the RTMP module configuration exists
    const rtmpConfigExists = await fileExists(NGINX_RTMP_CONFIG_PATH);
    
    // Method 2: Check for libnginx-mod-rtmp package
    let modRtmpInstalled = false;
    try {
      const { stdout } = await execAsync("dpkg -l | grep libnginx-mod-rtmp");
      modRtmpInstalled = stdout.includes("libnginx-mod-rtmp");
    } catch (error) {
      // Package manager might not be dpkg, try alternative methods
    }
    
    // Method 3: Check if nginx was compiled with RTMP support
    let compiledWithRtmp = false;
    try {
      const { stdout } = await execAsync("nginx -V 2>&1");
      compiledWithRtmp = stdout.includes("--with-http_ssl_module") && 
                         (stdout.includes("rtmp") || stdout.includes("--add-module=../nginx-rtmp-module"));
    } catch (error) {
      // Ignore if nginx -V command fails
    }
    
    // Return true if any method confirms RTMP is installed
    return rtmpConfigExists || modRtmpInstalled || compiledWithRtmp;
  } catch (error) {
    console.error("Error checking RTMP module:", error);
    return false;
  }
}

/**
 * Install NGINX with RTMP module
 */
async function installNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is already installed
    if (await isNginxInstalled()) {
      // If it's installed but RTMP module is missing, just install the module
      if (!(await isRtmpModuleInstalled())) {
        await execAsync("apt-get update && apt-get install -y libnginx-mod-rtmp");
        await createRtmpConfig();
        await restartNginx();
        return { 
          success: true, 
          message: "RTMP module installed successfully and NGINX restarted" 
        };
      }
      return { 
        success: true, 
        message: "NGINX with RTMP module is already installed" 
      };
    }
    
    // Install NGINX and RTMP module
    await execAsync("apt-get update && apt-get install -y nginx libnginx-mod-rtmp");
    
    // Create RTMP configuration
    await createRtmpConfig();
    
    // Update default site configuration to serve HLS
    await updateDefaultSiteConfig();
    
    // Create HLS directory
    await execAsync("mkdir -p /var/www/html/hls");
    await execAsync("chown -R www-data:www-data /var/www/html/hls");
    
    // Start NGINX service
    await execAsync("systemctl enable nginx");
    await execAsync("systemctl start nginx");
    
    return { 
      success: true, 
      message: "NGINX with RTMP module installed successfully" 
    };
  } catch (error) {
    console.error("Error installing NGINX:", error);
    return { 
      success: false, 
      message: `Failed to install NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Repair NGINX installation and configuration
 */
async function repairNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is installed
    if (!(await isNginxInstalled())) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install it first." 
      };
    }
    
    // Fix common issues
    await fixCommonNginxIssues();
    
    // Find and remove rtmp_auto_push directive from config files
    try {
      console.log("Checking for problematic rtmp_auto_push directive...");
      
      // Look for all NGINX config files
      const configFiles = await execAsync("find /etc/nginx -type f -name '*.conf'");
      const fileList = configFiles.stdout.trim().split('\n').filter(Boolean);
      
      for (const filePath of fileList) {
        try {
          // Read file content
          const fileContent = await fs.readFile(filePath, 'utf8');
          
          // Check if file contains the problematic directive
          if (fileContent.includes('rtmp_auto_push')) {
            console.log(`Found rtmp_auto_push in ${filePath}, fixing...`);
            
            // Create backup
            await backupConfigFile(filePath);
            
            // Remove the rtmp_auto_push directive
            const fixedContent = fileContent.replace(/rtmp_auto_push\s+on;?/g, '');
            
            // Write fixed content back
            await fs.writeFile(filePath, fixedContent);
            console.log(`Removed rtmp_auto_push directive from ${filePath}`);
          }
        } catch (error) {
          console.error(`Error processing file ${filePath}:`, error);
        }
      }
    } catch (error) {
      console.error("Error searching for rtmp_auto_push directive:", error);
    }
    
    // Recreate the RTMP configuration file to ensure it's correct
    await createRtmpConfig();
    
    // Check NGINX configuration again
    const configValid = await checkNginxConfig();
    
    if (!configValid) {
      console.log("Configuration still invalid after repairs, checking nginx.conf...");
      
      try {
        // Check the main nginx.conf file
        const mainConfigPath = '/etc/nginx/nginx.conf';
        if (await fileExists(mainConfigPath)) {
          // Backup the file
          await backupConfigFile(mainConfigPath);
          
          // Read the file
          const mainConfig = await fs.readFile(mainConfigPath, 'utf8');
          
          // Look for rtmp_auto_push directive in main config
          if (mainConfig.includes('rtmp_auto_push')) {
            console.log("Found rtmp_auto_push in main config, removing...");
            const fixedMainConfig = mainConfig.replace(/rtmp_auto_push\s+on;?/g, '');
            await fs.writeFile(mainConfigPath, fixedMainConfig);
          }
        }
      } catch (error) {
        console.error("Error fixing main nginx.conf:", error);
      }
      
      // Check again after all fixes
      const configNowValid = await checkNginxConfig();
      if (!configNowValid) {
        return { 
          success: false, 
          message: "NGINX configuration is still invalid after all repair attempts. Please check system logs for details." 
        };
      }
    }
    
    // Restart NGINX service
    await restartNginx();
    
    return { 
      success: true, 
      message: "NGINX repaired and restarted successfully" 
    };
  } catch (error) {
    console.error("Error repairing NGINX:", error);
    return { 
      success: false, 
      message: `Failed to repair NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Check if NGINX configuration is valid
 */
async function checkNginxConfig(): Promise<boolean> {
  try {
    await execAsync("nginx -t");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Fix common NGINX issues
 */
async function fixCommonNginxIssues(): Promise<void> {
  // 1. Fix permissions
  await execAsync("mkdir -p /var/log/nginx");
  await execAsync("chown -R www-data:www-data /var/log/nginx");
  await execAsync("mkdir -p /var/www/html/hls /var/www/html/dash /var/www/html/recordings /etc/nginx/backups");
  await execAsync("chown -R www-data:www-data /var/www/html");
  
  // 2. Fix missing RTMP module
  if (!(await isRtmpModuleInstalled())) {
    console.log("RTMP module not installed. Installing now...");
    await execAsync("apt-get update && apt-get install -y libnginx-mod-rtmp");
  }
  
  // 3. Backup and recreate config files if invalid or missing
  const configValid = await checkNginxConfig();
  
  if (!configValid || !(await fileExists(NGINX_RTMP_CONFIG_PATH))) {
    console.log("NGINX configuration invalid or missing, recreating...");
    
    // Backup existing configurations before replacing
    if (await fileExists(NGINX_RTMP_CONFIG_PATH)) {
      await backupConfigFile(NGINX_RTMP_CONFIG_PATH);
    }
    
    if (await fileExists(NGINX_DEFAULT_CONFIG_PATH)) {
      await backupConfigFile(NGINX_DEFAULT_CONFIG_PATH);
    }
    
    // Create new configuration files
    await createRtmpConfig();
    await updateDefaultSiteConfig();
  }
  
  // 4. Fix default site config if needed
  if (!(await fileExists(NGINX_DEFAULT_CONFIG_PATH))) {
    await updateDefaultSiteConfig();
  }
  
  // 5. Clear any stale pid files
  try {
    await execAsync("rm -f /var/run/nginx.pid");
  } catch (error) {
    // Ignore error if the pid file doesn't exist
  }
  
  // 6. Ensure symbolic links are correct
  try {
    // Create symbolic link for RTMP module if needed
    const rtmpModulePath = "/etc/nginx/modules-available/50-mod-rtmp.conf";
    const rtmpModuleLink = "/etc/nginx/modules-enabled/50-mod-rtmp.conf";
    
    if (await fileExists(rtmpModulePath) && !(await fileExists(rtmpModuleLink))) {
      await execAsync(`ln -sf ${rtmpModulePath} ${rtmpModuleLink}`);
    }
  } catch (error) {
    console.error("Error setting up module links:", error);
  }
}

/**
 * Uninstall NGINX and cleanup configuration
 */
async function uninstallNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is installed
    if (!(await isNginxInstalled())) {
      return { 
        success: true, 
        message: "NGINX is not installed" 
      };
    }
    
    // Stop NGINX service
    await execAsync("systemctl stop nginx");
    await execAsync("systemctl disable nginx");
    
    // Uninstall NGINX and RTMP module
    await execAsync("apt-get remove -y nginx libnginx-mod-rtmp");
    await execAsync("apt-get autoremove -y");
    
    // Remove configuration files
    await execAsync("rm -rf /etc/nginx");
    await execAsync("rm -rf /var/log/nginx");
    await execAsync("rm -rf /var/www/html/hls");
    
    return { 
      success: true, 
      message: "NGINX uninstalled successfully" 
    };
  } catch (error) {
    console.error("Error uninstalling NGINX:", error);
    return { 
      success: false, 
      message: `Failed to uninstall NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Get NGINX status
 */
async function getNginxStatus(): Promise<{
  installed: boolean;
  running: boolean;
  rtmpModuleInstalled: boolean;
  configValid: boolean;
}> {
  const installed = await isNginxInstalled();
  const running = installed ? await isNginxRunning() : false;
  const rtmpModuleInstalled = installed ? await isRtmpModuleInstalled() : false;
  const configValid = installed ? await checkNginxConfig() : false;
  
  return {
    installed,
    running,
    rtmpModuleInstalled,
    configValid
  };
}

/**
 * Check if NGINX version supports rtmp_auto_push directive
 */
async function supportsRtmpAutoPush(): Promise<boolean> {
    try {
        const versionOutput = await execCommand('nginx -v 2>&1');
        const versionMatch = versionOutput.match(/nginx\/(\d+\.\d+\.\d+)/);
        
        if (versionMatch) {
            const version = versionMatch[1];
            const [major, minor, patch] = version.split('.').map(Number);
            
            // NGINX with RTMP module supports rtmp_auto_push directive in newer versions
            // This is a simplified check - actual compatibility depends on the RTMP module version
            return (major > 1 || (major === 1 && minor >= 13));
        }
        
        return false;
    } catch (error) {
        console.error('Error checking NGINX version:', error);
        return false;
    }
}

/**
 * Create RTMP configuration file
 */
/**
 * Change the NGINX RTMP port
 */
async function changeRtmpPort(port: number): Promise<{ success: boolean, message: string }> {
  try {
    // Validate port
    if (port < 1024 || port > 65535) {
      return { 
        success: false, 
        message: "Port must be between 1024 and 65535" 
      };
    }

    // Check if NGINX is installed
    if (!await isNginxInstalled()) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install NGINX first." 
      };
    }

    // Update RTMP config with new port
    await createRtmpConfig(port);
    
    // Restart NGINX to apply changes
    await restartNginx();
    
    return { 
      success: true, 
      message: `RTMP port successfully changed to ${port}` 
    };
  } catch (error) {
    console.error("Error changing RTMP port:", error);
    return { 
      success: false, 
      message: `Failed to change RTMP port: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Change the NGINX HTTP port
 */
async function changeHttpPort(port: number): Promise<{ success: boolean, message: string }> {
  try {
    // Validate port
    if (port < 1024 || port > 65535) {
      return { 
        success: false, 
        message: "Port must be between 1024 and 65535" 
      };
    }

    // Check if NGINX is installed
    if (!await isNginxInstalled()) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install NGINX first." 
      };
    }
    
    // Update default site config with new port
    await updateDefaultSiteConfig(port);
    
    // Restart NGINX to apply changes
    await restartNginx();
    
    return { 
      success: true, 
      message: `HTTP port successfully changed to ${port}` 
    };
  } catch (error) {
    console.error("Error changing HTTP port:", error);
    return { 
      success: false, 
      message: `Failed to change HTTP port: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

async function createRtmpConfig(port: number = 1935): Promise<void> {
  // Check if NGINX version supports rtmp_auto_push
  const supportsAutoPush = await supportsRtmpAutoPush();
  
  // Create configuration without rtmp_auto_push directive as it causes issues on some nginx versions
  const rtmpConfig = `
# RTMP configuration for video streaming
load_module modules/ngx_rtmp_module.so;

rtmp {
    server {
        listen ${port}; # RTMP port
        chunk_size 4096;
        
        # Define application for live streaming
        application live {
            live on;
            record off;
            
            # HLS output
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # Enable HLS for all streams
            hls_variant _low bandwidth=800000 resolution=640x360;
            hls_variant _mid bandwidth=1200000 resolution=842x480;
            hls_variant _high bandwidth=2400000 resolution=1280x720;
            hls_variant _hd bandwidth=4800000 resolution=1920x1080;
            
            # Only allow streaming from the local system and authenticated users
            allow publish 127.0.0.1;
            deny publish all;
            
            # Only allow playing from anywhere
            allow play all;
        }
    }
}
`;

  // Ensure directory exists
  await execAsync("mkdir -p /etc/nginx/modules-enabled");
  
  // Create backup of existing configuration if it exists
  if (await fileExists(NGINX_RTMP_CONFIG_PATH)) {
    await backupConfigFile(NGINX_RTMP_CONFIG_PATH);
  }
  
  // Write the configuration file
  await fs.writeFile(NGINX_RTMP_CONFIG_PATH, rtmpConfig);
}

/**
 * Update default site configuration to serve HLS content
 */
async function updateDefaultSiteConfig(port: number = 80): Promise<void> {
  // Check if default config exists
  const defaultConfigExists = await fileExists(NGINX_DEFAULT_CONFIG_PATH);
  
  if (!defaultConfigExists) {
    // Create a basic default config
    const defaultConfig = `
server {
    listen ${port} default_server;
    listen [::]:${port} default_server;
    
    root /var/www/html;
    
    index index.html index.htm index.nginx-debian.html;
    
    server_name _;
    
    location / {
        try_files $uri $uri/ =404;
    }
    
    # HLS streaming location
    location /hls {
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        
        root /var/www/html;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
}
`;
    await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, defaultConfig);
  } else {
    // Read existing config
    let config = await fs.readFile(NGINX_DEFAULT_CONFIG_PATH, 'utf8');

    // Create backup of the existing configuration before modifying
    await backupConfigFile(NGINX_DEFAULT_CONFIG_PATH);
    
    // Update the port if specified
    if (port !== 80) {
      // Replace both IPv4 and IPv6 listen directives
      config = config.replace(
        /listen\s+\d+\s+default_server;/g,
        `listen ${port} default_server;`
      );
      config = config.replace(
        /listen\s+\[::\]:\d+\s+default_server;/g,
        `listen [::]:${port} default_server;`
      );
    }
    
    // Check if HLS section already exists
    if (!config.includes('location /hls')) {
      // Add HLS section to existing config
      const hlsSection = `
    # HLS streaming location
    location /hls {
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        
        root /var/www/html;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
`;
      
      // Insert before the closing bracket of the server block
      const updatedConfig = config.replace(
        /}(\s*)$/,
        `${hlsSection}}$1`
      );
      
      await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, updatedConfig);
    } else {
      // If we only need to update the port
      await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, config);
    }
  }
  
  // Create symbolic link if it doesn't exist
  const enabledPath = "/etc/nginx/sites-enabled/default";
  if (!(await fileExists(enabledPath))) {
    await execAsync(`ln -s ${NGINX_DEFAULT_CONFIG_PATH} ${enabledPath}`);
  }
}

/**
 * Restart NGINX service
 */
async function restartNginx(): Promise<void> {
  await execAsync("systemctl restart nginx");
}

/**
 * Backup a configuration file before modifying it
 */
async function backupConfigFile(filePath: string): Promise<string | null> {
  try {
    // Check if file exists
    if (!await fileExists(filePath)) {
      return null;
    }
    
    // Create backup directory if it doesn't exist
    const backupDir = "/etc/nginx/backups";
    await fs.mkdir(backupDir, { recursive: true });
    
    // Create backup with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = path.basename(filePath);
    const backupPath = `${backupDir}/${fileName}.${timestamp}.bak`;
    
    // Copy file to backup
    await fs.copyFile(filePath, backupPath);
    console.log(`Created backup of ${filePath} at ${backupPath}`);
    
    return backupPath;
  } catch (error) {
    console.error(`Error creating backup for ${filePath}:`, error);
    return null;
  }
}

/**
 * Check if a file exists
 */
async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Execute a shell command and return the output
 */
async function execCommand(command: string): Promise<string> {
  try {
    const { stdout } = await execAsync(command);
    return stdout.trim();
  } catch (error) {
    if (error instanceof Error && 'stderr' in error) {
      // @ts-ignore
      return error.stderr.trim();
    }
    throw error;
  }
}

// Export functions
export {
  getNginxStatus,
  installNginx,
  repairNginx,
  uninstallNginx,
  changeRtmpPort,
  changeHttpPort,
  supportsRtmpAutoPush
};