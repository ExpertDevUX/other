import { 
  users, type User, type InsertUser,
  streams, type Stream, type InsertStream,
  servers, type Server, type InsertServer,
  activities, type Activity, type InsertActivity,
  integrations, type Integration, type InsertIntegration,
  cloudProviders, type CloudProvider, type InsertCloudProvider,
  bandwidthAllocations, type BandwidthAllocation, type InsertBandwidthAllocation,
  siteConfig, type SiteConfig, type InsertSiteConfig
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { Pool } from "@neondatabase/serverless";

// Create session stores
const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Create pool for PostgreSQL session store
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Stream methods
  getStream(id: number): Promise<Stream | undefined>;
  getStreamByKey(streamKey: string): Promise<Stream | undefined>;
  createStream(stream: InsertStream): Promise<Stream>;
  updateStream(id: number, stream: Partial<Stream>): Promise<Stream | undefined>;
  deleteStream(id: number): Promise<boolean>;
  getAllStreams(): Promise<Stream[]>;
  getActiveStreams(): Promise<Stream[]>;
  getUserStreams(userId: number): Promise<Stream[]>;
  
  // Server methods
  getServer(id: number): Promise<Server | undefined>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: number, server: Partial<Server>): Promise<Server | undefined>;
  deleteServer(id: number): Promise<boolean>;
  getAllServers(): Promise<Server[]>;
  
  // Activity methods
  getActivity(id: number): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getAllActivities(limit?: number): Promise<Activity[]>;
  
  // Integration methods
  getIntegration(id: number): Promise<Integration | undefined>;
  getIntegrationByType(type: string): Promise<Integration | undefined>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, integration: Partial<Integration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<boolean>;
  getAllIntegrations(): Promise<Integration[]>;
  getEnabledIntegrations(): Promise<Integration[]>;
  
  // Cloud Provider methods
  getCloudProvider(id: number): Promise<CloudProvider | undefined>;
  createCloudProvider(provider: InsertCloudProvider): Promise<CloudProvider>;
  updateCloudProvider(id: number, provider: Partial<CloudProvider>): Promise<CloudProvider | undefined>;
  deleteCloudProvider(id: number): Promise<boolean>;
  getAllCloudProviders(): Promise<CloudProvider[]>;
  getUserCloudProviders(userId: number): Promise<CloudProvider[]>;
  getCloudProviderByType(type: string): Promise<CloudProvider | undefined>;
  
  // Bandwidth Allocation methods
  getBandwidthAllocation(id: number): Promise<BandwidthAllocation | undefined>;
  createBandwidthAllocation(allocation: InsertBandwidthAllocation): Promise<BandwidthAllocation>;
  updateBandwidthAllocation(id: number, allocation: Partial<BandwidthAllocation>): Promise<BandwidthAllocation | undefined>;
  deleteBandwidthAllocation(id: number): Promise<boolean>;
  getAllBandwidthAllocations(): Promise<BandwidthAllocation[]>;
  getServerBandwidthAllocations(serverId: number): Promise<BandwidthAllocation[]>;
  getStreamBandwidthAllocation(streamId: number): Promise<BandwidthAllocation | undefined>;

  // Site Configuration methods
  getSiteConfig(): Promise<SiteConfig | undefined>;
  updateSiteConfig(config: Partial<SiteConfig>): Promise<SiteConfig | undefined>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Initialize default data if needed
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Check if we have any admin users
      const adminUsers = await db.select().from(users).where(eq(users.isAdmin, true));
      
      // If no admin users, create a default admin
      if (adminUsers.length === 0) {
        // Note: Password will be hashed in auth.ts when calling createUser
        await this.createUser({
          username: "admin",
          password: "admin123",
          isAdmin: true,
          fullName: "Administrator",
          email: "admin@example.com"
        });
      }
      
      // Check if we have any servers
      const serversList = await db.select().from(servers);
      
      // If no servers, create a default one
      if (serversList.length === 0) {
        await this.createServer({
          name: "Default RTMP Server",
          host: "localhost",
          port: 1935,
          isInstalled: false,
          status: "offline",
          config: {
            rtmp: {
              port: 1935,
              chunk_size: 60000,
              gop_cache: true,
              ping: 30,
              ping_timeout: 60
            },
            http: {
              port: 8000,
              allow_origin: "*"
            }
          }
        });
      }
      
      // Check if we have site configuration
      const configList = await db.select().from(siteConfig);
      
      // If no site config, create a default one
      if (configList.length === 0) {
        await db.insert(siteConfig).values({
          siteName: "Stream Manager",
          domain: null,
          hostname: "localhost",
          primaryColor: "#3b82f6",
          siteDescription: "Video Stream Server Management Platform",
          faviconUrl: null,
          contactEmail: null,
          dbName: null,
          dbUser: null,
          dbHost: null,
          isConfigured: false,
          updatedAt: new Date()
        });
      }
    } catch (error) {
      console.error("Error initializing default data:", error);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning({ id: users.id });
    return result.length > 0;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Stream methods
  async getStream(id: number): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).where(eq(streams.id, id));
    return stream;
  }
  
  async getStreamByKey(streamKey: string): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).where(eq(streams.streamKey, streamKey));
    return stream;
  }
  
  async createStream(insertStream: InsertStream): Promise<Stream> {
    const [stream] = await db.insert(streams).values(insertStream).returning();
    return stream;
  }
  
  async updateStream(id: number, streamData: Partial<Stream>): Promise<Stream | undefined> {
    const [updatedStream] = await db
      .update(streams)
      .set(streamData)
      .where(eq(streams.id, id))
      .returning();
    return updatedStream;
  }
  
  async deleteStream(id: number): Promise<boolean> {
    const result = await db.delete(streams).where(eq(streams.id, id)).returning({ id: streams.id });
    return result.length > 0;
  }
  
  async getAllStreams(): Promise<Stream[]> {
    return await db.select().from(streams);
  }
  
  async getActiveStreams(): Promise<Stream[]> {
    return await db.select().from(streams).where(eq(streams.isActive, true));
  }
  
  async getUserStreams(userId: number): Promise<Stream[]> {
    return await db.select().from(streams).where(eq(streams.userId, userId));
  }

  // Server methods
  async getServer(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }
  
  async createServer(insertServer: InsertServer): Promise<Server> {
    const [server] = await db.insert(servers).values(insertServer).returning();
    return server;
  }
  
  async updateServer(id: number, serverData: Partial<Server>): Promise<Server | undefined> {
    const [updatedServer] = await db
      .update(servers)
      .set(serverData)
      .where(eq(servers.id, id))
      .returning();
    return updatedServer;
  }
  
  async deleteServer(id: number): Promise<boolean> {
    const result = await db.delete(servers).where(eq(servers.id, id)).returning({ id: servers.id });
    return result.length > 0;
  }
  
  async getAllServers(): Promise<Server[]> {
    return await db.select().from(servers);
  }

  // Activity methods
  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db.select().from(activities).where(eq(activities.id, id));
    return activity;
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db.insert(activities).values(insertActivity).returning();
    return activity;
  }
  
  async getAllActivities(limit?: number): Promise<Activity[]> {
    const query = db.select().from(activities).orderBy(desc(activities.timestamp));
    
    if (limit) {
      query.limit(limit);
    }
    
    return await query;
  }
  
  // Integration methods
  async getIntegration(id: number): Promise<Integration | undefined> {
    const [integration] = await db.select().from(integrations).where(eq(integrations.id, id));
    return integration;
  }
  
  async getIntegrationByType(type: string): Promise<Integration | undefined> {
    const [integration] = await db.select().from(integrations).where(eq(integrations.type, type));
    return integration;
  }
  
  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const [integration] = await db.insert(integrations).values(insertIntegration).returning();
    return integration;
  }
  
  async updateIntegration(id: number, integrationData: Partial<Integration>): Promise<Integration | undefined> {
    // Always update the updatedAt field
    const data = {
      ...integrationData,
      updatedAt: new Date()
    };
    
    const [updatedIntegration] = await db
      .update(integrations)
      .set(data)
      .where(eq(integrations.id, id))
      .returning();
    return updatedIntegration;
  }
  
  async deleteIntegration(id: number): Promise<boolean> {
    const result = await db.delete(integrations).where(eq(integrations.id, id)).returning({ id: integrations.id });
    return result.length > 0;
  }
  
  async getAllIntegrations(): Promise<Integration[]> {
    return await db.select().from(integrations);
  }
  
  async getEnabledIntegrations(): Promise<Integration[]> {
    return await db.select().from(integrations).where(eq(integrations.enabled, true));
  }

  // Cloud Provider methods
  async getCloudProvider(id: number): Promise<CloudProvider | undefined> {
    const [provider] = await db.select().from(cloudProviders).where(eq(cloudProviders.id, id));
    return provider;
  }
  
  async createCloudProvider(provider: InsertCloudProvider): Promise<CloudProvider> {
    const [newProvider] = await db.insert(cloudProviders).values(provider).returning();
    return newProvider;
  }
  
  async updateCloudProvider(id: number, provider: Partial<CloudProvider>): Promise<CloudProvider | undefined> {
    const [updatedProvider] = await db
      .update(cloudProviders)
      .set(provider)
      .where(eq(cloudProviders.id, id))
      .returning();
    return updatedProvider;
  }
  
  async deleteCloudProvider(id: number): Promise<boolean> {
    const result = await db.delete(cloudProviders).where(eq(cloudProviders.id, id)).returning({ id: cloudProviders.id });
    return result.length > 0;
  }
  
  async getAllCloudProviders(): Promise<CloudProvider[]> {
    return await db.select().from(cloudProviders);
  }
  
  async getUserCloudProviders(userId: number): Promise<CloudProvider[]> {
    return await db.select().from(cloudProviders).where(eq(cloudProviders.userId, userId));
  }
  
  async getCloudProviderByType(type: string): Promise<CloudProvider | undefined> {
    const [provider] = await db.select().from(cloudProviders).where(eq(cloudProviders.type, type));
    return provider;
  }
  
  // Bandwidth Allocation methods
  async getBandwidthAllocation(id: number): Promise<BandwidthAllocation | undefined> {
    const [allocation] = await db.select().from(bandwidthAllocations).where(eq(bandwidthAllocations.id, id));
    return allocation;
  }
  
  async createBandwidthAllocation(allocation: InsertBandwidthAllocation): Promise<BandwidthAllocation> {
    const [newAllocation] = await db.insert(bandwidthAllocations).values(allocation).returning();
    return newAllocation;
  }
  
  async updateBandwidthAllocation(id: number, allocation: Partial<BandwidthAllocation>): Promise<BandwidthAllocation | undefined> {
    // Always update the updatedAt field
    const data = {
      ...allocation,
      updatedAt: new Date()
    };
    
    const [updatedAllocation] = await db
      .update(bandwidthAllocations)
      .set(data)
      .where(eq(bandwidthAllocations.id, id))
      .returning();
    return updatedAllocation;
  }
  
  async deleteBandwidthAllocation(id: number): Promise<boolean> {
    const result = await db.delete(bandwidthAllocations).where(eq(bandwidthAllocations.id, id)).returning({ id: bandwidthAllocations.id });
    return result.length > 0;
  }
  
  async getAllBandwidthAllocations(): Promise<BandwidthAllocation[]> {
    return await db.select().from(bandwidthAllocations);
  }
  
  async getServerBandwidthAllocations(serverId: number): Promise<BandwidthAllocation[]> {
    return await db.select().from(bandwidthAllocations).where(eq(bandwidthAllocations.serverId, serverId));
  }
  
  async getStreamBandwidthAllocation(streamId: number): Promise<BandwidthAllocation | undefined> {
    const [allocation] = await db
      .select()
      .from(bandwidthAllocations)
      .where(eq(bandwidthAllocations.streamId, streamId));
    return allocation;
  }
  
  // Site Configuration methods
  async getSiteConfig(): Promise<SiteConfig | undefined> {
    const [config] = await db.select().from(siteConfig);
    return config;
  }
  
  async updateSiteConfig(configData: Partial<SiteConfig>): Promise<SiteConfig | undefined> {
    // Always update the updatedAt field
    const data = {
      ...configData,
      updatedAt: new Date()
    };
    
    // Get the current config to determine the ID
    const [currentConfig] = await db.select().from(siteConfig);
    
    if (!currentConfig) {
      // If no config exists, create a new one
      const [newConfig] = await db.insert(siteConfig).values({
        ...data,
        siteName: data.siteName || "Stream Manager",
        isConfigured: data.isConfigured !== undefined ? data.isConfigured : true
      }).returning();
      return newConfig;
    }
    
    // Update existing config
    const [updatedConfig] = await db
      .update(siteConfig)
      .set(data)
      .where(eq(siteConfig.id, currentConfig.id))
      .returning();
    return updatedConfig;
  }
}

// Use memory storage for backwards compatibility or testing
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private streams: Map<number, Stream>;
  private servers: Map<number, Server>;
  private activities: Map<number, Activity>;
  private integrations: Map<number, Integration>;
  
  sessionStore: session.Store;
  
  private userIdCounter: number;
  private streamIdCounter: number;
  private serverIdCounter: number;
  private activityIdCounter: number;
  private integrationIdCounter: number;

  constructor() {
    this.users = new Map();
    this.streams = new Map();
    this.servers = new Map();
    this.activities = new Map();
    this.integrations = new Map();
    
    this.userIdCounter = 1;
    this.streamIdCounter = 1;
    this.serverIdCounter = 1;
    this.activityIdCounter = 1;
    this.integrationIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h
    });
    
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "admin123", // This will be hashed in auth.ts
      isAdmin: true,
      fullName: "Administrator",
      email: "admin@example.com"
    });
    
    // Create default server
    this.createServer({
      name: "Default RTMP Server",
      host: "localhost",
      port: 1935,
      isInstalled: false,
      status: "offline",
      config: {
        rtmp: {
          port: 1935,
          chunk_size: 60000,
          gop_cache: true,
          ping: 30,
          ping_timeout: 60
        },
        http: {
          port: 8000,
          allow_origin: "*"
        }
      }
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      isAdmin: insertUser.isAdmin ?? false,
      email: insertUser.email ?? null,
      fullName: insertUser.fullName ?? null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Stream methods
  async getStream(id: number): Promise<Stream | undefined> {
    return this.streams.get(id);
  }
  
  async getStreamByKey(streamKey: string): Promise<Stream | undefined> {
    return Array.from(this.streams.values()).find(
      (stream) => stream.streamKey === streamKey,
    );
  }
  
  async createStream(insertStream: InsertStream): Promise<Stream> {
    const id = this.streamIdCounter++;
    const now = new Date();
    const stream: Stream = { 
      ...insertStream, 
      id, 
      viewers: 0, 
      isActive: insertStream.isActive ?? false,
      startedAt: insertStream.isActive ? now : null,
      duration: 0,
      bandwidth: 0,
      quality: insertStream.quality ?? null,
      wpStreamId: null
    };
    this.streams.set(id, stream);
    return stream;
  }
  
  async updateStream(id: number, streamData: Partial<Stream>): Promise<Stream | undefined> {
    const stream = this.streams.get(id);
    if (!stream) return undefined;
    
    const updatedStream = { ...stream, ...streamData };
    this.streams.set(id, updatedStream);
    return updatedStream;
  }
  
  async deleteStream(id: number): Promise<boolean> {
    return this.streams.delete(id);
  }
  
  async getAllStreams(): Promise<Stream[]> {
    return Array.from(this.streams.values());
  }
  
  async getActiveStreams(): Promise<Stream[]> {
    return Array.from(this.streams.values()).filter(stream => stream.isActive);
  }
  
  async getUserStreams(userId: number): Promise<Stream[]> {
    return Array.from(this.streams.values()).filter(
      (stream) => stream.userId === userId,
    );
  }

  // Server methods
  async getServer(id: number): Promise<Server | undefined> {
    return this.servers.get(id);
  }
  
  async createServer(insertServer: InsertServer): Promise<Server> {
    const id = this.serverIdCounter++;
    const server: Server = { 
      ...insertServer, 
      id,
      cpuUsage: 0,
      memoryUsage: 0,
      diskUsage: 0,
      networkUsage: 0,
      uptime: 0,
      status: insertServer.status ?? null,
      isInstalled: insertServer.isInstalled ?? null,
      config: insertServer.config ?? {}
    };
    this.servers.set(id, server);
    return server;
  }
  
  async updateServer(id: number, serverData: Partial<Server>): Promise<Server | undefined> {
    const server = this.servers.get(id);
    if (!server) return undefined;
    
    const updatedServer = { ...server, ...serverData };
    this.servers.set(id, updatedServer);
    return updatedServer;
  }
  
  async deleteServer(id: number): Promise<boolean> {
    return this.servers.delete(id);
  }
  
  async getAllServers(): Promise<Server[]> {
    return Array.from(this.servers.values());
  }

  // Activity methods
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const now = new Date();
    const activity: Activity = { 
      ...insertActivity, 
      id,
      timestamp: now,
      userId: insertActivity.userId ?? null,
      relatedId: insertActivity.relatedId ?? null,
      relatedType: insertActivity.relatedType ?? null
    };
    this.activities.set(id, activity);
    return activity;
  }
  
  async getAllActivities(limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => {
        // Handle null timestamps safely
        if (!a.timestamp) return 1;
        if (!b.timestamp) return -1;
        return b.timestamp.getTime() - a.timestamp.getTime();
      });
    
    return limit ? activities.slice(0, limit) : activities;
  }
  
  // Integration methods
  async getIntegration(id: number): Promise<Integration | undefined> {
    return this.integrations.get(id);
  }
  
  async getIntegrationByType(type: string): Promise<Integration | undefined> {
    return Array.from(this.integrations.values()).find(
      (integration) => integration.type === type
    );
  }
  
  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const id = this.integrationIdCounter++;
    const now = new Date();
    const integration: Integration = {
      ...insertIntegration,
      id,
      createdAt: now,
      updatedAt: now,
      enabled: insertIntegration.enabled ?? false,
      config: insertIntegration.config ?? {}
    };
    this.integrations.set(id, integration);
    return integration;
  }
  
  async updateIntegration(id: number, integrationData: Partial<Integration>): Promise<Integration | undefined> {
    const integration = this.integrations.get(id);
    if (!integration) return undefined;
    
    const updatedIntegration = {
      ...integration,
      ...integrationData,
      updatedAt: new Date()
    };
    this.integrations.set(id, updatedIntegration);
    return updatedIntegration;
  }
  
  async deleteIntegration(id: number): Promise<boolean> {
    return this.integrations.delete(id);
  }
  
  async getAllIntegrations(): Promise<Integration[]> {
    return Array.from(this.integrations.values());
  }
  
  async getEnabledIntegrations(): Promise<Integration[]> {
    return Array.from(this.integrations.values()).filter(
      (integration) => integration.enabled
    );
  }

  // Site Configuration methods
  async getSiteConfig(): Promise<SiteConfig | undefined> {
    // In memory implementation just returns a default configuration
    return {
      id: 1,
      siteName: "Stream Manager",
      domain: null,
      hostname: "localhost",
      primaryColor: "#3b82f6",
      siteDescription: "Video Stream Server Management Platform",
      faviconUrl: null,
      contactEmail: null,
      dbName: null,
      dbUser: null,
      dbHost: null,
      isConfigured: false,
      updatedAt: new Date()
    };
  }
  
  async updateSiteConfig(configData: Partial<SiteConfig>): Promise<SiteConfig | undefined> {
    // For the memory implementation, we just return the updated config without saving it
    const currentConfig = await this.getSiteConfig();
    return {
      ...currentConfig!,
      ...configData,
      updatedAt: new Date()
    };
  }

  // Cloud Provider methods (stubs to satisfy the interface)
  async getCloudProvider(): Promise<CloudProvider | undefined> { return undefined; }
  async createCloudProvider(provider: InsertCloudProvider): Promise<CloudProvider> { 
    return { id: 1, ...provider, createdAt: new Date(), isActive: true } as CloudProvider;
  }
  async updateCloudProvider(): Promise<CloudProvider | undefined> { return undefined; }
  async deleteCloudProvider(): Promise<boolean> { return true; }
  async getAllCloudProviders(): Promise<CloudProvider[]> { return []; }
  async getUserCloudProviders(): Promise<CloudProvider[]> { return []; }
  async getCloudProviderByType(): Promise<CloudProvider | undefined> { return undefined; }
  
  // Bandwidth Allocation methods (stubs to satisfy the interface)
  async getBandwidthAllocation(): Promise<BandwidthAllocation | undefined> { return undefined; }
  async createBandwidthAllocation(allocation: InsertBandwidthAllocation): Promise<BandwidthAllocation> {
    return { id: 1, ...allocation, createdAt: new Date(), updatedAt: new Date() } as BandwidthAllocation;
  }
  async updateBandwidthAllocation(): Promise<BandwidthAllocation | undefined> { return undefined; }
  async deleteBandwidthAllocation(): Promise<boolean> { return true; }
  async getAllBandwidthAllocations(): Promise<BandwidthAllocation[]> { return []; }
  async getServerBandwidthAllocations(): Promise<BandwidthAllocation[]> { return []; }
  async getStreamBandwidthAllocation(): Promise<BandwidthAllocation | undefined> { return undefined; }
}

// Use the database storage instead of memory storage
export const storage = new DatabaseStorage();
