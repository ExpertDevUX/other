# Video Stream Server Manager

A powerful video stream server management platform that simplifies complex server operations through intuitive design and intelligent automation.

## Features

- **User Management**: Secure authentication, role-based access control
- **RTMP Server Management**: Automatic installation script with options for different server resource levels
- **Stream Management**: Create, manage and monitor video streams
- **Embedding**: Embed streams on external websites using iframes and widgets
- **WordPress Integration**: Synchronize with WpStream WordPress plugin
- **Real-time Metrics**: Interactive server health dashboard with WebSockets
- **Storage Management**: Backup creation, restore, and storage optimization
- **VPS Information**: Server performance monitoring and analysis

## Tech Stack

- **Frontend**: React, TypeScript, TailwindCSS, shadcn/ui
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSockets for live monitoring
- **RTMP**: Node-Media-Server for RTMP handling

## Deployment Options

### 1. Deploy on Replit

The easiest way to deploy this application is directly on Replit:

1. Click the "Deploy" button in the Replit interface
2. Once deployed, your app will be available at a `.replit.app` domain
3. Set up environment variables for database connections if needed

### 2. Deploy to AWS

#### Prerequisites

- An AWS account
- Basic understanding of AWS services (EC2, RDS)
- Domain name (optional)

#### Steps for AWS Deployment

1. **Set up a PostgreSQL Database**

   - Create an RDS PostgreSQL instance
   - Note the database endpoint, username, and password

2. **Set up an EC2 Instance**

   ```bash
   # Launch a new EC2 instance with Ubuntu 22.04
   # Connect to your instance via SSH
   ssh -i your-key.pem ubuntu@your-instance-ip

   # Update system
   sudo apt update && sudo apt upgrade -y

   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt install -y nodejs

   # Install PostgreSQL client tools
   sudo apt install -y postgresql-client

   # Install Git
   sudo apt install -y git

   # Clone the repository
   git clone https://github.com/yourusername/video-stream-server.git
   cd video-stream-server

   # Install dependencies
   npm install

   # Set up environment variables
   cat > .env << EOF
   DATABASE_URL=postgresql://username:password@your-rds-endpoint:5432/your-database
   PORT=5000
   # Add other necessary environment variables
   EOF
   ```

3. **Set up RTMP Server**

   You can use the built-in installation script:

   ```bash
   # This will install the RTMP server components
   sudo ./install.sh
   ```

4. **Configure NGINX as a reverse proxy**

   ```bash
   sudo apt install -y nginx
   
   # Configure NGINX
   sudo nano /etc/nginx/sites-available/stream-manager

   # Add this configuration
   server {
     listen 80;
     server_name your-domain.com;

     location / {
       proxy_pass http://localhost:5000;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
     }
   }

   # Enable the site
   sudo ln -s /etc/nginx/sites-available/stream-manager /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

5. **Set up PM2 for process management**

   ```bash
   # Install PM2 globally
   sudo npm install -g pm2

   # Start the application
   pm2 start "npm run start" --name stream-manager
   
   # Ensure PM2 restarts on system reboot
   pm2 startup
   pm2 save
   ```

6. **Set up SSL with Let's Encrypt (Optional)**

   ```bash
   sudo apt install -y certbot python3-certbot-nginx
   sudo certbot --nginx -d your-domain.com
   ```

## Development

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL database

### Setup

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/video-stream-server.git
   cd video-stream-server
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Set up environment variables
   ```bash
   # Create a .env file
   DATABASE_URL=postgresql://username:password@localhost:5432/your-database
   PORT=5000
   ```

4. Run the development server
   ```bash
   npm run dev
   ```

### Default Admin Credentials

- Username: `admin`
- Password: `admin123`

**Important**: Change these credentials immediately after first login.

## License

This project is proprietary software.

## Support

For support or inquiries, please contact: info@hwosecurity.org