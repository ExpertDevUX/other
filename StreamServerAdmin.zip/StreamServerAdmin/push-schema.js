import { migrate } from 'drizzle-orm/postgres-js/migrator';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './shared/schema.js';

// Check for DATABASE_URL
if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL must be set in environment variables');
  process.exit(1);
}

async function main() {
  console.log('Initializing database schema...');
  
  const connectionString = process.env.DATABASE_URL;
  const client = postgres(connectionString);
  const db = drizzle(client, { schema });
  
  console.log('Creating tables...');
  try {
    // Create tables
    const migrationClient = postgres(connectionString, { max: 1 });
    
    // Push the schema changes
    await migrate(drizzle(migrationClient), { migrationsFolder: 'drizzle' });
    
    console.log('Schema created successfully');
  } catch (error) {
    console.error('Error creating schema:', error);
  } finally {
    await client.end();
    process.exit(0);
  }
}

main().catch(console.error);